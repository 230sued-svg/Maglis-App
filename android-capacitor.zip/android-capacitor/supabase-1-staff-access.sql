-- الخطوة 1 (نفّذها الآن): تسمح لحساب الموظفين المسجَّل دخوله بالوصول للجدول
-- لا تُغلق الوصول عن الأجهزة القديمة، فهي إضافة فقط
grant usage on schema public to authenticated;
grant select, insert, update, delete on public.kv_store to authenticated;

drop policy if exists "staff all" on kv_store;
create policy "staff all" on kv_store
  for all to authenticated using (true) with check (true);
