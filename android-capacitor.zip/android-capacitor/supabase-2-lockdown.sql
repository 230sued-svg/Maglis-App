-- الخطوة 2 (لاحقاً): بعد أن تسجّل كل الأجهزة دخول حساب المزامنة وتتأكد أنها تعمل
-- تغلق الوصول عن أي شخص ليس لديه حساب
drop policy if exists "anon all" on kv_store;
revoke all on public.kv_store from anon;
