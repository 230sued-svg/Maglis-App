/* ==========================================================================
   Maqlis cloud sync (Supabase) + order notifications
   - ملف إضافي مستقل: لا يعدّل أي كود موجود في script.js
   - يزامن مفاتيح localStorage المشتركة بين أجهزة الموظفين عبر جدول kv_store
   - يرسل إشعاراً عند وصول طلب جديد أو جهوزية طلب (حسب إعدادات التطبيق)
   ========================================================================== */
(function () {
  'use strict';
  if (window.__maqlisSyncLoaded) return;
  window.__maqlisSyncLoaded = true;

  var APP = 'admin-hazem';
  var NOTIFY = {"newOrder": true, "orderReady": false};
  var SUPABASE_URL = 'https://yowejflxjxncqrtunfay.supabase.co';
  var SUPABASE_KEY = 'sb_publishable_ML2VyzBx3Yv_u_DbQQ7Vhw_3IjeJjh_';
  var TABLE = SUPABASE_URL + '/rest/v1/kv_store';
  var POLL_VISIBLE = 3000, POLL_HIDDEN = 10000, FLUSH_DELAY = 400;

  // المفاتيح المشتركة بين الأجهزة. (جلسات الدخول والسلات وغيرها تبقى محلية)
  var SYNC_KEYS = [
    'maqlis_users', 'maqlis_pickup_orders', 'maqlis_inventory', 'maqlis_sales',
    'maqlis_sales_archive', 'maqlis_stock_movements', 'maqlis_shifts',
    'maqlis_couriers', 'maqlis_courier_deliveries', 'maqlis_retention_days',
    'maqlis_last_archive'
  ];
  var isSync = {};
  SYNC_KEYS.forEach(function (k) { isSync[k] = 1; });

  var ls = window.localStorage;
  var nGet = Storage.prototype.getItem;
  var nSet = Storage.prototype.setItem;
  function lget(k) { return nGet.call(ls, k); }
  function lset(k, v) { try { nSet.call(ls, k, v); return true; } catch (e) { return false; } }
  function log() { try { console.log.apply(console, ['[sync]'].concat([].slice.call(arguments))); } catch (e) {} }

  // ---------- ترميز القيم ----------
  function norm(raw) {
    if (raw === null || raw === undefined) return null;
    try { return JSON.stringify(JSON.parse(raw)); } catch (e) { return String(raw); }
  }
  function encode(raw) {
    try { var v = JSON.parse(raw); if (v !== null) return v; } catch (e) {}
    return { __raw: String(raw) };
  }
  function decode(value) {
    if (value && typeof value === 'object' && !Array.isArray(value) &&
        Object.keys(value).length === 1 && Object.prototype.hasOwnProperty.call(value, '__raw')) {
      return String(value.__raw);
    }
    return JSON.stringify(value);
  }
  function hdr(extra) {
    var h = { apikey: SUPABASE_KEY };
    if (extra) for (var k in extra) h[k] = extra[k];
    return h;
  }

  // ---------- الحالة ----------
  var dirty = {};      // مفاتيح تغيّرت محلياً وتنتظر الرفع
  var inflight = {};   // مفاتيح قيد الرفع
  var ready = false;   // تمّ أول سحب ناجح من السيرفر
  var lastSeen = '';
  var flushTimer = null, pollTimer = null, busy = false;

  // ---------- التقاط الكتابة في localStorage ----------
  Storage.prototype.setItem = function (k, v) {
    var tracked = (this === ls && isSync[k]);
    var before = tracked ? lget(k) : null;
    nSet.call(this, k, v);
    if (tracked && norm(String(v)) !== norm(before)) {
      dirty[k] = true;
      scheduleFlush();
    }
  };

  function scheduleFlush() {
    if (!ready || flushTimer) return;
    flushTimer = setTimeout(flush, FLUSH_DELAY);
  }

  function flush() {
    flushTimer = null;
    if (!ready) return;
    var keys = Object.keys(dirty);
    if (!keys.length) return;
    var rows = [];
    keys.forEach(function (k) {
      var raw = lget(k);
      delete dirty[k];
      if (raw !== null) { rows.push({ key: k, value: encode(raw) }); inflight[k] = norm(raw); }
    });
    if (!rows.length) return;
    fetch(TABLE + '?on_conflict=key', {
      method: 'POST',
      headers: hdr({ 'Content-Type': 'application/json', 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
      body: JSON.stringify(rows)
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      rows.forEach(function (row) { delete inflight[row.key]; });
    }).catch(function (e) {
      log('push failed, will retry:', e && e.message);
      rows.forEach(function (row) { delete inflight[row.key]; dirty[row.key] = true; });
      setTimeout(scheduleFlush, 5000);
    });
  }

  // ---------- تطبيق بيانات السيرفر محلياً ----------
  function backupOnce(k, old) {
    var bk = '__sync_backup_' + k;
    if (old && old.length < 500000 && lget(bk) === null) lset(bk, old);
  }

  function applyRow(row, baseline) {
    var k = row.key;
    if (!isSync[k]) return;
    var raw = decode(row.value), rn = norm(raw);
    if (baseline) delete dirty[k];                       // أول مزامنة: السيرفر هو المرجع
    if (dirty[k] || inflight[k] !== undefined) return;   // تعديل محلي أحدث ينتظر الرفع
    var old = lget(k);
    if (norm(old) === rn) return;
    backupOnce(k, old);
    lset(k, raw);
    try {
      window.dispatchEvent(new StorageEvent('storage', {
        key: k, oldValue: old, newValue: raw, storageArea: ls, url: location.href
      }));
    } catch (e) {}
    if (!baseline && k === 'maqlis_pickup_orders') watchOrders(old, raw);
  }

  function pull() {
    var url = TABLE + '?select=key,value,updated_at&order=updated_at.asc';
    if (lastSeen) url += '&updated_at=gt.' + encodeURIComponent(lastSeen);
    return fetch(url, { headers: hdr() }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (rows) {
      var baseline = !ready;
      var have = {};
      rows.forEach(function (row) {
        have[row.key] = true;
        if (row.updated_at && row.updated_at > lastSeen) lastSeen = row.updated_at;
        applyRow(row, baseline);
      });
      if (baseline) {
        // مفاتيح موجودة عندي ولا وجود لها في السيرفر: ارفعها (تهيئة أولى)
        SYNC_KEYS.forEach(function (k) { if (!have[k] && lget(k) !== null) dirty[k] = true; });
        ready = true;
        log('ready, app =', APP);
      }
      if (Object.keys(dirty).length) scheduleFlush();
    });
  }

  function tick() {
    if (busy) return;
    busy = true;
    pull().catch(function (e) { log('pull failed:', e && e.message); }).then(function () {
      busy = false;
      clearTimeout(pollTimer);
      pollTimer = setTimeout(tick, document.hidden ? POLL_HIDDEN : POLL_VISIBLE);
    });
  }

  // ---------- الإشعارات ----------
  function isWarehouseOrder(o) {
    if (o.orderType === 'warehouse') return true;
    if (o.orderType === 'sub_cashier') return false;
    if (o.source === 'online') return true;
    if (o.source === 'pos' && !o.subCashier) return true;
    return false;
  }
  function parseArr(raw) {
    try { var v = JSON.parse(raw); return Array.isArray(v) ? v : []; } catch (e) { return []; }
  }
  function describe(o) {
    var parts = ['طلب #' + String(o.id).split('-').pop()];
    if (o.customer && o.customer.name) parts.push(o.customer.name);
    if (Array.isArray(o.items) && o.items.length) parts.push(o.items.length + ' صنف');
    return parts.join(' • ');
  }
  function recent(o) {
    var t = Date.parse(o.date || '');
    return isNaN(t) || (Date.now() - t) < 24 * 3600 * 1000;
  }
  function watchOrders(oldRaw, newRaw) {
    var prevById = {};
    parseArr(oldRaw).forEach(function (o) { if (o && o.id) prevById[o.id] = o; });
    var news = [], readies = [];
    parseArr(newRaw).forEach(function (o) {
      if (!o || !o.id || !recent(o)) return;
      var prev = prevById[o.id];
      if (NOTIFY.newOrder && !prev && o.status === 'pending' &&
          (APP !== 'store-orders' || isWarehouseOrder(o))) news.push(o);
      else if (NOTIFY.orderReady && prev && prev.status !== 'ready' && o.status === 'ready') readies.push(o);
    });
    emit(news, 'طلب جديد', 'طلبات جديدة', 'n');
    emit(readies, 'طلب جاهز', 'طلبات جاهزة', 'r');
  }
  function emit(list, one, many, tag) {
    if (!list.length) return;
    if (list.length > 3) notify(list.length + ' ' + many, 'افتح التطبيق لمشاهدتها', tag + 'x' + Date.now());
    else list.forEach(function (o) { notify(one, describe(o), tag + o.id); });
  }

  function hashId(s) {
    var h = 0; s = String(s);
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return Math.abs(h) % 2147483000 + 1;
  }
  function nativeLN() {
    var C = window.Capacitor;
    return C && C.Plugins && C.Plugins.LocalNotifications ? C.Plugins.LocalNotifications : null;
  }
  var channelReady = false;
  function ensureNativePermission(LN) {
    return LN.checkPermissions().then(function (p) {
      if (p.display === 'granted') return true;
      return LN.requestPermissions().then(function (q) { return q.display === 'granted'; });
    });
  }
  function notify(title, body, key) {
    var LN = nativeLN();
    if (LN) {
      ensureNativePermission(LN).then(function (ok) {
        if (!ok) return;
        var p = channelReady ? Promise.resolve() : LN.createChannel({
          id: 'orders', name: 'الطلبات', description: 'إشعارات الطلبات',
          importance: 5, visibility: 1, vibration: true
        }).then(function () { channelReady = true; }).catch(function () {});
        return p.then(function () {
          return LN.schedule({ notifications: [{ id: hashId(key), title: title, body: body, channelId: 'orders' }] });
        });
      }).catch(function (e) { log('notify failed', e && e.message); });
    } else if ('Notification' in window && Notification.permission === 'granted') {
      try { new Notification(title, { body: body }); } catch (e) {}
    }
  }
  function askPermissionEarly() {
    if (!NOTIFY.newOrder && !NOTIFY.orderReady) return;
    var LN = nativeLN();
    if (LN) { setTimeout(function () { ensureNativePermission(LN).catch(function () {}); }, 1500); }
    else if ('Notification' in window && Notification.permission === 'default') {
      var once = function () {
        document.removeEventListener('click', once);
        try { Notification.requestPermission(); } catch (e) {}
      };
      document.addEventListener('click', once);
    }
  }

  // ---------- تشغيل ----------
  document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(); });
  window.addEventListener('online', tick);
  askPermissionEarly();
  tick();

  window.MaqlisSync = {
    pullNow: tick,
    pushAll: function () {
      SYNC_KEYS.forEach(function (k) { if (lget(k) !== null) dirty[k] = true; });
      scheduleFlush();
    },
    status: function () { return { app: APP, ready: ready, pending: Object.keys(dirty) }; }
  };
})();
