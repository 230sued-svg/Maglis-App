/* ==========================================================================
   Maqlis cloud sync (Supabase) + order notifications
   - ملف إضافي مستقل: لا يعدّل أي كود موجود في script.js
   - يزامن مفاتيح localStorage المشتركة بين أجهزة الموظفين عبر جدول kv_store
   - يرسل إشعاراً عند وصول طلب جديد أو جهوزية طلب (حسب إعدادات التطبيق)
   ========================================================================== */
(function () {
  'use strict';
  if (window.__maqlisSyncLoaded) return;
  window.__maqlisSyncLoaded = true;

  var APP = 'admin-hazem';
  var NOTIFY = {"newOrder": true, "orderReady": false};
  var SUPABASE_URL = 'https://yowejflxjxncqrtunfay.supabase.co';
  var SUPABASE_KEY = 'sb_publishable_ML2VyzBx3Yv_u_DbQQ7Vhw_3IjeJjh_';
  var TABLE = SUPABASE_URL + '/rest/v1/kv_store';
  var POLL_VISIBLE = 3000, POLL_HIDDEN = 10000, FLUSH_DELAY = 400;

  // المفاتيح المشتركة بين الأجهزة. (جلسات الدخول والسلات وغيرها تبقى محلية)
  var SYNC_KEYS = [
    'maqlis_users', 'maqlis_pickup_orders', 'maqlis_inventory', 'maqlis_sales',
    'maqlis_sales_archive', 'maqlis_stock_movements', 'maqlis_shifts',
    'maqlis_couriers', 'maqlis_courier_deliveries', 'maqlis_retention_days',
    'maqlis_last_archive'
  ];
  var isSync = {};
  SYNC_KEYS.forEach(function (k) { isSync[k] = 1; });

  var ls = window.localStorage;
  var nGet = Storage.prototype.getItem;
  var nSet = Storage.prototype.setItem;
  function lget(k) { return nGet.call(ls, k); }
  function lset(k, v) { try { nSet.call(ls, k, v); return true; } catch (e) { return false; } }
  function log() { try { console.log.apply(console, ['[sync]'].concat([].slice.call(arguments))); } catch (e) {} }

  // ---------- ترميز القيم ----------
  function norm(raw) {
    if (raw === null || raw === undefined) return null;
    try { return JSON.stringify(JSON.parse(raw)); } catch (e) { return String(raw); }
  }
  function encode(raw) {
    try { var v = JSON.parse(raw); if (v !== null) return v; } catch (e) {}
    return { __raw: String(raw) };
  }
  function decode(value) {
    if (value && typeof value === 'object' && !Array.isArray(value) &&
        Object.keys(value).length === 1 && Object.prototype.hasOwnProperty.call(value, '__raw')) {
      return String(value.__raw);
    }
    return JSON.stringify(value);
  }
  function hdr(extra) {
    var h = { apikey: SUPABASE_KEY };
    if (extra) for (var k in extra) h[k] = extra[k];
    return h;
  }

  // ---------- الحالة ----------
  var dirty = {};      // مفاتيح تغيّرت محلياً وتنتظر الرفع
  var inflight = {};   // مفاتيح قيد الرفع
  var ready = false;   // تمّ أول سحب ناجح من السيرفر
  var lastSeen = '';
  var flushTimer = null, pollTimer = null, busy = false;
  var lastWrite = {};  // وقت آخر كتابة/رفع محلي لكل مفتاح (لتجاهل ردود سحب قديمة)
  var st = { pullOk: 0, pullErr: '', pushOk: 0, pushErr: '', remoteCount: {} };
  var OVERLAP_MS = 120000;  // إعادة جلب آخر دقيقتين لتحمّل فروق ساعات الأجهزة

  // ---------- التقاط الكتابة في localStorage ----------
  Storage.prototype.setItem = function (k, v) {
    var tracked = (this === ls && isSync[k]);
    var before = tracked ? lget(k) : null;
    nSet.call(this, k, v);
    if (tracked && norm(String(v)) !== norm(before)) {
      dirty[k] = true;
      lastWrite[k] = Date.now();
      scheduleFlush();
    }
  };

  function scheduleFlush() {
    if (!ready || flushTimer) return;
    flushTimer = setTimeout(flush, FLUSH_DELAY);
  }

  function flush() {
    flushTimer = null;
    if (!ready) return;
    var keys = Object.keys(dirty);
    if (!keys.length) return;
    var rows = [];
    keys.forEach(function (k) {
      var raw = lget(k);
      delete dirty[k];
      if (raw !== null) { rows.push({ key: k, value: encode(raw), updated_at: new Date().toISOString() }); inflight[k] = norm(raw); }
    });
    if (!rows.length) return;
    fetch(TABLE + '?on_conflict=key', {
      method: 'POST',
      headers: hdr({ 'Content-Type': 'application/json', 'Prefer': 'resolution=merge-duplicates,return=minimal' }),
      body: JSON.stringify(rows)
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      rows.forEach(function (row) { delete inflight[row.key]; lastWrite[row.key] = Date.now(); });
      st.pushOk = Date.now(); st.pushErr = ''; paint();
    }).catch(function (e) {
      log('push failed, will retry:', e && e.message);
      st.pushErr = String(e && e.message || e); paint();
      rows.forEach(function (row) { delete inflight[row.key]; dirty[row.key] = true; });
      setTimeout(scheduleFlush, 5000);
    });
  }

  // ---------- تطبيق بيانات السيرفر محلياً ----------
  function backupOnce(k, old) {
    var bk = '__sync_backup_' + k;
    if (old && old.length < 500000 && lget(bk) === null) lset(bk, old);
  }

  function applyRow(row, baseline, startedAt) {
    var k = row.key;
    if (!isSync[k]) return;
    var raw = decode(row.value), rn = norm(raw);
    if (baseline) delete dirty[k];                       // أول مزامنة: السيرفر هو المرجع
    if (dirty[k] || inflight[k] !== undefined) return;   // تعديل محلي أحدث ينتظر الرفع
    if (!baseline && lastWrite[k] && lastWrite[k] >= startedAt) return;  // رد سحب بدأ قبل تعديل محلي
    var old = lget(k);
    if (norm(old) === rn) return;
    backupOnce(k, old);
    lset(k, raw);
    try {
      window.dispatchEvent(new StorageEvent('storage', {
        key: k, oldValue: old, newValue: raw, storageArea: ls, url: location.href
      }));
    } catch (e) {}
    if (!baseline && k === 'maqlis_pickup_orders') watchOrders(old, raw);
  }

  function sinceParam() {
    if (!lastSeen) return '';
    var t = Date.parse(lastSeen);
    if (isNaN(t)) return '';
    return '&updated_at=gt.' + encodeURIComponent(new Date(t - OVERLAP_MS).toISOString());
  }

  function pull() {
    var started = Date.now();
    var url = TABLE + '?select=key,value,updated_at&order=updated_at.asc' + sinceParam();
    return fetch(url, { headers: hdr() }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (rows) {
      var baseline = !ready;
      var have = {};
      rows.forEach(function (row) {
        have[row.key] = true;
        if (Array.isArray(row.value)) st.remoteCount[row.key] = row.value.length;
        if (row.updated_at && row.updated_at > lastSeen) lastSeen = row.updated_at;
        applyRow(row, baseline, started);
      });
      if (baseline) {
        // مفاتيح موجودة عندي ولا وجود لها في السيرفر: ارفعها (تهيئة أولى)
        SYNC_KEYS.forEach(function (k) { if (!have[k] && lget(k) !== null) dirty[k] = true; });
        ready = true;
        log('ready, app =', APP);
      }
      st.pullOk = Date.now(); st.pullErr = '';
      if (Object.keys(dirty).length) scheduleFlush();
    });
  }

  function tick() {
    if (busy) return;
    busy = true;
    pull().catch(function (e) {
      log('pull failed:', e && e.message);
      st.pullErr = String(e && e.message || e);
    }).then(function () {
      busy = false;
      paint();
      clearTimeout(pollTimer);
      pollTimer = setTimeout(tick, document.hidden ? POLL_HIDDEN : POLL_VISIBLE);
    });
  }

  // ---------- الإشعارات ----------
  function isWarehouseOrder(o) {
    if (o.orderType === 'warehouse') return true;
    if (o.orderType === 'sub_cashier') return false;
    if (o.source === 'online') return true;
    if (o.source === 'pos' && !o.subCashier) return true;
    return false;
  }
  function parseArr(raw) {
    try { var v = JSON.parse(raw); return Array.isArray(v) ? v : []; } catch (e) { return []; }
  }
  function describe(o) {
    var parts = ['طلب #' + String(o.id).split('-').pop()];
    if (o.customer && o.customer.name) parts.push(o.customer.name);
    if (Array.isArray(o.items) && o.items.length) parts.push(o.items.length + ' صنف');
    return parts.join(' • ');
  }
  function recent(o) {
    var t = Date.parse(o.date || '');
    return isNaN(t) || (Date.now() - t) < 24 * 3600 * 1000;
  }
  function watchOrders(oldRaw, newRaw) {
    var prevById = {};
    parseArr(oldRaw).forEach(function (o) { if (o && o.id) prevById[o.id] = o; });
    var news = [], readies = [];
    parseArr(newRaw).forEach(function (o) {
      if (!o || !o.id || !recent(o)) return;
      var prev = prevById[o.id];
      if (NOTIFY.newOrder && !prev && o.status === 'pending' &&
          (APP !== 'store-orders' || isWarehouseOrder(o))) news.push(o);
      else if (NOTIFY.orderReady && prev && prev.status !== 'ready' && o.status === 'ready') readies.push(o);
    });
    emit(news, 'طلب جديد', 'طلبات جديدة', 'n');
    emit(readies, 'طلب جاهز', 'طلبات جاهزة', 'r');
  }
  function emit(list, one, many, tag) {
    if (!list.length) return;
    if (list.length > 3) notify(list.length + ' ' + many, 'افتح التطبيق لمشاهدتها', tag + 'x' + Date.now());
    else list.forEach(function (o) { notify(one, describe(o), tag + o.id); });
  }

  function hashId(s) {
    var h = 0; s = String(s);
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
    return Math.abs(h) % 2147483000 + 1;
  }
  function nativeLN() {
    var C = window.Capacitor;
    return C && C.Plugins && C.Plugins.LocalNotifications ? C.Plugins.LocalNotifications : null;
  }
  var channelReady = false;
  function ensureNativePermission(LN) {
    return LN.checkPermissions().then(function (p) {
      if (p.display === 'granted') return true;
      return LN.requestPermissions().then(function (q) { return q.display === 'granted'; });
    });
  }
  function notify(title, body, key) {
    var LN = nativeLN();
    if (LN) {
      ensureNativePermission(LN).then(function (ok) {
        if (!ok) return;
        var p = channelReady ? Promise.resolve() : LN.createChannel({
          id: 'orders', name: 'الطلبات', description: 'إشعارات الطلبات',
          importance: 5, visibility: 1, vibration: true
        }).then(function () { channelReady = true; }).catch(function () {});
        return p.then(function () {
          return LN.schedule({ notifications: [{ id: hashId(key), title: title, body: body, channelId: 'orders' }] });
        });
      }).catch(function (e) { log('notify failed', e && e.message); });
    } else if ('Notification' in window && Notification.permission === 'granted') {
      try { new Notification(title, { body: body }); } catch (e) {}
    }
  }
  function askPermissionEarly() {
    if (!NOTIFY.newOrder && !NOTIFY.orderReady) return;
    var LN = nativeLN();
    if (LN) { setTimeout(function () { ensureNativePermission(LN).catch(function () {}); }, 1500); }
    else if ('Notification' in window && Notification.permission === 'default') {
      var once = function () {
        document.removeEventListener('click', once);
        try { Notification.requestPermission(); } catch (e) {}
      };
      document.addEventListener('click', once);
    }
  }

  // ---------- مؤشر الحالة (دائرة صغيرة أسفل الشاشة؛ اضغطها لعرض التفاصيل) ----------
  var badge = null, panel = null;
  function count(k) {
    try { var v = JSON.parse(lget(k)); return Array.isArray(v) ? v.length : (v ? 1 : 0); } catch (e) { return '-'; }
  }
  function ago(t) { return t ? Math.round((Date.now() - t) / 1000) + ' ث' : '—'; }
  function paint() {
    if (!badge) return;
    var color = '#2e9e5b';
    if (!ready) color = st.pullErr ? '#d64545' : '#e0a800';
    else if (st.pullErr || st.pushErr) color = '#d64545';
    else if (Object.keys(dirty).length || Object.keys(inflight).length) color = '#e0a800';
    badge.style.background = color;
    if (panel) fillPanel();
  }
  function fillPanel() {
    var lines = [
      'التطبيق: ' + APP,
      'الحالة: ' + (ready ? 'متصل ✓' : 'لم تكتمل أول مزامنة ✗'),
      'آخر سحب: ' + ago(st.pullOk) + (st.pullErr ? ' | خطأ: ' + st.pullErr : ''),
      'آخر رفع: ' + ago(st.pushOk) + (st.pushErr ? ' | خطأ: ' + st.pushErr : ''),
      'بانتظار الرفع: ' + Object.keys(dirty).length,
      'المستخدمون: محلي ' + count('maqlis_users') + ' / سيرفر ' + (st.remoteCount.maqlis_users === undefined ? '؟' : st.remoteCount.maqlis_users),
      'الطلبات: محلي ' + count('maqlis_pickup_orders') + ' / سيرفر ' + (st.remoteCount.maqlis_pickup_orders === undefined ? '؟' : st.remoteCount.maqlis_pickup_orders),
      'المخزون: محلي ' + count('maqlis_inventory') + ' / سيرفر ' + (st.remoteCount.maqlis_inventory === undefined ? '؟' : st.remoteCount.maqlis_inventory)
    ];
    panel.firstChild.textContent = lines.join('\n');
  }
  function mkBtn(label, fn) {
    var b = document.createElement('button');
    b.textContent = label;
    b.style.cssText = 'margin:6px 4px 0 0;padding:6px 10px;border:0;border-radius:6px;background:#444;color:#fff;font:13px sans-serif';
    b.onclick = fn;
    return b;
  }
  function buildUI() {
    try {
      if (!document.body || !document.createElement) return;
      badge = document.createElement('div');
      badge.style.cssText = 'position:fixed;left:6px;bottom:calc(6px + env(safe-area-inset-bottom, 0px));width:14px;height:14px;border-radius:50%;background:#e0a800;opacity:.8;z-index:2147483647;box-shadow:0 0 0 2px rgba(255,255,255,.7)';
      badge.onclick = function () {
        if (panel) { panel.remove(); panel = null; return; }
        panel = document.createElement('div');
        panel.style.cssText = 'position:fixed;left:6px;right:6px;bottom:calc(28px + env(safe-area-inset-bottom, 0px));background:#111;color:#fff;padding:10px;border-radius:10px;z-index:2147483647;direction:rtl;text-align:right;font:13px/1.7 sans-serif;box-shadow:0 4px 16px rgba(0,0,0,.5)';
        var pre = document.createElement('div'); pre.style.whiteSpace = 'pre-wrap'; panel.appendChild(pre);
        panel.appendChild(mkBtn('سحب الآن', function () { tick(); }));
        panel.appendChild(mkBtn('رفع كل البيانات', function () { window.MaqlisSync.pushAll(); }));
        panel.appendChild(mkBtn('إغلاق', function () { panel.remove(); panel = null; }));
        document.body.appendChild(panel);
        fillPanel();
      };
      document.body.appendChild(badge);
      paint();
    } catch (e) {}
  }

  // ---------- تشغيل ----------
  document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(); });
  window.addEventListener('online', tick);
  buildUI();
  askPermissionEarly();
  tick();

  window.MaqlisSync = {
    pullNow: tick,
    pushAll: function () {
      SYNC_KEYS.forEach(function (k) { if (lget(k) !== null) dirty[k] = true; });
      scheduleFlush();
    },
    status: function () { return { app: APP, ready: ready, pending: Object.keys(dirty) }; }
  };
})();
