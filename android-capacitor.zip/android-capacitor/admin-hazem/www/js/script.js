(function() {
    'use strict';

    // قراءة آمنة لسجلات localStorage مع حماية الواجهة من البيانات التالفة.
    function readAdminArray(key) {
        try {
            const value = JSON.parse(localStorage.getItem(key) || '[]');
            return Array.isArray(value) ? value : [];
        } catch (error) {
            console.warn('تعذر قراءة بيانات ' + key, error);
            return [];
        }
    }

    function saleIdentity(sale, fallback) {
        if (!sale || typeof sale !== 'object') return fallback;
        const fields = ['id', 'invoiceId', 'invoiceNo', 'invoiceNumber', 'saleId', 'transactionId'];
        for (const field of fields) {
            const value = sale[field];
            if (value !== undefined && value !== null && String(value).trim() !== '') {
                return field + ':' + String(value).trim();
            }
        }
        return fallback;
    }

    function getUnifiedSales() {
        const archived = readAdminArray('maqlis_sales_archive');
        const active = readAdminArray('maqlis_sales');
        const byIdentity = new Map();
        archived.forEach((sale, index) => byIdentity.set(saleIdentity(sale, 'archive:' + index), sale));
        active.forEach((sale, index) => byIdentity.set(saleIdentity(sale, 'active:' + index), sale));
        return Array.from(byIdentity.values());
    }

    function saleDateKey(sale) {
        if (!sale || !sale.date) return '';
        const date = new Date(sale.date);
        return Number.isNaN(date.getTime()) ? '' : date.toISOString().slice(0, 10);
    }

    function saleTotal(sale) {
        const value = Number(sale && sale.total);
        return Number.isFinite(value) ? value : 0;
    }

    function saleItems(sale) {
        return sale && Array.isArray(sale.items) ? sale.items : [];
    }

    function saleItemCount(sale) {
        return saleItems(sale).reduce((sum, item) => sum + (Number(item && item.qty) || 0), 0);
    }

    function saleProfit(sale) {
        return saleItems(sale).reduce((sum, item) => {
            const price = Number(item && item.price) || 0;
            const cost = Number(item && item.costPrice) || 0;
            const qty = Number(item && item.qty) || 0;
            return sum + ((price - cost) * qty);
        }, 0);
    }

    function isAdminPanelRole(role) {
        return role === 'admin' || role === 'inventory';
    }

    if (!localStorage.getItem('maqlis_users')) {
        localStorage.setItem('maqlis_users', JSON.stringify([{
            id: 1, name: 'المدير العام', username: 'admin', password: '123456', role: 'admin',
            permissions: {
                canReceivePayment: true, printReceipt: true, printBarcode: true, useBarcode: true,
                allowReturn: true, allowManualReturn: true, applyDiscount: true, viewReports: true
            }
        }]));
    }

    window.login = function() {
        const user = document.getElementById('loginUser').value.trim();
        const pass = document.getElementById('loginPass').value.trim();
        const users = readAdminArray('maqlis_users');
        const found = users.find(u => u && u.username === user && u.password === pass);
        const errorBox = document.getElementById('loginError');
        if (errorBox) errorBox.style.display = 'none';

        if (!found) {
            if (errorBox) errorBox.style.display = 'block';
            return;
        }

        if (found.role === 'cashier') {
            alert('أنت مسجل كـ كاشير. سيتم تحويلك إلى نظام الكاشير.');
            window.location.href = 'الكاشير.html';
            return;
        }

        if (!isAdminPanelRole(found.role)) {
            alert('هذا الحساب غير مخوّل بدخول لوحة الإدارة. يرجى استخدام الواجهة المخصصة لدورك.');
            return;
        }

        localStorage.setItem('maqlis_currentUser', JSON.stringify(found));
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('app-container').style.display = 'flex';
        document.getElementById('currentUserName').textContent = found.name || found.username;
        initApp();
    };

    window.logout = function() {
        localStorage.removeItem('maqlis_currentUser');
        document.getElementById('app-container').style.display = 'none';
        document.getElementById('login-screen').style.display = 'flex';
        document.getElementById('loginPass').value = '';
    };

    window.onload = function() {
        let session = null;
        try { session = JSON.parse(localStorage.getItem('maqlis_currentUser') || 'null'); }
        catch (error) { session = null; }

        if (!session) return;
        const users = readAdminArray('maqlis_users');
        const currentUser = users.find(user => user && (
            (session.id !== undefined && String(user.id) === String(session.id)) ||
            (session.username && user.username === session.username)
        ));

        if (!currentUser || !isAdminPanelRole(currentUser.role)) {
            localStorage.removeItem('maqlis_currentUser');
            document.getElementById('app-container').style.display = 'none';
            document.getElementById('login-screen').style.display = 'flex';
            return;
        }

        localStorage.setItem('maqlis_currentUser', JSON.stringify(currentUser));
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('app-container').style.display = 'flex';
        document.getElementById('currentUserName').textContent = currentUser.name || currentUser.username;
        initApp();
    };

    window.switchPage = function(pageId, menuElement) {
        const targetPage = document.getElementById(pageId);
        if (!targetPage) {
            console.error('Page not found:', pageId);
            return false;
        }
        document.querySelectorAll('#app-container .page').forEach(page => {
            page.classList.toggle('active', page.id === pageId);
        });
        document.querySelectorAll('.sidebar .menu-item[data-page]').forEach(item => {
            item.classList.toggle('active', item.getAttribute('data-page') === pageId);
        });
        if (menuElement && menuElement.classList && menuElement.classList.contains('menu-item')) {
            menuElement.classList.add('active');
        }
        const title = document.getElementById('mobilePageTitle');
        const activeMenu = document.querySelector('.sidebar .menu-item[data-page="' + pageId + '"]');
        if (title && activeMenu) {
            const label = activeMenu.querySelector('span:not(.alert-count)');
            title.textContent = label ? label.textContent.trim() : pageId;
        }
        return true;
    };

    function initApp() {
        window.autoArchiveOnLogin();

        let sales = JSON.parse(localStorage.getItem('maqlis_sales')) || [];
        let updated = false;
        sales.forEach(s => { if (!s.source) { s.source = 'pos'; updated = true; } });
        if (updated) localStorage.setItem('maqlis_sales', JSON.stringify(sales));

        window.initSwatches();
        window.renderInventoryTable();
        window.renderUsers();
        window.renderCouriers();
        window.renderSales();
        window.populateCashierFilter();
        window.updateDashboard();
        window.populateShiftCashierFilter();
        window.renderShifts();
        window.updateShiftsAlertBadge();

        window.populateMovementFilters();
        window.renderStockMovements();

        window.refreshAdminSystemMonitor(false);
        window.refreshAdminLinkedViews = function(changedKey) {
            if (!changedKey) { window.renderCourierOpsPanel(); window.updateDashboard(); window.refreshAdminSystemMonitor(false); return; }
            const keys = changedKey === '*' ? ['maqlis_inventory','maqlis_sales','maqlis_pickup_orders','maqlis_couriers','maqlis_courier_deliveries','maqlis_users','maqlis_stock_movements','maqlis_shifts','maqlis_sales_archive'] : [changedKey];
            const has = key => keys.includes(key);
            if (has('maqlis_inventory')) { window.renderInventoryTable(); }
            if (has('maqlis_users')) { window.renderUsers(); window.renderCouriers(); }
            if (has('maqlis_couriers')) { window.renderCouriers(); }
            if (has('maqlis_sales')) { window.renderSales(); window.populateCashierFilter(); window.renderShifts(); window.updateShiftsAlertBadge(); }
            if (has('maqlis_shifts')) { window.renderShifts(); window.updateShiftsAlertBadge(); }
            if (has('maqlis_stock_movements')) { window.populateMovementFilters(); window.renderStockMovements(); }
            if (has('maqlis_pickup_orders') || has('maqlis_courier_deliveries') || has('maqlis_couriers') || has('maqlis_inventory') || has('maqlis_sales') || has('maqlis_sales_archive')) {
                window.renderCourierOpsPanel(); window.updateDashboard(); window.refreshAdminSystemMonitor(false);
            }
        };
        window.addEventListener('storage', function(e) {
            if (!e.key) { window.refreshAdminLinkedViews('*'); return; }
            if (['maqlis_inventory','maqlis_sales','maqlis_pickup_orders','maqlis_couriers','maqlis_courier_deliveries','maqlis_users','maqlis_stock_movements','maqlis_shifts','maqlis_sales_archive'].includes(e.key)) window.refreshAdminLinkedViews(e.key);
        });
        window.addEventListener('focus', function() { window.refreshAdminLinkedViews(); });
        document.addEventListener('visibilitychange', function() { if (!document.hidden) window.refreshAdminLinkedViews(); });
        if (window.__maqlisAdminSyncTimer) clearInterval(window.__maqlisAdminSyncTimer);
        window.__maqlisAdminSyncTimer = setInterval(function() {
            if (!document.hidden && document.getElementById('app-container') && document.getElementById('app-container').style.display !== 'none') window.refreshAdminLinkedViews();
        }, 12000);
    }

    let revenueChartInstance = null, sourceChartInstance = null;
    let currentQuickFilter = 'all';
    let currentSalesFilter = 'all';

    window.setQuickFilter = function(range, btn) {
        currentQuickFilter = range;
        document.querySelectorAll('.qf-btn').forEach(b => { if (!b.classList.contains('sales-date-quick')) b.classList.remove('active'); });
        if (btn) btn.classList.add('active');
        const now = new Date();
        const today = now.toISOString().split('T')[0];
        const fromInput = document.getElementById('filterFromDate');
        const toInput = document.getElementById('filterToDate');
        if (range === 'all') { fromInput.value = ''; toInput.value = ''; }
        else if (range === 'today') { fromInput.value = today; toInput.value = today; }
        else if (range === 'week') { const past = new Date(now); past.setDate(past.getDate() - 7); fromInput.value = past.toISOString().split('T')[0]; toInput.value = today; }
        else if (range === 'month') { fromInput.value = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0]; toInput.value = today; }
        else if (range === 'year') { fromInput.value = new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0]; toInput.value = today; }
        window.updateDashboard();
    };

    window.clearQuickFilter = function() {
        currentQuickFilter = '';
        document.querySelectorAll('.qf-btn').forEach(b => b.classList.remove('active'));
    };

    window.resetFilters = function() {
        document.getElementById('filterFromDate').value = '';
        document.getElementById('filterToDate').value = '';
        document.getElementById('filterSource').value = 'all';
        document.querySelectorAll('.qf-btn').forEach(b => b.classList.remove('active'));
        document.querySelector('.qf-btn[data-range="all"]').classList.add('active');
        window.updateDashboard();
    };

    function getPreviousPeriodSales(sales, fromDate, toDate) {
        if (!fromDate || !toDate) return [];
        const from = new Date(fromDate);
        const to = new Date(toDate);
        const diffMs = to - from;
        const prevTo = new Date(from.getTime() - 1);
        const prevFrom = new Date(prevTo.getTime() - diffMs);
        return sales.filter(s => { const d = new Date(s.date); return d >= prevFrom && d <= prevTo; });
    }

    function calcTrend(current, previous) {
        if (previous === 0) return current > 0 ? { value: 100, dir: 'up' } : { value: 0, dir: 'neutral' };
        const diff = ((current - previous) / previous) * 100;
        return { value: Math.abs(diff).toFixed(1), dir: diff > 0 ? 'up' : (diff < 0 ? 'down' : 'neutral') };
    }

    function setTrendElement(elId, trend) {
        const el = document.getElementById(elId);
        if (!el) return;
        let icon = 'fa-minus'; let cls = 'neutral'; let text = 'ثابت';
        if (trend.dir === 'up') { icon = 'fa-arrow-up'; cls = 'up'; text = '+' + trend.value + '%'; }
        else if (trend.dir === 'down') { icon = 'fa-arrow-down'; cls = 'down'; text = '-' + trend.value + '%'; }
        el.className = 'kpi-trend ' + cls;
        el.innerHTML = '<i class="fa-solid ' + icon + '"></i> ' + text;
    }

    window.renderCourierOpsPanel = function() {
        const orders = JSON.parse(localStorage.getItem('maqlis_pickup_orders') || '[]');
        const deliveries = JSON.parse(localStorage.getItem('maqlis_courier_deliveries') || '[]');
        const couriers = JSON.parse(localStorage.getItem('maqlis_couriers') || '[]');
        const active = orders.filter(o => ['ready', 'picked_up', 'delivered'].includes(o.status));
        const unsettled = deliveries.filter(d => !d.settled);
        const remit = unsettled.reduce((sum, d) => sum + (Number(d.cashToCashier != null ? d.cashToCashier : d.amount) || 0), 0);
        const fees = deliveries.reduce((sum, d) => sum + (Number(d.deliveryFee) || 0), 0);

        const brief = document.getElementById('courierSummaryBrief');
        if (brief) {
            brief.textContent = 'سائقون: ' + couriers.length + ' • طلبات نشطة: ' + active.length + ' • توريد غير مسوّى: ' + remit.toLocaleString() + ' ر.ي';
        }

        const stats = document.getElementById('courierOpsStats');
        const rows = document.getElementById('courierOpsRows');
        if (!stats || !rows) return;
        const cards = [
            ['طلبات نشطة', active.length, '#1d4ed8'],
            ['توصيلات مسجلة', deliveries.length, '#0f766e'],
            ['أجور الموصلين', fees.toLocaleString() + ' ر.ي', '#047857'],
            ['مبالغ لم تُورّد للكاشير', remit.toLocaleString() + ' ر.ي', '#b45309']
        ];
        stats.innerHTML = cards.map(c => `<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px;"><div style="font-size:11px;color:#64748b;margin-bottom:6px;">${c[0]}</div><strong style="font-size:20px;color:${c[2]};">${c[1]}</strong></div>`).join('');
        const grouped = {};
        deliveries.forEach(d => {
            const id = String(d.courierId || 'unknown');
            if (!grouped[id]) grouped[id] = { name: d.courierName || 'موصل غير معروف', count: 0, fees: 0, remit: 0 };
            grouped[id].count++;
            grouped[id].fees += Number(d.deliveryFee) || 0;
            if (!d.settled) grouped[id].remit += Number(d.cashToCashier != null ? d.cashToCashier : d.amount) || 0;
        });
        couriers.forEach(c => { const id = String(c.id); if (!grouped[id]) grouped[id] = { name: c.name, count: 0, fees: 0, remit: 0 }; });
        const list = Object.values(grouped);
        rows.innerHTML = list.length ? list.map(c => `<tr style="border-top:1px solid #e2e8f0;"><td style="padding:10px;font-weight:800;">${courierEscape(c.name)}</td><td style="padding:10px;">${c.count}</td><td style="padding:10px;color:#047857;font-weight:800;">${c.fees.toLocaleString()} ر.ي</td><td style="padding:10px;color:#b45309;font-weight:800;">${c.remit.toLocaleString()} ر.ي</td></tr>`).join('') : '<tr><td colspan="4" style="padding:14px;text-align:center;color:#64748b;">لا توجد بيانات توصيل</td></tr>';
    };

    window.updateDashboard = function() {
        const fromDate = document.getElementById('filterFromDate').value;
        const toDate = document.getElementById('filterToDate').value;
        const source = document.getElementById('filterSource').value;
        const allSales = getUnifiedSales();

        const filteredSales = allSales.filter(sale => {
            const sd = saleDateKey(sale);
            if (!sd) return false;
            const matchDate = (!fromDate || sd >= fromDate) && (!toDate || sd <= toDate);
            const matchSource = source === 'all' || (sale.source || 'pos') === source;
            return matchDate && matchSource;
        });

        const prevSales = (fromDate && toDate)
            ? getPreviousPeriodSales(allSales.filter(sale => !!saleDateKey(sale)), fromDate, toDate)
                .filter(sale => source === 'all' || (sale.source || 'pos') === source)
            : [];

        const totalRevenue = filteredSales.reduce((sum, sale) => sum + saleTotal(sale), 0);
        const totalProfit = filteredSales.reduce((sum, sale) => sum + saleProfit(sale), 0);
        const totalOrders = filteredSales.length;
        const totalItems = filteredSales.reduce((sum, sale) => sum + saleItemCount(sale), 0);
        const totalReturns = Math.abs(filteredSales.filter(sale => sale.source === 'return').reduce((sum, sale) => sum + saleTotal(sale), 0));

        const prevRevenue = prevSales.reduce((sum, sale) => sum + saleTotal(sale), 0);
        const prevProfit = prevSales.reduce((sum, sale) => sum + saleProfit(sale), 0);
        const prevOrders = prevSales.length;
        const prevItems = prevSales.reduce((sum, sale) => sum + saleItemCount(sale), 0);

        document.getElementById('statRevenue').textContent = totalRevenue.toLocaleString() + ' ر.ي';
        document.getElementById('statProfit').textContent = totalProfit.toLocaleString() + ' ر.ي';
        document.getElementById('statOrders').textContent = totalOrders.toLocaleString();
        document.getElementById('statItems').textContent = totalItems.toLocaleString();
        document.getElementById('statReturns').textContent = totalReturns.toLocaleString() + ' ر.ي';

        setTrendElement('trendRevenue', calcTrend(totalRevenue, prevRevenue));
        setTrendElement('trendProfit', calcTrend(totalProfit, prevProfit));
        setTrendElement('trendOrders', calcTrend(totalOrders, prevOrders));
        setTrendElement('trendItems', calcTrend(totalItems, prevItems));

        document.getElementById('sumGross').textContent = totalRevenue.toLocaleString() + ' ر.ي';
        document.getElementById('sumProfit').textContent = totalProfit.toLocaleString() + ' ر.ي';

        const posRev = filteredSales.filter(sale => (sale.source || 'pos') === 'pos').reduce((sum, sale) => sum + saleTotal(sale), 0);
        const onlineRev = filteredSales.filter(sale => sale.source === 'online').reduce((sum, sale) => sum + saleTotal(sale), 0);

        const groupedByDate = {};
        filteredSales.forEach(sale => {
            const iso = saleDateKey(sale);
            if (iso) groupedByDate[iso] = (groupedByDate[iso] || 0) + saleTotal(sale);
        });
        const sortedDates = Object.keys(groupedByDate).sort();
        const labels = sortedDates.map(date => new Date(date).toLocaleDateString('ar-EG', { day: 'numeric', month: 'short' }));
        const data = sortedDates.map(date => groupedByDate[date]);

        window.renderCharts(posRev, onlineRev, labels, data);
        window.renderPaymentMethodsStats();
        window.renderCourierOpsPanel();
        if (window.refreshAdminSystemMonitor) window.refreshAdminSystemMonitor(false);
    };

    window.renderCharts = function(posRev, onlineRev, labels, data) {
        Chart.defaults.font.family = "'Cairo', sans-serif";
        Chart.defaults.color = '#8B94A3';

        const revCtx = document.getElementById('revenueChart').getContext('2d');
        if (revenueChartInstance) revenueChartInstance.destroy();
        const gradient = revCtx.createLinearGradient(0, 0, 0, 320);
        gradient.addColorStop(0, 'rgba(201, 169, 97, 0.4)');
        gradient.addColorStop(1, 'rgba(201, 169, 97, 0)');
        revenueChartInstance = new Chart(revCtx, {
            type: 'line',
            data: { labels: labels.length ? labels : ['لا توجد بيانات'], datasets: [{ label: 'الإيرادات', data: data.length ? data : [0], borderColor: '#C9A961', backgroundColor: gradient, borderWidth: 3, tension: 0.4, fill: true, pointBackgroundColor: '#C9A961', pointBorderColor: '#fff', pointBorderWidth: 2, pointRadius: 5, pointHoverRadius: 8 }] },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { padding: 12, backgroundColor: '#1F1B18', cornerRadius: 8 } }, scales: { y: { beginAtZero: true, grid: { color: '#F0F4F8', drawBorder: false } }, x: { grid: { display: false } } } }
        });

        const sourceCtx = document.getElementById('sourceChart').getContext('2d');
        if (sourceChartInstance) sourceChartInstance.destroy();
        sourceChartInstance = new Chart(sourceCtx, {
            type: 'doughnut',
            data: { labels: ['الكاشير', 'الأونلاين'], datasets: [{ data: [posRev, onlineRev], backgroundColor: ['#C9A961', '#3182CE'], borderWidth: 5, borderColor: '#fff', hoverOffset: 8 }] },
            options: { responsive: true, maintainAspectRatio: false, cutout: '75%', plugins: { legend: { position: 'bottom', labels: { padding: 20, font: { size: 13, weight: '600' }, usePointStyle: true, pointStyle: 'circle' } } } }
        });
    };

    window.renderPaymentMethodsStats = function() {
        const container = document.getElementById('paymentMethodsStats');
        if (!container) return;
        const fromDate = document.getElementById('filterFromDate')?.value || '';
        const toDate = document.getElementById('filterToDate')?.value || '';
        const sourceFilter = document.getElementById('filterSource')?.value || 'all';
        const allSales = getUnifiedSales();

        const filtered = allSales.filter(s => {
            const sd = saleDateKey(s);
            if (!sd) return false;
            let matchDate = true;
            if (fromDate) matchDate = matchDate && (sd >= fromDate);
            if (toDate) matchDate = matchDate && (sd <= toDate);
            const matchSource = sourceFilter === 'all' || (s.source || 'pos') === sourceFilter;
            return matchDate && matchSource;
        });

        const methods = {};
        filtered.forEach(s => {
            if (saleTotal(s) <= 0 || s.source === 'return') return;
            const method = s.paymentMethod || 'غير محدد';
            if (!methods[method]) methods[method] = { count: 0, total: 0 };
            methods[method].count++;
            methods[method].total += saleTotal(s);
        });

        if (Object.keys(methods).length === 0) {
            container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--muted); grid-column:1/-1;">لا توجد مبيعات في الفترة المحددة</div>';
            return;
        }

        const methodStyles = {
            'نقدي': { icon: '💵', color: '#059669', bg: '#DEF7EC' },
            'جيب': { icon: '💳', color: '#0284C7', bg: '#DBEAFE' },
            'كريمي': { icon: '🏦', color: '#7C3AED', bg: '#EDE9FE' },
            'فلوسك': { icon: '🪙', color: '#D97706', bg: '#FEF3C7' },
            'جوالي': { icon: '📱', color: '#DC2626', bg: '#FEE2E2' },
            'موبايل موني': { icon: '📲', color: '#EA580C', bg: '#FFEDD5' }
        };

        const grandTotal = Object.values(methods).reduce((sum, m) => sum + m.total, 0);
        container.innerHTML = Object.entries(methods).sort((a, b) => b[1].total - a[1].total).map(([method, data]) => {
            const style = methodStyles[method] || { icon: '💳', color: '#64748B', bg: '#F1F5F9' };
            const percentage = grandTotal > 0 ? ((data.total / grandTotal) * 100).toFixed(1) : 0;
            return '<div style="background: ' + style.bg + '; border: 1.5px solid ' + style.color + '30; border-radius: 12px; padding: 14px;">' +
                '<div style="display: flex; align-items: center; gap: 6px; margin-bottom: 8px;">' +
                    '<span style="font-size: 18px;">' + style.icon + '</span>' +
                    '<span style="font-weight: 800; font-size: 13px; color: ' + style.color + ';">' + method + '</span>' +
                '</div>' +
                '<div style="font-size: 20px; font-weight: 900; color: ' + style.color + '; line-height: 1.2;">' +
                    data.total.toLocaleString() + ' <span style="font-size: 11px;">ر.ي</span>' +
                '</div>' +
                '<div style="font-size: 11px; color: ' + style.color + 'BB; margin-top: 4px; font-weight: 600;">' +
                    data.count + ' عملية • ' + percentage + '%' +
                '</div>' +
            '</div>';
        }).join('');
    };

    window.printFinancialReport = function() {
        const fromDate = document.getElementById('filterFromDate').value || 'البداية';
        const toDate = document.getElementById('filterToDate').value || 'النهاية';
        const selectedSource = document.getElementById('filterSource').value;
        const allSales = getUnifiedSales();
        const filtered = allSales.filter(sale => {
            const sd = saleDateKey(sale);
            if (!sd) return false;
            const matchDate = (fromDate === 'البداية' || sd >= fromDate) && (toDate === 'النهاية' || sd <= toDate);
            const matchSource = selectedSource === 'all' || (sale.source || 'pos') === selectedSource;
            return matchDate && matchSource;
        });
        const totalRevenue = filtered.reduce((sum, sale) => sum + saleTotal(sale), 0);
        const totalProfit = filtered.reduce((sum, sale) => sum + saleProfit(sale), 0);
        const totalInvoices = filtered.length;
        const totalItems = filtered.reduce((sum, sale) => sum + saleItemCount(sale), 0);

        const escapeHTML = value => String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
        }[ch]));
        const printArea = document.getElementById('print-area');
        printArea.innerHTML = '<h1>التقرير المالي - بوتيك مقليس</h1>' +
            '<div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:15px;background:#f8f8f8;margin-bottom:20px;border-radius:8px;">' +
                '<div><strong>من:</strong> ' + escapeHTML(fromDate) + '</div>' +
                '<div><strong>إلى:</strong> ' + escapeHTML(toDate) + '</div>' +
                '<div><strong>التاريخ:</strong> ' + new Date().toLocaleDateString('ar-EG') + '</div>' +
            '</div>' +
            '<div style="display:flex;gap:20px;flex-wrap:wrap;margin:12px 0;font-weight:800;">' +
                '<span>عدد الفواتير: ' + totalInvoices.toLocaleString() + '</span>' +
                '<span>عدد القطع: ' + totalItems.toLocaleString() + '</span>' +
                '<span>مصدر البيانات: السجل الحالي والأرشيف دون تكرار</span>' +
            '</div>' +
            '<table style="width:100%;border-collapse:collapse;margin-top:20px;">' +
                '<tr style="background:#f0f0f0;"><th style="border:1px solid #ddd;padding:10px;">الفاتورة</th><th style="border:1px solid #ddd;padding:10px;">التاريخ</th><th style="border:1px solid #ddd;padding:10px;">المصدر</th><th style="border:1px solid #ddd;padding:10px;">الكاشير</th><th style="border:1px solid #ddd;padding:10px;">القطع</th><th style="border:1px solid #ddd;padding:10px;">الإجمالي</th></tr>' +
                filtered.map(sale => {
                    const sourceLabel = (sale.source || 'pos') === 'pos' ? 'كاشير' : (sale.source === 'online' ? 'أونلاين' : 'مرتجع');
                    const dateLabel = sale.date && !Number.isNaN(new Date(sale.date).getTime()) ? new Date(sale.date).toLocaleDateString('ar-EG') : '—';
                    return '<tr><td style="border:1px solid #ddd;padding:10px;">' + escapeHTML(sale.id || sale.invoiceNo || sale.invoiceNumber || '—') + '</td>' +
                        '<td style="border:1px solid #ddd;padding:10px;">' + escapeHTML(dateLabel) + '</td>' +
                        '<td style="border:1px solid #ddd;padding:10px;">' + sourceLabel + '</td>' +
                        '<td style="border:1px solid #ddd;padding:10px;">' + escapeHTML(sale.cashier || '—') + '</td>' +
                        '<td style="border:1px solid #ddd;padding:10px;">' + saleItemCount(sale).toLocaleString() + '</td>' +
                        '<td style="border:1px solid #ddd;padding:10px;">' + saleTotal(sale).toLocaleString() + ' ر.ي</td></tr>';
                }).join('') +
            '</table>' +
            '<div style="margin-top:30px;padding:20px;background:#F8FAFC;border-radius:10px;display:flex;flex-direction:column;gap:10px;">' +
                '<div style="display:flex;justify-content:space-between;font-size:20px;font-weight:900;color:#C9A961;"><strong>إجمالي الإيرادات:</strong><span>' + totalRevenue.toLocaleString() + ' ر.ي</span></div>' +
                '<div style="display:flex;justify-content:space-between;font-size:20px;font-weight:900;color:#38A169;"><strong>صافي الربح:</strong><span>' + totalProfit.toLocaleString() + ' ر.ي</span></div>' +
            '</div>';
        setTimeout(() => window.print(), 200);
    };

    /* ===== USERS ===== */
    window.addUser = function() {
        const name = document.getElementById('uName').value.trim();
        const username = document.getElementById('uUsername').value.trim();
        const password = document.getElementById('uPassword').value.trim();
        const role = document.getElementById('uRole').value;

        if (!name || !username || !password) return alert('الرجاء تعبئة جميع الحقول');

        let users = JSON.parse(localStorage.getItem('maqlis_users')) || [];
        if (users.find(u => u.username === username)) return alert('اسم المستخدم موجود مسبقاً!');

        const defaultPerms = {
            canReceivePayment: role === 'admin' || role === 'cashier',
            printReceipt: role !== 'inventory',
            printBarcode: role === 'admin' || role === 'inventory',
            useBarcode: true,
            allowReturn: role !== 'inventory',
            allowManualReturn: role !== 'inventory',
            applyDiscount: role !== 'inventory',
            viewReports: role === 'admin' || role === 'inventory'
        };

        users.push({ id: Date.now(), name, username, password, role, permissions: defaultPerms });
        localStorage.setItem('maqlis_users', JSON.stringify(users));
        alert('✅ تم إضافة المستخدم');
        document.getElementById('uName').value = ''; document.getElementById('uUsername').value = ''; document.getElementById('uPassword').value = '';
        window.renderUsers();
    };

    /* ===== COURIERS ===== */
    function courierEscape(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, function(ch) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch];
        });
    }

    window.addCourierAccount = function() {
        const name = document.getElementById('courierNameInput').value.trim();
        const phone = document.getElementById('courierPhoneInput').value.trim();
        const username = document.getElementById('courierUsernameInput').value.trim();
        const password = document.getElementById('courierPasswordInput').value.trim();
        const areas = document.getElementById('courierAreasInput').value.split(/[،,]/).map(x => x.trim()).filter(Boolean);
        if (!name || !username || !password) return alert('أدخل اسم الموصل واسم المستخدم وكلمة المرور');
        if (password.length < 4) return alert('كلمة المرور يجب ألا تقل عن 4 أحرف أو أرقام');
        const users = JSON.parse(localStorage.getItem('maqlis_users') || '[]');
        if (users.some(u => u.username.toLowerCase() === username.toLowerCase())) return alert('اسم المستخدم موجود مسبقاً');
        const userId = Date.now();
        const courierId = 'CR-' + userId;
        users.push({ id: userId, name, username, password, role: 'courier', permissions: {}, createdAt: new Date().toISOString() });
        const couriers = JSON.parse(localStorage.getItem('maqlis_couriers') || '[]');
        couriers.push({ id: courierId, userId, name, phone, areas, active: true, createdAt: new Date().toISOString() });
        localStorage.setItem('maqlis_users', JSON.stringify(users));
        localStorage.setItem('maqlis_couriers', JSON.stringify(couriers));
        ['courierNameInput', 'courierPhoneInput', 'courierUsernameInput', 'courierPasswordInput', 'courierAreasInput'].forEach(id => document.getElementById(id).value = '');
        window.renderCouriers();
        window.renderUsers();
        window.renderCourierOpsPanel();
        alert('تم إنشاء حساب الموصل بنجاح. يمكنه الآن الدخول من صفحة الموصلين.');
    };

    window.deleteCourierAccount = function(courierId) {
        const couriers = JSON.parse(localStorage.getItem('maqlis_couriers') || '[]');
        const courier = couriers.find(c => String(c.id) === String(courierId));
        if (!courier) return;
        const deliveries = JSON.parse(localStorage.getItem('maqlis_courier_deliveries') || '[]');
        const orders = JSON.parse(localStorage.getItem('maqlis_pickup_orders') || '[]');
        const hasHistory = deliveries.some(d => String(d.courierId) === String(courierId)) || orders.some(o => String(o.courierId) === String(courierId) || String(o.lastCourierId) === String(courierId));
        const promptText = hasHistory
            ? 'لدى هذا الموصل طلبات أو سجلات توصيل مرتبطة. سيتم إيقاف حسابه وإخفاؤه من التشغيل النشط مع الاحتفاظ بسجلاته المالية والتاريخية. هل تريد المتابعة؟'
            : 'لا توجد سجلات مرتبطة بهذا الموصل. هل تريد حذف حسابه نهائياً؟';
        if (!confirm(promptText)) return;
        if (hasHistory) {
            courier.active = false;
            localStorage.setItem('maqlis_couriers', JSON.stringify(couriers));
            const users = JSON.parse(localStorage.getItem('maqlis_users') || '[]');
            const user = users.find(u => String(u.id) === String(courier.userId));
            if (user) user.active = false;
            localStorage.setItem('maqlis_users', JSON.stringify(users));
            window.showToast('تم إيقاف الموصل مع الاحتفاظ بسجلاته السابقة', 'success');
        } else {
            localStorage.setItem('maqlis_couriers', JSON.stringify(couriers.filter(c => String(c.id) !== String(courierId))));
            const users = JSON.parse(localStorage.getItem('maqlis_users') || '[]');
            localStorage.setItem('maqlis_users', JSON.stringify(users.filter(u => String(u.id) !== String(courier.userId))));
            window.showToast('تم حذف حساب الموصل', 'success');
        }
        window.renderCouriers(); window.renderUsers(); window.renderCourierOpsPanel(); window.refreshAdminSystemMonitor(false);
    };

    window.renderCouriers = function() {
        const tbody = document.querySelector('#couriersTable tbody');
        if (!tbody) return;
        const couriers = JSON.parse(localStorage.getItem('maqlis_couriers') || '[]');
        const users = JSON.parse(localStorage.getItem('maqlis_users') || '[]');
        if (!couriers.length) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:22px;color:var(--muted);">لا يوجد موصلون حتى الآن</td></tr>';
            return;
        }
        tbody.innerHTML = couriers.map(c => {
            const user = users.find(u => u.id === c.userId);
            return '<tr><td><b>' + courierEscape(c.name) + '</b>' + (c.active === false ? '<div style="margin-top:4px;font-size:10px;color:#b45309;font-weight:800;">موقوف — محفوظ في السجلات</div>' : '') + '</td><td>' + courierEscape(c.phone || '—') + '</td><td style="font-family:monospace;">' + courierEscape(user ? user.username : 'حساب غير مرتبط') + '</td><td>' + courierEscape((c.areas || []).join('، ') || '—') + '</td><td><button class="btn btn-danger" style="padding:6px 12px;font-size:12px;" onclick="window.deleteCourierAccount(' + JSON.stringify(c.id) + ')"><i class="fa-solid fa-trash"></i> حذف / إيقاف</button></td></tr>';
        }).join('');
    };

    window.deleteUser = function(id) {
        let currentUser = null;
        try { currentUser = JSON.parse(localStorage.getItem('maqlis_currentUser') || 'null'); } catch (error) {}
        if (currentUser && String(currentUser.id) === String(id)) {
            window.showToast('لا يمكن حذف الحساب المستخدم حالياً. سجّل الخروج أولاً أو استخدم حساب مدير آخر.', 'error');
            return;
        }
        if (!confirm('حذف هذا المستخدم؟')) return;
        const users = readAdminArray('maqlis_users').filter(user => String(user.id) !== String(id));
        localStorage.setItem('maqlis_users', JSON.stringify(users));
        window.renderUsers();
    };

    window.renderUsers = function() {
        const users = JSON.parse(localStorage.getItem('maqlis_users')) || [];
        const tbody = document.querySelector('#usersTable tbody');
        tbody.innerHTML = '';

        users.forEach(u => {
            let roleName, roleClass;
            if (u.role === 'admin') { roleName = 'مدير'; roleClass = 'badge-admin'; }
            else if (u.role === 'inventory') { roleName = 'مخزون'; roleClass = 'badge-inventory'; }
            else if (u.role === 'courier') { roleName = 'موصل'; roleClass = 'badge-cashier'; }
            else if (u.role === 'cashier') {
                const canReceive = u.permissions && u.permissions.canReceivePayment;
                if (canReceive) { roleName = '💵 كاشير رئيسي'; roleClass = 'badge-main-cashier'; }
                else { roleName = '🛍️ كاشير فرعي'; roleClass = 'badge-sub-cashier'; }
            } else { roleName = u.role; roleClass = 'badge-cashier'; }

            const permCount = u.permissions ? Object.values(u.permissions).filter(v => v === true).length : 0;
            const totalPerms = u.permissions ? Object.keys(u.permissions).length : 8;

            tbody.innerHTML += '<tr>' +
                '<td data-label="الاسم"><b>' + u.name + '</b></td>' +
                '<td data-label="المستخدم" style="font-family: monospace;">' + u.username + '</td>' +
                '<td data-label="الصلاحية">' +
                    '<span class="badge ' + roleClass + '">' + roleName + '</span>' +
                    '<div style="font-size:11px; color:var(--muted); margin-top:4px;">' + permCount + '/' + totalPerms + ' صلاحية</div>' +
                '</td>' +
                '<td data-label="إجراءات" style="text-align:center;">' +
                    '<button class="btn" style="padding: 6px 14px; font-size: 12px; background: var(--blue); color: white; margin-left: 4px;" onclick="window.openEditUserModal(' + u.id + ')">' +
                        '<i class="fa-solid fa-pen"></i> تعديل' +
                    '</button>' +
                    (u.username !== 'admin' ? '<button class="btn btn-danger" style="padding: 6px 12px; font-size: 12px;" onclick="window.deleteUser(' + u.id + ')"><i class="fa-solid fa-trash"></i></button>' : '') +
                '</td>' +
            '</tr>';
        });
    };

    const STORE_CATEGORIES = {
        "أحذية": ["كعب", "سبورت", "طبي", "سليبر"],
        "شنط": ["جامعي", "عرائسي", "شنط يد", "شنط سفر", "شنط ظهر"],
        "اكسسوارات": ["خواتم", "اساور", "طقوم", "ساعات"],
        "ملابس": ["فساتين", "بجايم", "طقوم", "بلايز", "بناطيل"],
        "أخرى": ["منتجات أخرى"]
    };

    window.updateAdminSubCategories = function() {
        const mainCat = document.getElementById('pMainCategory').value;
        const subSelect = document.getElementById('pSubCategory');
        subSelect.innerHTML = '<option value="">اختر القسم الفرعي</option>';
        if (mainCat && STORE_CATEGORIES[mainCat]) {
            STORE_CATEGORIES[mainCat].forEach(sub => {
                const option = document.createElement('option');
                option.value = sub; option.textContent = sub;
                subSelect.appendChild(option);
            });
        }
    };

    const availableColors = [{ name: 'أحمر', en: 'RED', hex: '#E53E3E' }, { name: 'أزرق', en: 'BLU', hex: '#3182CE' }, { name: 'أسود', en: 'BLK', hex: '#1A202C' }, { name: 'أبيض', en: 'WHT', hex: '#F7FAFC' }, { name: 'ذهبي', en: 'GLD', hex: '#C9A961' }];
    const availableSizes = ['S', 'M', 'L', 'XL', '36', '37', '38', '39', '40'];
    let selectedColors = [], selectedSizes = [], generatedVariants = [], currentProduct = {};

    window.initSwatches = function() {
        const colorBox = document.getElementById('colorSwatches');
        if (colorBox.children.length > 0) return;
        availableColors.forEach(c => {
            const div = document.createElement('div');
            div.style.cssText = 'width:42px; height:42px; border-radius:50%; cursor:pointer; border:3px solid transparent; background:' + c.hex + '; display:inline-block; margin:5px; transition: 0.2s;';
            if (c.name === 'أبيض') div.style.border = '1px solid #ddd';
            div.onclick = () => {
                const idx = selectedColors.findIndex(sc => sc.name === c.name);
                if (idx > -1) { selectedColors.splice(idx, 1); div.style.border = c.name === 'أبيض' ? '1px solid #ddd' : '3px solid transparent'; div.style.transform = 'scale(1)'; }
                else { selectedColors.push(c); div.style.border = '3px solid #1F1B18'; div.style.transform = 'scale(1.1)'; }
            };
            colorBox.appendChild(div);
        });
        const sizeBox = document.getElementById('sizeSwatches');
        availableSizes.forEach(s => {
            const btn = document.createElement('button');
            btn.className = 'btn';
            btn.style.cssText = 'padding: 9px 18px; margin: 5px; border: 1.5px solid #E8EDF2; background: white; color:#333; border-radius: 10px;';
            btn.textContent = s;
            btn.onclick = () => {
                const idx = selectedSizes.indexOf(s);
                if (idx > -1) { selectedSizes.splice(idx, 1); btn.style.background = 'white'; btn.style.color = '#333'; btn.style.borderColor = '#E8EDF2'; }
                else { selectedSizes.push(s); btn.style.background = '#1F1B18'; btn.style.color = 'white'; btn.style.borderColor = '#1F1B18'; }
            };
            sizeBox.appendChild(btn);
        });
    };

    window.generateMatrix = function() {
        const name = document.getElementById('pName').value.trim();
        const price = document.getElementById('pPrice').value;
        const costPrice = document.getElementById('pCostPrice').value;
        const img = document.getElementById('pImage').value.trim() || 'https://via.placeholder.com/300x400?text=No+Image';
        const maxDiscount = parseInt(document.getElementById('pMaxDiscount').value) || 0;
        const mainCat = document.getElementById('pMainCategory').value;
        const subCat = document.getElementById('pSubCategory').value;

        if (!name || !price || !costPrice || !mainCat || !subCat || selectedColors.length === 0 || selectedSizes.length === 0) {
            return alert('الرجاء إكمال جميع البيانات (بما فيها القسم والسعر)');
        }

        currentProduct = { name, price: Number(price), costPrice: Number(costPrice), image: img, maxDiscount: maxDiscount, mainCategory: mainCat, subCategory: subCat };
        generatedVariants = [];
        const tbody = document.querySelector('#previewTable tbody'); tbody.innerHTML = '';
        selectedColors.forEach(color => {
            const headerTr = document.createElement('tr');
            headerTr.style.cssText = 'background:#F8FAFC;';
            headerTr.innerHTML = '<td colspan="4" style="padding:12px 15px; font-weight:900; color:var(--dark); border-bottom:none;"><span style="display:inline-block;width:16px;height:16px;border-radius:50%;background:' + color.hex + ';vertical-align:middle;margin-left:8px;border:1px solid #ccc;"></span>' + color.name + '</td>';
            tbody.appendChild(headerTr);
            selectedSizes.forEach(size => {
                const sku = 'MQ-' + color.en + '-' + size + '-' + Math.floor(1000 + Math.random() * 9000);
                generatedVariants.push({ ...currentProduct, color: color.name, colorHex: color.hex, size, sku, qty: 1, dateAdded: new Date().toISOString() });
                const tr = document.createElement('tr');
                tr.innerHTML = '<td data-label="المقاس" style="padding-right:35px; color:#555;">↳ ' + size + '</td>' +
                    '<td data-label="SKU" style="font-family:monospace; font-size:12px;">' + sku + '</td>' +
                    '<td data-label="الكمية"><input type="number" class="qty-input form-control" style="width:90px; padding:8px; text-align:center; font-weight:bold; font-size:16px;" value="1" min="0"></td>' +
                    '<td data-label="الباركود"><svg class="barcode-svg" data-sku="' + sku + '"></svg></td>';
                tbody.appendChild(tr);
            });
        });
        document.getElementById('previewCard').style.display = 'block';
        document.querySelectorAll('.barcode-svg').forEach(svg => JsBarcode(svg, svg.dataset.sku, { format: "CODE128", width: 1.5, height: 40, displayValue: true, fontSize: 12, margin: 5 }));
        document.querySelectorAll('.qty-input').forEach(input => input.addEventListener('input', window.updateTotalPreview));
        window.updateTotalPreview();
    };

    window.fillAll = function() {
        const qty = parseInt(document.getElementById('bulkQty').value) || 0;
        document.querySelectorAll('.qty-input').forEach(input => input.value = qty);
        window.updateTotalPreview();
    };

    window.updateTotalPreview = function() {
        let total = 0;
        document.querySelectorAll('.qty-input').forEach(input => {
            const val = parseInt(input.value) || 0;
            total += val;
            input.style.borderColor = val === 0 ? 'var(--danger)' : 'var(--border)';
            input.style.background = val === 0 ? '#FED7D7' : 'white';
        });
        document.getElementById('totalPreviewQty').textContent = total;
    };

    window.saveToInventory = function() {
        if (generatedVariants.length === 0) return;
        const qtyInputs = document.querySelectorAll('.qty-input');
        generatedVariants.forEach((v, i) => v.qty = parseInt(qtyInputs[i].value) || 0);

        const zeroQty = generatedVariants.filter(v => v.qty === 0);
        if (zeroQty.length > 0 && !confirm('لديك ' + zeroQty.length + ' قطعة بكمية صفر. حفظها؟')) {
            generatedVariants = generatedVariants.filter(v => v.qty > 0);
        }
        if (generatedVariants.length === 0) return alert('لا توجد قطع للحفظ!');

        const defaultBoutiqueImage = 'https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?q=80&w=900&auto=format&fit=crop';
        const catMapForMain = { 'أحذية': 'shoes', 'شنط': 'bags', 'اكسسوارات': 'accessories', 'أخرى': 'other' };
        const catMapForClothes = { 'فساتين': 'dresses', 'بجايم': 'casual', 'طقوم': 'casual', 'بلايز': 'casual', 'بناطيل': 'casual' };

        generatedVariants.forEach(v => {
            if (!v.image || v.image.trim() === '' || v.image.includes('placeholder')) v.image = defaultBoutiqueImage;
            if (v.mainCategory === 'ملابس') v.cat = catMapForClothes[v.subCategory] || 'casual';
            else v.cat = catMapForMain[v.mainCategory] || 'other';
            if (v.reserved === undefined) v.reserved = 0;
        });

        let inventory = JSON.parse(localStorage.getItem('maqlis_inventory')) || [];
        localStorage.setItem('maqlis_inventory', JSON.stringify([...inventory, ...generatedVariants]));

        generatedVariants.forEach(v => {
            logStockMovement(v.sku, 'add', v.qty, 0, v.qty, 'ADD-' + Date.now(), 'إضافة منتج جديد');
        });

        alert('✅ تم حفظ المنتجات بنجاح وأصبحت متاحة في الكاشير والمتجر!');

        document.getElementById('previewCard').style.display = 'none';
        document.getElementById('pName').value = ''; document.getElementById('pPrice').value = ''; document.getElementById('pCostPrice').value = ''; document.getElementById('pImage').value = ''; document.getElementById('pMaxDiscount').value = '0'; document.getElementById('pMainCategory').value = ''; document.getElementById('pSubCategory').innerHTML = '<option value="">اختر القسم الفرعي</option>';

        selectedColors = []; selectedSizes = [];
        document.querySelectorAll('#colorSwatches div').forEach(el => { el.style.border = '3px solid transparent'; el.style.transform = 'scale(1)'; });
        document.querySelectorAll('#sizeSwatches button').forEach(el => { el.style.background = 'white'; el.style.color = '#333'; el.style.borderColor = '#E8EDF2'; });

        window.renderInventoryTable();
        window.switchPage('inventory', document.querySelector('[data-page="inventory"]'));
    };

    window.renderInventoryTable = function() {
        const inventory = JSON.parse(localStorage.getItem('maqlis_inventory')) || [];
        const grid = document.getElementById('inventoryGrid');
        const searchInput = document.getElementById('searchInput');
        const search = searchInput ? searchInput.value.toLowerCase() : '';
        grid.innerHTML = '';
        const filtered = inventory.filter(i => i.name.toLowerCase().includes(search) || i.sku.toLowerCase().includes(search));

        if (filtered.length === 0) {
            grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:50px; color:#888;"><i class="fa-solid fa-box-open" style="font-size:40px; margin-bottom:10px; opacity:0.3;"></i><br>لا توجد منتجات مطابقة</div>';
            return;
        }

        filtered.forEach(item => {
            const qty = item.qty || 0;
            const reserved = item.reserved || 0;
            const available = Math.max(0, qty - reserved);
            let statusClass = 'in', statusText = 'متوفر';
            if (qty === 0) { statusClass = 'out'; statusText = 'نفدت الكمية'; }
            else if (available === 0) { statusClass = 'low'; statusText = 'محجوز بالكامل'; }
            else if (available <= 5) { statusClass = 'low'; statusText = 'كمية منخفضة'; }

            const card = document.createElement('div');
            card.className = 'inv-card';
            card.innerHTML = '<div class="inv-img-wrap">' +
                    '<img src="' + item.image + '" alt="' + item.name + '">' +
                    '<span class="inv-status ' + statusClass + '">' + statusText + '</span>' +
                '</div>' +
                '<div class="inv-info">' +
                    '<h3 class="inv-title">' + item.name + '</h3>' +
                    '<div class="inv-details"><span class="inv-dot" style="background:' + item.colorHex + ';"></span> ' + item.color + ' | مقاس ' + item.size + '</div>' +
                    '<div style="font-family:monospace; font-size:11px; color:#888; margin-bottom:5px; background:#F8FAFC; padding:4px 8px; border-radius:5px; display:inline-block;">' + item.sku + '</div>' +
                    '<div style="display:flex; justify-content:space-between; font-size:12px; margin-bottom:5px;">' +
                        '<span>سعر البيع: <b>' + item.price.toLocaleString() + '</b></span>' +
                        '<span style="color:var(--muted);">التكلفة: ' + (item.costPrice || 0).toLocaleString() + '</span>' +
                    '</div>' +
                    '<div style="font-size:11px; color:var(--gold); font-weight:bold; margin-bottom:5px;">' + (item.mainCategory || 'أخرى') + ' - ' + (item.subCategory || '') + '</div>' +
                    (item.maxDiscount > 0 ? '<div style="font-size:12px; color:var(--success); font-weight:bold; margin-bottom:10px;"><i class="fa-solid fa-tag"></i> خصم حتى ' + item.maxDiscount + '%</div>' : '') +
                    '<div class="inv-price-row" style="gap: 8px;">' +
                        '<div class="inv-price">' + item.price.toLocaleString() + ' <span style="font-size:12px;">ر.ي</span></div>' +
                        '<div style="display: flex; flex-direction: column; align-items: flex-end; gap: 3px;">' +
                            '<div style="font-weight: 800; color: ' + (available > 5 ? 'var(--success)' : (available > 0 ? 'var(--warning)' : 'var(--danger)')) + '; background: ' + (available > 5 ? 'rgba(56,161,105,0.1)' : (available > 0 ? 'rgba(221,107,32,0.1)' : 'rgba(229,62,62,0.1)')) + '; padding: 4px 10px; border-radius: 8px; font-size: 13px;">' +
                                'المتاح: ' + available +
                            '</div>' +
                            (reserved > 0 ? '<div style="font-size: 10px; color: var(--muted);">(' + qty + ' كلي - ' + reserved + ' محجوز)</div>' : '') +
                        '</div>' +
                    '</div>' +
                    '<div class="inv-actions">' +
                        '<button class="inv-btn history" onclick="event.stopPropagation(); window.openProductMovements(\'' + item.sku + '\')" title="عرض السجل"><i class="fa-solid fa-clock-rotate-left"></i></button>' +
                        '<button class="inv-btn edit" onclick="window.openEditProductModal(\'' + item.sku + '\')" title="تعديل"><i class="fa-solid fa-pen"></i></button>' +
                        '<button class="inv-btn print" onclick="window.printSingleItem(\'' + item.sku + '\')" title="طباعة ملصق"><i class="fa-solid fa-print"></i></button>' +
                        '<button class="inv-btn del" onclick="window.deleteInventoryItem(\'' + item.sku + '\')" title="حذف"><i class="fa-solid fa-trash"></i></button>' +
                    '</div>' +
                '</div>';
            grid.appendChild(card);
        });
    };

    let currentEditingSku = null;
    window.openEditProductModal = function(sku) {
        const inventory = JSON.parse(localStorage.getItem('maqlis_inventory')) || [];
        const product = inventory.find(p => p.sku === sku);
        if (!product) return;
        currentEditingSku = sku;
        document.getElementById('editProductSku').value = sku;
        document.getElementById('editProductSkuDisplay').textContent = sku;
        document.getElementById('editProductMeta').textContent = (product.mainCategory || '') + ' - ' + (product.subCategory || '') + ' | ' + (product.color || '') + ' - ' + (product.size || '');
        document.getElementById('editPName').value = product.name || '';
        document.getElementById('editPPrice').value = product.price || 0;
        document.getElementById('editPCost').value = product.costPrice || 0;
        document.getElementById('editPMaxDiscount').value = product.maxDiscount || 0;
        document.getElementById('editPImage').value = product.image || '';
        document.getElementById('editPQty').value = product.qty || 0;
        document.getElementById('editPQtyTotal').textContent = product.qty || 0;
        document.getElementById('editPQtyReserved').textContent = product.reserved || 0;
        document.getElementById('editPQtyAvailable').textContent = Math.max(0, (product.qty || 0) - (product.reserved || 0));
        const modal = document.getElementById('editProductModal');
        modal.style.display = 'flex';
        setTimeout(() => modal.classList.add('show'), 10);
    };

    window.updateEditQtyPreview = function() {
        const newQty = parseInt(document.getElementById('editPQty').value) || 0;
        const reserved = parseInt(document.getElementById('editPQtyReserved').textContent) || 0;
        document.getElementById('editPQtyTotal').textContent = newQty;
        document.getElementById('editPQtyAvailable').textContent = Math.max(0, newQty - reserved);
    };

    window.closeEditProductModal = function() {
        const modal = document.getElementById('editProductModal');
        modal.classList.remove('show');
        setTimeout(() => modal.style.display = 'none', 300);
        currentEditingSku = null;
    };

    window.saveProductChanges = function() {
        if (!currentEditingSku) return;
        const name = document.getElementById('editPName').value.trim();
        const price = parseFloat(document.getElementById('editPPrice').value) || 0;
        const costPrice = parseFloat(document.getElementById('editPCost').value) || 0;
        const maxDiscount = parseInt(document.getElementById('editPMaxDiscount').value) || 0;
        const image = document.getElementById('editPImage').value.trim();
        const newQty = parseInt(document.getElementById('editPQty').value) || 0;

        if (!name) return alert('اسم المنتج مطلوب');
        if (price <= 0) return alert('السعر يجب أن يكون أكبر من صفر');
        if (costPrice < 0) return alert('سعر التكلفة غير صالح');
        if (maxDiscount < 0 || maxDiscount > 100) return alert('الخصم يجب أن يكون بين 0 و 100');

        let inventory = JSON.parse(localStorage.getItem('maqlis_inventory')) || [];
        const idx = inventory.findIndex(p => p.sku === currentEditingSku);
        if (idx === -1) return alert('المنتج غير موجود');

        const product = inventory[idx];
        const reserved = product.reserved || 0;
        if (newQty < reserved) return alert('⚠️ لا يمكن تقليل الكمية إلى ' + newQty + '\nهناك ' + reserved + ' قطعة محجوزة.\nالحد الأدنى المسموح: ' + reserved);

        const oldQty = product.qty || 0;

        inventory[idx] = { ...product, name, price, costPrice, maxDiscount, image: image || product.image, qty: newQty };
        localStorage.setItem('maqlis_inventory', JSON.stringify(inventory));

        if (newQty !== oldQty) {
            logStockMovement(currentEditingSku, 'adjust', newQty - oldQty, oldQty, newQty, 'ADJ-' + Date.now(), 'تسوية يدوية من المخزون');
        }
        alert('✅ تم حفظ التعديلات بنجاح');
        window.closeEditProductModal();
        window.renderInventoryTable();
    };

    window.deleteInventoryItem = function(sku) {
        if (!confirm('حذف هذا المنتج؟')) return;
        const inventory = JSON.parse(localStorage.getItem('maqlis_inventory')) || [];
        const product = inventory.find(i => i.sku === sku);

        if (product) {
            logStockMovement(sku, 'delete', -product.qty, product.qty, 0, 'DEL-' + Date.now(), 'حذف المنتج: ' + product.name);
        }

        let inv = inventory.filter(i => i.sku !== sku);
        localStorage.setItem('maqlis_inventory', JSON.stringify(inv));
        window.renderInventoryTable();
    };

    window.printFromAdd = function() {
        if (generatedVariants.length === 0) return alert('لا توجد منتجات للطباعة');
        const qtyInputs = document.querySelectorAll('.qty-input');
        const variantsToPrint = generatedVariants.map((v, i) => ({ ...v, qty: parseInt(qtyInputs[i].value) || 0 }));
        const printArea = document.getElementById('print-area');
        printArea.innerHTML = '<div class="print-grid">';
        variantsToPrint.forEach(item => { for (let i = 0; i < item.qty; i++) { printArea.innerHTML += '<div class="print-item"><h4>' + item.name + '</h4><div class="meta">' + item.color + ' - ' + item.size + '</div><svg class="print-svg" data-sku="' + item.sku + '"></svg><div class="price">' + item.price.toLocaleString() + ' ر.ي</div></div>'; } });
        printArea.innerHTML += '</div>';
        document.querySelectorAll('.print-svg').forEach(svg => JsBarcode(svg, svg.dataset.sku, { format: "CODE128", width: 1.5, height: 35, displayValue: true, fontSize: 10, margin: 2 }));
        setTimeout(() => window.print(), 200);
    };

    window.printSingleItem = function(sku) {
        const inventory = JSON.parse(localStorage.getItem('maqlis_inventory')) || [];
        const item = inventory.find(i => i.sku === sku); if (!item) return;
        const printArea = document.getElementById('print-area');
        printArea.innerHTML = '<div class="print-grid">';
        printArea.innerHTML += '<div class="print-item"><h4>' + item.name + '</h4><div class="meta">' + item.color + ' - ' + item.size + '</div><svg class="print-svg" data-sku="' + item.sku + '"></svg><div class="price">' + item.price.toLocaleString() + ' ر.ي</div></div>';
        printArea.innerHTML += '</div>';
        document.querySelectorAll('.print-svg').forEach(svg => JsBarcode(svg, svg.dataset.sku, { format: "CODE128", width: 1.5, height: 35, displayValue: true, fontSize: 10, margin: 2 }));
        setTimeout(() => window.print(), 200);
    };

    window.printFilteredItems = function() {
        const inventory = JSON.parse(localStorage.getItem('maqlis_inventory')) || [];
        if (inventory.length === 0) return alert('لا يوجد منتجات');
        const printArea = document.getElementById('print-area');
        printArea.innerHTML = '<div class="print-grid">';
        inventory.forEach(item => { for (let i = 0; i < item.qty; i++) { printArea.innerHTML += '<div class="print-item"><h4>' + item.name + '</h4><div class="meta">' + item.color + ' - ' + item.size + '</div><svg class="print-svg" data-sku="' + item.sku + '"></svg><div class="price">' + item.price.toLocaleString() + ' ر.ي</div></div>'; } });
        printArea.innerHTML += '</div>';
        document.querySelectorAll('.print-svg').forEach(svg => JsBarcode(svg, svg.dataset.sku, { format: "CODE128", width: 1.5, height: 35, displayValue: true, fontSize: 10, margin: 2 }));
        setTimeout(() => window.print(), 200);
    };

    /* ===== SALES ===== */
    window.populateCashierFilter = function() {
        const sales = JSON.parse(localStorage.getItem('maqlis_sales')) || [];

        const subCashiers = [...new Set(sales.map(s => s.subCashier).filter(Boolean))].sort();
        const subSelect = document.getElementById('subCashierFilter');
        if (subSelect) {
            const currentVal = subSelect.value;
            subSelect.innerHTML = '<option value="all">جميع الكاشيرين الفرعيين</option>';
            subCashiers.forEach(c => {
                subSelect.innerHTML += '<option value="' + c + '">' + c + '</option>';
            });
            if (subCashiers.includes(currentVal)) subSelect.value = currentVal;
        }

        const mainCashiers = [...new Set(sales.map(s => s.mainCashier || (s.source === 'pos' ? s.cashier : null)).filter(Boolean))].sort();
        const mainSelect = document.getElementById('mainCashierFilter');
        if (mainSelect) {
            const currentVal = mainSelect.value;
            mainSelect.innerHTML = '<option value="all">جميع الصناديق</option>';
            mainCashiers.forEach(c => {
                mainSelect.innerHTML += '<option value="' + c + '">' + c + '</option>';
            });
            if (mainCashiers.includes(currentVal)) mainSelect.value = currentVal;
        }
    };

    window.renderSalesFilterCards = function() {
        const sales = JSON.parse(localStorage.getItem('maqlis_sales')) || [];
        const walletMethods = ['جيب', 'كريمي', 'فلوسك', 'جوالي', 'موبايل موني'];
        const filters = [
            { key: 'all', icon: 'fa-chart-pie', label: 'الكل', color: '#C9A961', count: sales.length, amount: sales.reduce((s, x) => s + x.total, 0) },
            { key: 'cash', icon: 'fa-money-bill-wave', label: 'نقدي', color: '#059669', count: sales.filter(s => s.paymentMethod === 'نقدي').length, amount: sales.filter(s => s.paymentMethod === 'نقدي').reduce((a, s) => a + s.total, 0) },
            { key: 'wallets', icon: 'fa-wallet', label: 'محافظ إلكترونية', color: '#7C3AED', count: sales.filter(s => walletMethods.includes(s.paymentMethod)).length, amount: sales.filter(s => walletMethods.includes(s.paymentMethod)).reduce((a, s) => a + s.total, 0) },
            { key: 'online', icon: 'fa-globe', label: 'أونلاين', color: '#3182CE', count: sales.filter(s => s.source === 'online').length, amount: sales.filter(s => s.source === 'online').reduce((a, s) => a + s.total, 0) },
            { key: 'return', icon: 'fa-rotate-left', label: 'مرتجع', color: '#DD6B20', count: sales.filter(s => s.source === 'return' && !s.manualReturn).length, amount: Math.abs(sales.filter(s => s.source === 'return' && !s.manualReturn).reduce((a, s) => a + s.total, 0)) },
            { key: 'manual', icon: 'fa-circle-exclamation', label: 'مرتجع يدوي', color: '#E53E3E', count: sales.filter(s => s.manualReturn === true).length, amount: Math.abs(sales.filter(s => s.manualReturn === true).reduce((a, s) => a + s.total, 0)) }
        ];

        const container = document.getElementById('salesFiltersContainer');
        if (!container) return;
        container.innerHTML = filters.map(f =>
            '<div class="sales-filter-card ' + (currentSalesFilter === f.key ? 'active' : '') + '" onclick="window.setSalesFilter(\'' + f.key + '\')">' +
                '<div class="sales-filter-icon" style="color: ' + f.color + ';"><i class="fa-solid ' + f.icon + '"></i></div>' +
                '<div class="sales-filter-label">' + f.label + '</div>' +
                '<div class="sales-filter-count" style="color:' + f.color + ';">' + f.count + '</div>' +
                '<div class="sales-filter-amount">' + f.amount.toLocaleString() + ' ر.ي</div>' +
            '</div>'
        ).join('');
    };

    window.setSalesFilter = function(key) { currentSalesFilter = key; window.renderSales(); };

    window.getPaymentMethodBadge = function(method) {
        if (!method || method === 'قيد الانتظار') return '<span style="background:#FEF3C7; padding:5px 10px; border-radius:8px; font-size:11.5px; font-weight:800; color:#92400E;"><i class="fa-solid fa-hourglass-half"></i> قيد الانتظار</span>';
        const methodMap = {
            'نقدي': { icon: 'fa-money-bill-wave', color: '#059669', bg: '#DEF7EC', label: 'نقدي' },
            'جيب': { icon: 'fa-wallet', color: '#0284C7', bg: '#DBEAFE', label: 'جيب' },
            'كريمي': { icon: 'fa-building-columns', color: '#7C3AED', bg: '#EDE9FE', label: 'كريمي' },
            'فلوسك': { icon: 'fa-coins', color: '#D97706', bg: '#FEF3C7', label: 'فلوسك' },
            'جوالي': { icon: 'fa-mobile-screen', color: '#DC2626', bg: '#FEE2E2', label: 'جوالي' },
            'موبايل موني': { icon: 'fa-mobile-screen-button', color: '#EA580C', bg: '#FFEDD5', label: 'موبايل موني' },
            'طلب من المخزن': { icon: 'fa-boxes-picking', color: '#92400E', bg: '#FDE68A', label: 'من المخزن' },
            'مرتجع': { icon: 'fa-rotate-left', color: '#991B1B', bg: '#FEE2E2', label: 'مرتجع' },
            'مرتجع يدوي': { icon: 'fa-circle-exclamation', color: '#991B1B', bg: '#FECACA', label: 'مرتجع يدوي' },
            'أونلاين': { icon: 'fa-globe', color: '#1E40AF', bg: '#DBEAFE', label: 'أونلاين' }
        };
        const info = methodMap[method] || { icon: 'fa-credit-card', color: '#64748B', bg: '#F1F5F9', label: method };
        return '<span style="display: inline-flex; align-items: center; gap: 6px; background: ' + info.bg + '; color: ' + info.color + '; padding: 6px 12px; border-radius: 8px; font-size: 11.5px; font-weight: 800; white-space: nowrap; border: 1px solid ' + info.color + '25;"><i class="fa-solid ' + info.icon + '"></i> ' + info.label + '</span>';
    };

    window.renderSales = function() {
        const sales = JSON.parse(localStorage.getItem('maqlis_sales')) || [];
        const tbody = document.querySelector('#salesTable tbody');
        tbody.innerHTML = '';

        const searchQuery = (document.getElementById('salesSearch')?.value || '').trim().toLowerCase();
        const fromDate = document.getElementById('salesFromDate')?.value || '';
        const toDate = document.getElementById('salesToDate')?.value || '';
        const subCashierFilter = document.getElementById('subCashierFilter')?.value || 'all';
        const mainCashierFilter = document.getElementById('mainCashierFilter')?.value || 'all';
        const paymentFilter = document.getElementById('paymentFilter')?.value || 'all';

        let filtered = sales;
        const walletMethods = ['جيب', 'كريمي', 'فلوسك', 'جوالي', 'موبايل موني'];

        if (currentSalesFilter === 'cash') filtered = filtered.filter(s => s.paymentMethod === 'نقدي');
        else if (currentSalesFilter === 'wallets') filtered = filtered.filter(s => walletMethods.includes(s.paymentMethod));
        else if (currentSalesFilter === 'online') filtered = filtered.filter(s => s.source === 'online');
        else if (currentSalesFilter === 'return') filtered = filtered.filter(s => s.source === 'return' && !s.manualReturn);
        else if (currentSalesFilter === 'manual') filtered = filtered.filter(s => s.manualReturn === true);

        if (fromDate) filtered = filtered.filter(s => new Date(s.date).toISOString().split('T')[0] >= fromDate);
        if (toDate) filtered = filtered.filter(s => new Date(s.date).toISOString().split('T')[0] <= toDate);
        if (subCashierFilter !== 'all') filtered = filtered.filter(s => s.subCashier === subCashierFilter);
        if (mainCashierFilter !== 'all') filtered = filtered.filter(s => (s.mainCashier || s.cashier) === mainCashierFilter);
        if (paymentFilter !== 'all') filtered = filtered.filter(s => s.paymentMethod === paymentFilter);

        if (searchQuery) {
            filtered = filtered.filter(s => {
                const itemsMatch = s.items && s.items.some(item =>
                    (item.name || '').toLowerCase().includes(searchQuery) ||
                    (item.sku || '').toLowerCase().includes(searchQuery)
                );
                return (s.id || '').toLowerCase().includes(searchQuery) ||
                       String(s.customerNo || '').includes(searchQuery) ||
                       (s.cashier || '').toLowerCase().includes(searchQuery) ||
                       (s.subCashier || '').toLowerCase().includes(searchQuery) ||
                       (s.mainCashier || '').toLowerCase().includes(searchQuery) ||
                       (s.customer?.name || '').toLowerCase().includes(searchQuery) ||
                       (s.paymentMethod || '').toLowerCase().includes(searchQuery) ||
                       itemsMatch;
            });
        }

        const countDisplay = document.getElementById('salesCountDisplay');
        if (countDisplay) countDisplay.textContent = 'إجمالي العمليات: ' + filtered.length;

        if (filtered.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:40px; color:#888;"><i class="fa-solid fa-inbox" style="font-size:40px; opacity:0.3; display:block; margin-bottom:10px;"></i>لا توجد عمليات مطابقة</td></tr>';
            window.renderSalesFilterCards();
            return;
        }

        [...filtered].reverse().forEach((sale) => {
            const date = new Date(sale.date).toLocaleString('ar-EG');
            const isOnline = sale.source === 'online';
            const isReturn = sale.source === 'return';
            const isManual = sale.manualReturn === true;
            const fromWarehouse = sale.originalPickupOrder ? true : false;

            let sourceBadge;
            if (isManual) {
                sourceBadge = '<span class="badge" style="background:#FEE2E2; color:#991B1B;">🔴 مرتجع يدوي</span>';
            } else if (isReturn) {
                sourceBadge = '<span class="badge badge-return">🔄 مرتجع</span>';
            } else if (isOnline) {
                sourceBadge = '<span class="badge badge-online">🌐 أونلاين</span>';
            } else if (fromWarehouse) {
                sourceBadge = '<span class="badge" style="background:#D1FAE5; color:#065F46; border:1px solid #A7F3D0;">📦 من المخزن</span>';
            } else {
                sourceBadge = '<span class="badge badge-pos">💳 كاشير</span>';
            }

            const customerNoBadge = sale.customerNo
                ? '<span class="row-customer-badge"><i class="fa-solid fa-user"></i> #' + sale.customerNo + '</span>'
                : (sale.customer && sale.customer.name
                    ? '<span class="row-customer-badge"><i class="fa-solid fa-user"></i> ' + sale.customer.name + '</span>'
                    : '<span style="color:var(--muted); font-size:11px;">—</span>');

            let cashierDisplay = '';
            const subName = sale.subCashier || null;
            const mainName = sale.mainCashier || sale.cashier || null;

            if (subName && mainName) {
                cashierDisplay = '<div style="display:flex; flex-direction:column; gap:3px;">' +
                    '<span class="row-cashier-badge row-cashier-sub" style="font-size:10.5px;"><i class="fa-solid fa-user-tag"></i> البائع: ' + subName + '</span>' +
                    '<span class="row-cashier-badge row-cashier-main" style="font-size:10.5px;"><i class="fa-solid fa-cash-register"></i> الصندوق: ' + mainName + '</span>' +
                '</div>';
            } else if (mainName) {
                cashierDisplay = '<span class="row-cashier-badge row-cashier-main"><i class="fa-solid fa-cash-register"></i> ' + mainName + '</span>';
            } else {
                cashierDisplay = '<span style="color:var(--danger); font-size:11px; font-weight:700;">⚠️ غير مسجل</span>';
            }

            let paymentDisplay;
            if (sale.paymentMethod === 'طلب من المخزن') {
                paymentDisplay = '<span class="badge" style="background:#FEF3C7; color:#92400E; padding:5px 10px; border-radius:8px; font-size:11px;">⏳ لم يكتمل</span>';
            } else if (!sale.paymentMethod) {
                paymentDisplay = '<span style="color:var(--muted); font-size:11px;">—</span>';
            } else {
                paymentDisplay = window.getPaymentMethodBadge(sale.paymentMethod);
            }

            const tr = document.createElement('tr');
            tr.innerHTML = '<td data-label="الفاتورة" style="font-family:monospace; font-size:12px; font-weight:700;">' + sale.id + '</td>' +
                '<td data-label="التاريخ" style="font-size:12px;">' + date + '</td>' +
                '<td data-label="المصدر">' + sourceBadge + '</td>' +
                '<td data-label="الزبونة">' + customerNoBadge + '</td>' +
                '<td data-label="الكاشير">' + cashierDisplay + '</td>' +
                '<td data-label="طريقة الدفع">' + paymentDisplay + '</td>' +
                '<td data-label="الإجمالي" style="color:' + (isReturn ? 'var(--danger)' : 'var(--gold)') + '; font-weight:800; font-size:14px;">' + sale.total.toLocaleString() + ' ر.ي</td>' +
                '<td data-label="عرض" style="text-align:center;"><i class="fa-solid fa-chevron-down" style="color:var(--muted); transition:0.3s;"></i></td>';

            const detailTr = document.createElement('tr');
            detailTr.className = 'details-row';

            let customerInfo = '';
            if (sale.customer && (sale.customer.name || sale.customer.phone)) {
                customerInfo = '<div style="background: linear-gradient(135deg, #EFF6FF, #DBEAFE); padding: 12px; border-radius: 8px; margin-bottom: 12px; font-size: 12px; color: #1E40AF; border: 1px solid #BFDBFE;">' +
                    '<div style="font-weight:800; margin-bottom:5px; color:#1E3A8A;">👤 بيانات العميلة:</div>' +
                    (sale.customer.name ? '<div><strong>الاسم:</strong> ' + sale.customer.name + '</div>' : '') +
                    (sale.customer.phone ? '<div><strong>الجوال:</strong> ' + sale.customer.phone + '</div>' : '') +
                    (sale.customer.city ? '<div><strong>المدينة:</strong> ' + sale.customer.city + '</div>' : '') +
                    (sale.customer.address ? '<div><strong>العنوان:</strong> ' + sale.customer.address + '</div>' : '') +
                '</div>';
            }

            let itemsHTML = (sale.items || []).map(item =>
                '<div class="details-item" style="flex-direction: column; align-items: flex-start; gap: 4px;">' +
                    '<div style="display:flex; justify-content:space-between; width:100%; align-items:center;">' +
                        '<strong>' + item.name + '</strong>' +
                        '<span style="color:var(--gold); font-weight:800;">' + ((item.qty || 0) * (item.price || 0)).toLocaleString() + ' ر.ي</span>' +
                    '</div>' +
                    '<div class="detail-meta-row">' +
                        (item.color ? '<span style="font-size:12px;"><i class="fa-solid fa-palette"></i> ' + item.color + '</span>' : '') +
                        (item.size ? '<span style="font-size:12px;"><i class="fa-solid fa-ruler"></i> مقاس ' + item.size + '</span>' : '') +
                        '<span class="detail-item-sku">' + (item.sku || 'SKU') + '</span>' +
                        '<span style="font-size:12px;">الكمية: <strong>' + (item.qty || 0) + '</strong></span>' +
                        '<span style="font-size:12px;">السعر: ' + (item.price || 0).toLocaleString() + ' ر.ي</span>' +
                        (item.discount > 0 ? '<span style="color:var(--danger); font-size:12px;">خصم ' + item.discount + '%</span>' : '') +
                    '</div>' +
                '</div>'
            ).join('');

            let orderInfo = '';
            if (fromWarehouse) {
                orderInfo = '<div style="background: #D1FAE5; padding: 10px; border-radius: 8px; margin-bottom: 12px; font-size: 12px; color: #065F46; border: 1px solid #A7F3D0;">' +
                    '<i class="fa-solid fa-boxes-packing"></i> <strong>رقم الطلب الأصلي (المخزن):</strong> ' + sale.originalPickupOrder +
                '</div>';
            }

            detailTr.innerHTML = '<td colspan="8">' +
                '<div class="details-content">' +
                    '<h4><i class="fa-solid fa-box-open" style="color:var(--gold);"></i> تفاصيل العملية:</h4>' +
                    orderInfo + customerInfo + itemsHTML +
                '</div>' +
            '</td>';

            tr.onclick = () => {
                detailTr.classList.toggle('open');
                tr.classList.toggle('is-expanded');
                const icon = tr.querySelector('.fa-chevron-down');
                if (detailTr.classList.contains('open')) { icon.style.transform = 'rotate(180deg)'; }
                else { icon.style.transform = 'rotate(0deg)'; }
            };

            tbody.appendChild(tr);
            tbody.appendChild(detailTr);
        });

        window.renderSalesFilterCards();
    };

    window.setSalesDateQuick = function(range, btn) {
        document.querySelectorAll('.sales-date-quick').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
        const now = new Date();
        const today = now.toISOString().split('T')[0];
        const fromInput = document.getElementById('salesFromDate');
        const toInput = document.getElementById('salesToDate');

        if (range === 'today') { fromInput.value = today; toInput.value = today; }
        else if (range === 'week') {
            const past = new Date(now);
            past.setDate(past.getDate() - 7);
            fromInput.value = past.toISOString().split('T')[0];
            toInput.value = today;
        }
        else if (range === 'month') {
            fromInput.value = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
            toInput.value = today;
        }
        else if (range === 'year') {
            fromInput.value = new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0];
            toInput.value = today;
        }
        window.renderSales();
    };

    window.resetSalesFilters = function() {
        document.getElementById('salesSearch').value = '';
        document.getElementById('salesFromDate').value = '';
        document.getElementById('salesToDate').value = '';
        document.getElementById('subCashierFilter').value = 'all';
        document.getElementById('mainCashierFilter').value = 'all';
        document.getElementById('paymentFilter').value = 'all';
        document.querySelectorAll('.sales-date-quick').forEach(b => b.classList.remove('active'));
        currentSalesFilter = 'all';
        window.renderSales();
        window.showToast('تم مسح جميع الفلاتر', 'success');
    };

    window.exportSalesToCSV = function() {
        const sales = JSON.parse(localStorage.getItem('maqlis_sales')) || [];
        const fromDate = document.getElementById('salesFromDate')?.value || '';
        const toDate = document.getElementById('salesToDate')?.value || '';

        let filtered = sales;
        if (fromDate) filtered = filtered.filter(s => new Date(s.date).toISOString().split('T')[0] >= fromDate);
        if (toDate) filtered = filtered.filter(s => new Date(s.date).toISOString().split('T')[0] <= toDate);

        if (filtered.length === 0) { window.showToast('لا توجد نتائج للتصدير', 'error'); return; }

        let csv = '\uFEFF';
        csv += 'الفاتورة,التاريخ,المصدر,رقم الزبونة,اسم العميلة,كاشير فرعي,صندوق رئيسي,طريقة الدفع,الإجمالي,القطع\n';

        filtered.forEach(sale => {
            const date = new Date(sale.date).toLocaleString('ar-EG');
            const source = sale.manualReturn ? 'مرتجع يدوي' :
                           sale.source === 'return' ? 'مرتجع' :
                           sale.source === 'online' ? 'أونلاين' :
                           sale.originalPickupOrder ? 'من المخزن' : 'كاشير';
            const customerNo = sale.customerNo || '';
            const customerName = sale.customer ? (sale.customer.name || '') : '';
            const subCashier = sale.subCashier || '';
            const mainCashier = sale.mainCashier || sale.cashier || '';
            const payment = sale.paymentMethod || '';
            const total = sale.total || 0;
            const itemsCount = sale.items ? sale.items.reduce((s, i) => s + i.qty, 0) : 0;

            csv += '"' + sale.id + '","' + date + '","' + source + '","' + customerNo + '","' + customerName + '","' + subCashier + '","' + mainCashier + '","' + payment + '","' + total + '","' + itemsCount + '"\n';
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'maqlis-sales-' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
        URL.revokeObjectURL(url);
        window.showToast('✅ تم تصدير ' + filtered.length + ' فاتورة', 'success');
    };

    /* ===== ARCHIVE ===== */
    function archiveOldSales(days, silent) {
        if (days <= 0) { if (!silent) window.showToast('الأرشفة التلقائية معطّلة', 'info'); return 0; }
        let sales = JSON.parse(localStorage.getItem('maqlis_sales')) || [];
        let archive = JSON.parse(localStorage.getItem('maqlis_sales_archive')) || [];
        const cutoff = new Date();
        cutoff.setDate(cutoff.getDate() - days);
        const archivedIds = new Set(archive.map((sale, index) => saleIdentity(sale, 'archive:' + index)));
        const toArchive = sales.filter(sale => {
            const date = sale && sale.date ? new Date(sale.date) : null;
            if (!date || Number.isNaN(date.getTime()) || date >= cutoff) return false;
            return !archivedIds.has(saleIdentity(sale, 'active:' + sales.indexOf(sale)));
        });
        const toKeep = sales.filter(sale => {
            const date = sale && sale.date ? new Date(sale.date) : null;
            return !date || Number.isNaN(date.getTime()) || date >= cutoff;
        });
        if (toArchive.length === 0) { if (!silent) window.showToast('لا توجد فواتير أقدم من ' + days + ' يوم', 'info'); return 0; }
        const mergedArchive = new Map();
        archive.forEach((sale, index) => mergedArchive.set(saleIdentity(sale, 'archive:' + index), sale));
        toArchive.forEach((sale, index) => mergedArchive.set(saleIdentity(sale, 'moved:' + index), sale));
        localStorage.setItem('maqlis_sales', JSON.stringify(toKeep));
        localStorage.setItem('maqlis_sales_archive', JSON.stringify(Array.from(mergedArchive.values())));
        if (!silent) { window.showToast('✅ تم أرشفة ' + toArchive.length + ' فاتورة', 'success'); window.renderSales(); window.refreshArchiveModal(); }
        return toArchive.length;
    }

    window.autoArchiveOnLogin = function() {
        const lastArchive = localStorage.getItem('maqlis_last_archive');
        const today = new Date().toISOString().split('T')[0];
        if (lastArchive === today) return;
        const retentionDays = parseInt(localStorage.getItem('maqlis_retention_days')) || 90;
        const archived = archiveOldSales(retentionDays, true);
        localStorage.setItem('maqlis_last_archive', today);
        if (archived > 0) console.log('✅ Auto-archived ' + archived + ' old invoices');
    };

    window.openArchiveModal = function() {
        window.refreshArchiveModal();
        const modal = document.getElementById('archiveModal');
        modal.style.display = 'flex';
        setTimeout(() => modal.classList.add('show'), 10);
    };

    window.closeArchiveModal = function() {
        const modal = document.getElementById('archiveModal');
        modal.classList.remove('show');
        setTimeout(() => modal.style.display = 'none', 300);
    };

    window.refreshArchiveModal = function() {
        const sales = JSON.parse(localStorage.getItem('maqlis_sales')) || [];
        const archive = JSON.parse(localStorage.getItem('maqlis_sales_archive')) || [];

        document.getElementById('activeSalesCount').textContent = sales.length;
        document.getElementById('archivedSalesCount').textContent = archive.length;

        const totalSize = (localStorage.getItem('maqlis_sales') || '').length + (localStorage.getItem('maqlis_sales_archive') || '').length;
        const sizeKB = (totalSize / 1024).toFixed(1);
        document.getElementById('storageSize').textContent = sizeKB + ' KB';

        const retention = localStorage.getItem('maqlis_retention_days') || '90';
        document.getElementById('retentionPeriod').value = retention;
    };

    window.updateRetention = function() {
        const val = document.getElementById('retentionPeriod').value;
        localStorage.setItem('maqlis_retention_days', val);
        window.showToast('✅ تم حفظ إعداد الأرشفة', 'success');
    };

    window.manualArchive = function() {
        const days = parseInt(document.getElementById('retentionPeriod').value) || 90;
        if (days === 0) { window.showToast('اختر مدة للأرشفة أولاً', 'error'); return; }
        archiveOldSales(days, false);
    };

    window.exportArchiveToCSV = function() {
        const archive = JSON.parse(localStorage.getItem('maqlis_sales_archive')) || [];
        if (archive.length === 0) { window.showToast('لا توجد فواتير في الأرشيف', 'info'); return; }

        let csv = '\uFEFF';
        csv += 'الفاتورة,التاريخ,الكاشير,طريقة الدفع,الإجمالي,المصدر\n';

        archive.forEach(sale => {
            const date = new Date(sale.date).toLocaleString('ar-EG');
            const source = sale.source === 'online' ? 'أونلاين' : sale.source === 'return' ? 'مرتجع' : 'كاشير';
            csv += '"' + sale.id + '","' + date + '","' + sale.cashier + '","' + (sale.paymentMethod || 'غير محدد') + '","' + sale.total + '","' + source + '"\n';
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'maqlis-archive-' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
        URL.revokeObjectURL(url);
        window.showToast('✅ تم تصدير الأرشيف', 'success');
    };

    /* ===== TOAST ===== */
    window.showToast = function(message, type) {
        type = type || 'success';
        const toast = document.createElement('div');
        toast.style.cssText = 'position: fixed; bottom: 30px; left: 50%; transform: translateX(-50%) translateY(20px); background: ' + (type === 'error' ? '#E53E3E' : '#1F1B18') + '; color: white; padding: 12px 24px; border-radius: 50px; font-family: \'Cairo\'; font-weight: 700; font-size: 14px; z-index: 10000; box-shadow: 0 8px 24px rgba(0,0,0,0.15); opacity: 0; transition: all 0.3s ease;';
        toast.textContent = message;
        document.body.appendChild(toast);

        requestAnimationFrame(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateX(-50%) translateY(0)';
        });

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(-50%) translateY(20px)';
            setTimeout(() => toast.remove(), 300);
        }, 2500);
    };

    /* ===== USER PERMISSIONS ===== */
    const PERMISSIONS_LIST = [
        { key: 'canReceivePayment', title: '💵 استلام الدفع (كاشير رئيسي)', desc: 'عند التفعيل: يستلم المال ويطبع الفواتير. عند الإطفاء: يختار فقط ويرسل للصندوق' },
        { key: 'printReceipt', title: '🖨️ طباعة الفاتورة', desc: 'طباعة إيصال بعد البيع' },
        { key: 'printBarcode', title: '📊 طباعة الباركود', desc: 'طباعة ملصقات الباركود للمنتجات' },
        { key: 'useBarcode', title: '🔍 مسح الباركود', desc: 'استخدام الباركود في الكاشير' },
        { key: 'allowReturn', title: '🔄 المرتجع بالفاتورة', desc: 'استخدام شاشة المرتجعات' },
        { key: 'allowManualReturn', title: '🔴 المرتجع اليدوي', desc: 'المرتجع بدون فاتورة' },
        { key: 'applyDiscount', title: '💰 تطبيق خصومات', desc: 'تطبيق خصم على المنتجات' },
        { key: 'viewReports', title: '📊 عرض التقارير', desc: 'عرض تقارير المبيعات' }
    ];

    function renderPermissionsList(user) {
        const container = document.getElementById('permissionsContainer');
        if (!container) return;
        const perms = user.permissions || {};

        container.innerHTML = PERMISSIONS_LIST.map(p =>
            '<div class="permission-item">' +
                '<div>' +
                    '<div class="permission-title">' + p.title + '</div>' +
                    '<div class="permission-desc">' + p.desc + '</div>' +
                '</div>' +
                '<label class="toggle-switch">' +
                    '<input type="checkbox" data-perm="' + p.key + '" ' + (perms[p.key] !== false ? 'checked' : '') + '>' +
                    '<span class="toggle-slider"></span>' +
                '</label>' +
            '</div>'
        ).join('');
    }

    window.openEditUserModal = function(userId) {
        const users = JSON.parse(localStorage.getItem('maqlis_users')) || [];
        const user = users.find(u => u.id === userId);
        if (!user) { window.showToast('المستخدم غير موجود', 'error'); return; }

        document.getElementById('editUserId').value = user.id;
        document.getElementById('editUserName').value = user.name;
        document.getElementById('editUserUsername').value = user.username;
        document.getElementById('editUserPassword').value = user.password;
        document.getElementById('editUserRole').value = user.role;

        renderPermissionsList(user);

        const modal = document.getElementById('editUserModal');
        modal.style.display = 'flex';
        setTimeout(() => modal.classList.add('show'), 10);
    };

    window.closeEditUserModal = function() {
        const modal = document.getElementById('editUserModal');
        modal.classList.remove('show');
        setTimeout(() => modal.style.display = 'none', 300);
    };

    window.saveUserChanges = function() {
        const id = parseInt(document.getElementById('editUserId').value);
        const name = document.getElementById('editUserName').value.trim();
        const username = document.getElementById('editUserUsername').value.trim();
        const password = document.getElementById('editUserPassword').value.trim();
        const role = document.getElementById('editUserRole').value;

        if (!name || !username || !password) {
            window.showToast('الرجاء تعبئة جميع الحقول', 'error');
            return;
        }

        let users = JSON.parse(localStorage.getItem('maqlis_users')) || [];
        const existingUser = users.find(u => u.username === username && u.id !== id);
        if (existingUser) {
            window.showToast('اسم المستخدم موجود مسبقاً!', 'error');
            return;
        }

        const permissions = {};
        document.querySelectorAll('#permissionsContainer input[type="checkbox"]').forEach(cb => {
            permissions[cb.dataset.perm] = cb.checked;
        });

        const idx = users.findIndex(u => u.id === id);
        if (idx > -1) {
            users[idx] = { ...users[idx], name, username, password, role, permissions };
            localStorage.setItem('maqlis_users', JSON.stringify(users));
            window.showToast('✅ تم حفظ التعديلات بنجاح', 'success');
            window.closeEditUserModal();
            window.renderUsers();

            let currentLoggedIn = null;
            try { currentLoggedIn = JSON.parse(localStorage.getItem('maqlis_currentUser') || 'null'); } catch (error) {}
            if (currentLoggedIn && String(currentLoggedIn.id) === String(id)) {
                const updatedUser = users.find(u => String(u.id) === String(id));
                if (!updatedUser || !isAdminPanelRole(updatedUser.role)) {
                    localStorage.removeItem('maqlis_currentUser');
                    document.getElementById('app-container').style.display = 'none';
                    document.getElementById('login-screen').style.display = 'flex';
                    document.getElementById('loginPass').value = '';
                    window.showToast('تم إغلاق الجلسة لأن صلاحية الحساب لم تعد تسمح بدخول لوحة الإدارة', 'warning');
                } else {
                    localStorage.setItem('maqlis_currentUser', JSON.stringify(updatedUser));
                    const nameNode = document.getElementById('currentUserName');
                    if (nameNode) nameNode.textContent = updatedUser.name || updatedUser.username;
                }
            }
        }
    };

    /* ===== SHIFTS ===== */
    const SHIFT_STORAGE_KEYS = { SHIFTS: 'maqlis_shifts', SALES: 'maqlis_sales' };

    function getShiftsRegistry() {
        try { return JSON.parse(localStorage.getItem(SHIFT_STORAGE_KEYS.SHIFTS)) || []; }
        catch { return []; }
    }

    function fmtShift(n) {
        return Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 }) + ' ر.ي';
    }

    function formatShiftDuration(ms) {
        if (ms < 0) ms = 0;
        const totalSec = Math.floor(ms / 1000);
        const h = Math.floor(totalSec / 3600);
        const m = Math.floor((totalSec % 3600) / 60);
        if (h > 0) return h + 'س ' + m + 'د';
        return m + 'د';
    }

    function computeLiveShiftStats(shiftId) {
        const sales = JSON.parse(localStorage.getItem(SHIFT_STORAGE_KEYS.SALES)) || [];
        const shiftSales = sales.filter(s => s.shiftId === shiftId);
        const stats = { invoices: 0, items: 0, revenue: 0, returns: 0, cash: 0, wallets: 0, online: 0, breakdown: {} };
        const WALLET_METHODS = ['جيب', 'كريمي', 'فلوسك', 'جوالي', 'موبايل موني'];

        shiftSales.forEach(sale => {
            const isReturn = sale.source === 'return' || (sale.total < 0);
            const amount = Math.abs(sale.total || 0);
            const method = sale.paymentMethod || 'غير محدد';

            if (!stats.breakdown[method]) stats.breakdown[method] = { sales: 0, returns: 0, net: 0, count: 0 };

            if (isReturn) {
                stats.returns += amount;
                stats.breakdown[method].returns += amount;
                stats.breakdown[method].net -= amount;
            } else {
                stats.invoices++;
                stats.items += (sale.items || []).reduce((sum, i) => sum + (i.qty || 0), 0);
                stats.breakdown[method].sales += amount;
                stats.breakdown[method].net += amount;
                stats.breakdown[method].count++;
                if (method === 'نقدي') stats.cash += amount;
                else if (WALLET_METHODS.includes(method)) stats.wallets += amount;
            }
            stats.revenue += sale.total || 0;
        });
        return stats;
    }

    function getShiftRevenue(shift) {
        if (shift.breakdown && shift.status === 'closed') {
            return Object.values(shift.breakdown).reduce((s, b) => s + (b.net || 0), 0);
        }
        return computeLiveShiftStats(shift.id).revenue;
    }

    window.populateShiftCashierFilter = function() {
        const select = document.getElementById('shiftFilterCashier');
        if (!select) return;
        const shifts = getShiftsRegistry();
        const cashiers = [...new Set(shifts.map(s => s.cashierName).filter(Boolean))].sort();
        const currentVal = select.value;
        select.innerHTML = '<option value="all">جميع الكاشيرين</option>';
        cashiers.forEach(c => {
            select.innerHTML += '<option value="' + c + '">' + c + '</option>';
        });
        if (cashiers.includes(currentVal)) select.value = currentVal;
    };

    window.updateShiftsKPIs = function(shifts) {
        const openShifts = shifts.filter(s => s.status === 'open').length;
        const withDiff = shifts.filter(s => s.status === 'closed' && s.difference && s.difference.total !== 0).length;
        const totalRevenue = shifts.reduce((sum, s) => sum + getShiftRevenue(s), 0);
        const netDiff = shifts.filter(s => s.status === 'closed').reduce((sum, s) => sum + (s.difference?.total || 0), 0);

        const setEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        setEl('kpiTotalShifts', shifts.length);
        setEl('kpiOpenShifts', openShifts);
        setEl('kpiShiftsWithDiff', withDiff);
        setEl('kpiShiftsRevenue', fmtShift(totalRevenue));
        setEl('kpiShiftsNetDiff', (netDiff >= 0 ? '+' : '-') + fmtShift(Math.abs(netDiff)));

        const netDiffEl = document.getElementById('kpiShiftsNetDiff');
        if (netDiffEl) {
            if (netDiff === 0) netDiffEl.style.color = 'var(--success)';
            else if (netDiff > 0) netDiffEl.style.color = 'var(--blue)';
            else netDiffEl.style.color = 'var(--danger)';
        }
    };

    window.renderShifts = function() {
        const tbody = document.querySelector('#shiftsTable tbody');
        const emptyState = document.getElementById('shiftsEmptyState');
        if (!tbody) return;

        let shifts = getShiftsRegistry();
        shifts.sort((a, b) => new Date(b.openedAt) - new Date(a.openedAt));

        window.populateShiftCashierFilter();
        window.updateShiftsKPIs(shifts);

        const cashierFilter = document.getElementById('shiftFilterCashier')?.value || 'all';
        const statusFilter = document.getElementById('shiftFilterStatus')?.value || 'all';
        const fromDate = document.getElementById('shiftFilterFrom')?.value || '';
        const toDate = document.getElementById('shiftFilterTo')?.value || '';

        let filtered = shifts;
        if (cashierFilter !== 'all') filtered = filtered.filter(s => s.cashierName === cashierFilter);
        if (statusFilter === 'open') filtered = filtered.filter(s => s.status === 'open');
        else if (statusFilter === 'closed') filtered = filtered.filter(s => s.status === 'closed');
        else if (statusFilter === 'diff') filtered = filtered.filter(s => s.status === 'closed' && s.difference && s.difference.total !== 0);

        if (fromDate) filtered = filtered.filter(s => new Date(s.openedAt).toISOString().split('T')[0] >= fromDate);
        if (toDate) filtered = filtered.filter(s => new Date(s.openedAt).toISOString().split('T')[0] <= toDate);

        if (filtered.length === 0) {
            tbody.innerHTML = '';
            if (emptyState) emptyState.style.display = 'block';
            return;
        }
        if (emptyState) emptyState.style.display = 'none';

        tbody.innerHTML = filtered.map(shift => {
            const isOpen = shift.status === 'open';
            const stats = isOpen ? computeLiveShiftStats(shift.id) : null;
            const openedAt = new Date(shift.openedAt);
            const closedAt = shift.closedAt ? new Date(shift.closedAt) : null;
            const durationMs = (closedAt || new Date()) - openedAt;
            const duration = formatShiftDuration(durationMs);
            const invoices = isOpen ? stats.invoices : (shift.expected?.invoices || 0);
            const revenue = getShiftRevenue(shift);
            const expectedCash = isOpen ? (shift.openingFloat || 0) + stats.cash : (shift.expected?.cash || 0);
            const actualCash = isOpen ? null : (shift.actual?.cash || 0);
            const diff = isOpen ? null : (shift.difference?.total || 0);

            let rowClass = '';
            if (isOpen) rowClass = '';
            else if (diff !== 0) rowClass = 'row-with-diff';
            else rowClass = 'row-closed-ok';

            const shortId = shift.id.split('-').pop();
            const dateStr = openedAt.toLocaleDateString('ar-EG');
            const openTimeStr = openedAt.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
            const closeTimeStr = closedAt ? closedAt.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : '—';

            let diffBadge = '<span class="diff-badge-admin pending">—</span>';
            if (!isOpen) {
                if (diff === 0) diffBadge = '<span class="diff-badge-admin zero">✓ 0</span>';
                else if (diff > 0) diffBadge = '<span class="diff-badge-admin positive">+' + fmtShift(diff) + '</span>';
                else diffBadge = '<span class="diff-badge-admin negative">' + fmtShift(diff) + '</span>';
            }

            const statusBadge = isOpen
                ? '<span class="shift-status-badge open">مفتوحة الآن</span>'
                : '<span class="shift-status-badge closed">مغلقة</span>';

            return '<tr class="' + rowClass + '" onclick="window.openShiftDetailModal(\'' + shift.id + '\')">' +
                '<td data-label="الوردية"><strong style="font-family:monospace; color:var(--gold-hover);">#' + shortId + '</strong></td>' +
                '<td data-label="الكاشير"><strong>' + shift.cashierName + '</strong></td>' +
                '<td data-label="الفترة"><div style="font-size:12px;">' + dateStr + '</div><div style="font-size:11px; color:var(--muted);">' + openTimeStr + ' → ' + closeTimeStr + '</div></td>' +
                '<td data-label="المدة"><strong style="font-variant-numeric:tabular-nums;">' + duration + '</strong></td>' +
                '<td data-label="الفواتير"><strong>' + invoices + '</strong></td>' +
                '<td data-label="الإيرادات"><strong style="color:var(--gold-hover);">' + fmtShift(revenue) + '</strong></td>' +
                '<td data-label="المتوقع"><strong style="color:var(--blue);">' + fmtShift(expectedCash) + '</strong></td>' +
                '<td data-label="الفعلي"><strong>' + (actualCash !== null ? fmtShift(actualCash) : '—') + '</strong></td>' +
                '<td data-label="الفرق">' + diffBadge + '</td>' +
                '<td data-label="الحالة">' + statusBadge + '</td>' +
            '</tr>';
        }).join('');
    };

    window.resetShiftFilters = function() {
        document.getElementById('shiftFilterCashier').value = 'all';
        document.getElementById('shiftFilterStatus').value = 'all';
        document.getElementById('shiftFilterFrom').value = '';
        document.getElementById('shiftFilterTo').value = '';
        window.renderShifts();
        window.showToast('تم مسح الفلاتر', 'success');
    };

    let currentShiftDetailId = null;

    window.openShiftDetailModal = function(shiftId) {
        const shifts = getShiftsRegistry();
        const shift = shifts.find(s => s.id === shiftId);
        if (!shift) { window.showToast('الوردية غير موجودة', 'error'); return; }

        currentShiftDetailId = shiftId;
        const isOpen = shift.status === 'open';
        const stats = isOpen ? computeLiveShiftStats(shift.id) : null;
        const breakdown = isOpen ? stats.breakdown : (shift.breakdown || {});
        const invoices = isOpen ? stats.invoices : (shift.expected?.invoices || 0);
        const items = isOpen ? stats.items : (shift.expected?.items || 0);
        const returns = isOpen ? stats.returns : (shift.expected?.returns || 0);
        const revenue = getShiftRevenue(shift);

        const openedAt = new Date(shift.openedAt);
        const closedAt = shift.closedAt ? new Date(shift.closedAt) : null;
        const durationMs = (closedAt || new Date()) - openedAt;
        const duration = formatShiftDuration(durationMs);

        const openingFloat = shift.openingFloat || 0;
        const expectedCash = isOpen ? (openingFloat + stats.cash) : (shift.expected?.cash || 0);
        const actualCash = isOpen ? null : (shift.actual?.cash || 0);
        const diff = isOpen ? null : (shift.difference?.total || 0);
        const shortId = shift.id.split('-').pop();
        const body = document.getElementById('shiftDetailBody');

        let diffHTML = '';
        if (!isOpen && diff !== null) {
            const cls = diff === 0 ? 'zero' : (diff > 0 ? 'positive' : 'negative');
            const label = diff === 0 ? 'مطابق' : (diff > 0 ? 'زيادة' : 'عجز');
            const sign = diff > 0 ? '+' : (diff < 0 ? '-' : '');
            diffHTML = '<span class="diff-badge-admin ' + cls + '" style="font-size:14px; padding:8px 14px;">' + label + ' ' + sign + fmtShift(Math.abs(diff)) + '</span>';
        }

        body.innerHTML = '<div class="shift-detail-stats">' +
                '<div class="shift-detail-stat gold"><div class="label"><i class="fa-solid fa-coins"></i> الإيرادات</div><div class="value">' + fmtShift(revenue) + '</div></div>' +
                '<div class="shift-detail-stat blue"><div class="label"><i class="fa-solid fa-receipt"></i> الفواتير</div><div class="value">' + invoices + '</div></div>' +
                '<div class="shift-detail-stat green"><div class="label"><i class="fa-solid fa-box"></i> القطع</div><div class="value">' + items + '</div></div>' +
                '<div class="shift-detail-stat red"><div class="label"><i class="fa-solid fa-rotate-left"></i> المرتجعات</div><div class="value">' + fmtShift(returns) + '</div></div>' +
            '</div>' +
            '<div class="shift-detail-info">' +
                '<div class="shift-info-row"><span class="label">رقم الوردية</span><span class="value" style="font-family:monospace;">#' + shortId + '</span></div>' +
                '<div class="shift-info-row"><span class="label">الكاشير</span><span class="value">' + shift.cashierName + '</span></div>' +
                '<div class="shift-info-row"><span class="label">وقت الفتح</span><span class="value">' + openedAt.toLocaleString('ar-EG') + '</span></div>' +
                '<div class="shift-info-row"><span class="label">وقت الإغلاق</span><span class="value">' + (closedAt ? closedAt.toLocaleString('ar-EG') : '<span style="color:var(--success);">مفتوحة الآن</span>') + '</span></div>' +
                '<div class="shift-info-row"><span class="label">المدة</span><span class="value" style="font-variant-numeric:tabular-nums;">' + duration + '</span></div>' +
                '<div class="shift-info-row"><span class="label">العهدة الابتدائية</span><span class="value">' + fmtShift(openingFloat) + '</span></div>' +
            '</div>' +
            '<h3 style="font-size:14px; margin-bottom:10px; color:var(--dark); display:flex; align-items:center; gap:6px;"><i class="fa-solid fa-list" style="color:var(--gold);"></i> تفصيل حسب طريقة الدفع</h3>' +
            '<table class="shift-breakdown-table"><thead><tr><th>الطريقة</th><th>الفواتير</th><th>مبيعات</th><th>مرتجعات</th><th>الصافي</th></tr></thead><tbody>' +
                (Object.keys(breakdown).length === 0
                    ? '<tr><td colspan="5" style="text-align:center; color:var(--muted); padding:20px;">لا توجد عمليات</td></tr>'
                    : Object.entries(breakdown).map(([method, data]) =>
                        '<tr><td>' + method + '</td><td>' + (data.count || 0) + '</td><td>' + fmtShift(data.sales) + '</td><td style="color:' + (data.returns > 0 ? 'var(--danger)' : 'var(--muted)') + ';">' + (data.returns > 0 ? '-' + fmtShift(data.returns) : '—') + '</td><td style="color:var(--gold-hover); font-weight:900;">' + fmtShift(data.net) + '</td></tr>'
                    ).join('')
                ) +
            '</tbody></table>' +
            '<div class="shift-cash-box">' +
                '<h4><i class="fa-solid fa-money-bill-wave"></i> تسوية النقدية</h4>' +
                '<div class="shift-cash-row"><span>العهدة الابتدائية</span><span class="val">' + fmtShift(openingFloat) + '</span></div>' +
                '<div class="shift-cash-row"><span>المنتظر في الدرج</span><span class="val" style="color:var(--gold-hover);">' + fmtShift(expectedCash) + '</span></div>' +
                (!isOpen ?
                    '<div class="shift-cash-row"><span>الفعلي في الدرج</span><span class="val">' + fmtShift(actualCash) + '</span></div>' +
                    '<div class="shift-cash-row"><span>الفرق</span><span class="val">' + diffHTML + '</span></div>'
                : '') +
            '</div>' +
            (!isOpen && shift.note ? '<div class="shift-detail-note"><strong><i class="fa-solid fa-note-sticky"></i> ملاحظة:</strong> ' + shift.note + '</div>' : '') +
            (shift.openingNote ? '<div class="shift-detail-note" style="background:#DBEAFE; border-color:#BFDBFE; color:#1E40AF;"><strong><i class="fa-solid fa-note-sticky"></i> ملاحظة الفتح:</strong> ' + shift.openingNote + '</div>' : '');

        const modal = document.getElementById('shiftDetailModal');
        modal.style.display = 'flex';
        setTimeout(() => modal.classList.add('show'), 10);
    };

    window.closeShiftDetailModal = function() {
        const modal = document.getElementById('shiftDetailModal');
        modal.classList.remove('show');
        setTimeout(() => modal.style.display = 'none', 300);
        currentShiftDetailId = null;
    };

    window.exportShiftsToCSV = function() {
        let shifts = getShiftsRegistry();
        shifts.sort((a, b) => new Date(b.openedAt) - new Date(a.openedAt));

        if (shifts.length === 0) { window.showToast('لا توجد ورديات للتصدير', 'error'); return; }

        let csv = '\uFEFF';
        csv += 'رقم الوردية,الكاشير,وقت الفتح,وقت الإغلاق,الحالة,المدة,الفواتير,القطع,المرتجعات,الإيرادات,العهدة,المتوقع,الفعلي,الفرق,ملاحظة\n';

        shifts.forEach(s => {
            const isOpen = s.status === 'open';
            const stats = isOpen ? computeLiveShiftStats(s.id) : null;
            const openedAt = new Date(s.openedAt);
            const closedAt = s.closedAt ? new Date(s.closedAt) : null;
            const durationMs = (closedAt || new Date()) - openedAt;
            const duration = formatShiftDuration(durationMs);

            const invoices = isOpen ? stats.invoices : (s.expected?.invoices || 0);
            const items = isOpen ? stats.items : (s.expected?.items || 0);
            const returns = isOpen ? stats.returns : (s.expected?.returns || 0);
            const revenue = getShiftRevenue(s);
            const expected = isOpen ? ((s.openingFloat || 0) + stats.cash) : (s.expected?.cash || 0);
            const actual = isOpen ? '' : (s.actual?.cash || 0);
            const diff = isOpen ? '' : (s.difference?.total || 0);
            const status = isOpen ? 'مفتوحة' : 'مغلقة';

            csv += '"' + s.id + '","' + s.cashierName + '","' + openedAt.toLocaleString('ar-EG') + '","' + (closedAt ? closedAt.toLocaleString('ar-EG') : '') + '","' + status + '","' + duration + '","' + invoices + '","' + items + '","' + returns + '","' + revenue + '","' + (s.openingFloat || 0) + '","' + expected + '","' + actual + '","' + diff + '","' + (s.note || '') + '"\n';
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'maqlis-shifts-' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
        URL.revokeObjectURL(url);
        window.showToast('✅ تم تصدير ' + shifts.length + ' وردية', 'success');
    };

    window.exportShiftDetailToCSV = function() {
        if (!currentShiftDetailId) return;
        window.exportShiftsToCSV();
    };

    window.printShiftDetail = function() {
        if (!currentShiftDetailId) return;
        const shifts = getShiftsRegistry();
        const shift = shifts.find(s => s.id === currentShiftDetailId);
        if (!shift) return;

        const isOpen = shift.status === 'open';
        const stats = isOpen ? computeLiveShiftStats(shift.id) : null;
        const breakdown = isOpen ? stats.breakdown : (shift.breakdown || {});
        const invoices = isOpen ? stats.invoices : (shift.expected?.invoices || 0);
        const items = isOpen ? stats.items : (shift.expected?.items || 0);
        const returns = isOpen ? stats.returns : (shift.expected?.returns || 0);
        const revenue = getShiftRevenue(shift);
        const openedAt = new Date(shift.openedAt);
        const closedAt = shift.closedAt ? new Date(shift.closedAt) : null;
        const durationMs = (closedAt || new Date()) - openedAt;
        const duration = formatShiftDuration(durationMs);
        const expectedCash = isOpen ? ((shift.openingFloat || 0) + stats.cash) : (shift.expected?.cash || 0);
        const actualCash = isOpen ? null : (shift.actual?.cash || 0);
        const diff = isOpen ? null : (shift.difference?.total || 0);
        const shortId = shift.id.split('-').pop();

        const printArea = document.getElementById('shift-print-area');
        printArea.style.display = 'block';
        printArea.innerHTML = '<div style="max-width: 800px; margin: 0 auto; padding: 20px; font-family: \'Cairo\'; background: white; color: black; direction: rtl;">' +
            '<div style="text-align: center; border-bottom: 2px dashed #333; padding-bottom: 12px; margin-bottom: 15px;"><h1 style="font-size: 22px; margin-bottom: 5px;">بوتيك مقليس</h1><p style="font-size: 13px; color: #555;">تقرير وردية - #' + shortId + '</p></div>' +
            '<div style="background: #F8FAFC; padding: 12px; border-radius: 6px; margin-bottom: 15px; font-size: 12px;"><div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px;">' +
                '<div><strong>الكاشير:</strong> ' + shift.cashierName + '</div>' +
                '<div><strong>المدة:</strong> ' + duration + '</div>' +
                '<div><strong>وقت الفتح:</strong> ' + openedAt.toLocaleString('ar-EG') + '</div>' +
                '<div><strong>وقت الإغلاق:</strong> ' + (closedAt ? closedAt.toLocaleString('ar-EG') : 'مفتوحة') + '</div>' +
                '<div><strong>العهدة:</strong> ' + fmtShift(shift.openingFloat || 0) + '</div>' +
                '<div><strong>الحالة:</strong> ' + (isOpen ? 'مفتوحة' : 'مغلقة') + '</div>' +
            '</div></div>' +
            '<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 15px;">' +
                '<div style="text-align: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px;"><div style="font-size: 10px; color: #666;">الإيرادات</div><div style="font-size: 14px; font-weight: 900;">' + fmtShift(revenue) + '</div></div>' +
                '<div style="text-align: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px;"><div style="font-size: 10px; color: #666;">الفواتير</div><div style="font-size: 14px; font-weight: 900;">' + invoices + '</div></div>' +
                '<div style="text-align: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px;"><div style="font-size: 10px; color: #666;">القطع</div><div style="font-size: 14px; font-weight: 900;">' + items + '</div></div>' +
                '<div style="text-align: center; padding: 10px; border: 1px solid #ddd; border-radius: 6px;"><div style="font-size: 10px; color: #666;">المرتجعات</div><div style="font-size: 14px; font-weight: 900;">' + fmtShift(returns) + '</div></div>' +
            '</div>' +
            '<h3 style="font-size: 14px; margin-bottom: 8px; padding-bottom: 6px; border-bottom: 1px solid #ddd;">تفصيل المدفوعات</h3>' +
            '<table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 12px;"><thead><tr style="background: #F0F0F0;">' +
                '<th style="padding: 8px; text-align: right; border: 1px solid #ddd;">الطريقة</th>' +
                '<th style="padding: 8px; text-align: center; border: 1px solid #ddd;">الفواتير</th>' +
                '<th style="padding: 8px; text-align: center; border: 1px solid #ddd;">مبيعات</th>' +
                '<th style="padding: 8px; text-align: center; border: 1px solid #ddd;">مرتجعات</th>' +
                '<th style="padding: 8px; text-align: center; border: 1px solid #ddd;">الصافي</th>' +
            '</tr></thead><tbody>' +
                (Object.keys(breakdown).length === 0
                    ? '<tr><td colspan="5" style="padding: 15px; text-align: center; color: #999; border: 1px solid #ddd;">لا توجد عمليات</td></tr>'
                    : Object.entries(breakdown).map(([method, data]) =>
                        '<tr><td style="padding: 8px; border: 1px solid #ddd;">' + method + '</td><td style="padding: 8px; text-align: center; border: 1px solid #ddd;">' + (data.count || 0) + '</td><td style="padding: 8px; text-align: center; border: 1px solid #ddd;">' + fmtShift(data.sales) + '</td><td style="padding: 8px; text-align: center; border: 1px solid #ddd;">' + (data.returns > 0 ? '-' + fmtShift(data.returns) : '—') + '</td><td style="padding: 8px; text-align: center; border: 1px solid #ddd; font-weight: 900;">' + fmtShift(data.net) + '</td></tr>'
                    ).join('')
                ) +
            '</tbody></table>' +
            '<h3 style="font-size: 14px; margin-bottom: 8px; padding-bottom: 6px; border-bottom: 1px solid #ddd;">تسوية النقدية</h3>' +
            '<table style="width: 100%; border-collapse: collapse; margin-bottom: 15px; font-size: 12px;">' +
                '<tr><td style="padding: 6px; border: 1px solid #ddd;">العهدة الابتدائية</td><td style="padding: 6px; text-align: left; border: 1px solid #ddd;">' + fmtShift(shift.openingFloat || 0) + '</td></tr>' +
                '<tr><td style="padding: 6px; border: 1px solid #ddd;">المنتظر في الدرج</td><td style="padding: 6px; text-align: left; border: 1px solid #ddd; font-weight: 900;">' + fmtShift(expectedCash) + '</td></tr>' +
                (!isOpen ?
                    '<tr><td style="padding: 6px; border: 1px solid #ddd;">الفعلي في الدرج</td><td style="padding: 6px; text-align: left; border: 1px solid #ddd;">' + fmtShift(actualCash) + '</td></tr>' +
                    '<tr style="background: ' + (diff === 0 ? '#DEF7EC' : (diff > 0 ? '#DBEAFE' : '#FEE2E2')) + ';"><td style="padding: 6px; border: 1px solid #ddd; font-weight: 900;">الفرق</td><td style="padding: 6px; text-align: left; border: 1px solid #ddd; font-weight: 900;">' + (diff >= 0 ? '+' : '') + fmtShift(diff) + '</td></tr>'
                : '') +
            '</table>' +
            (shift.note ? '<div style="background: #FEF3C7; padding: 10px; border-radius: 6px; margin-bottom: 15px; font-size: 12px;"><strong>ملاحظة:</strong> ' + shift.note + '</div>' : '') +
            '<div style="display: flex; justify-content: space-between; margin-top: 40px; padding-top: 20px; border-top: 1px dashed #333; font-size: 12px;"><div style="text-align: center;"><div style="border-top: 1px solid #333; padding-top: 5px; min-width: 120px;">توقيع الكاشير</div></div><div style="text-align: center;"><div style="border-top: 1px solid #333; padding-top: 5px; min-width: 120px;">توقيع المدير</div></div></div>' +
            '<div style="text-align: center; margin-top: 25px; font-size: 11px; color: #999;">تم الطباعة في ' + new Date().toLocaleString('ar-EG') + '</div>' +
        '</div>';

        setTimeout(() => {
            window.print();
            setTimeout(() => { printArea.style.display = 'none'; }, 500);
        }, 200);
    };

    window.updateShiftsAlertBadge = function() {
        const shifts = getShiftsRegistry();
        const withDiffCount = shifts.filter(s => s.status === 'closed' && s.difference && s.difference.total !== 0).length;
        const badge = document.getElementById('shiftsAlertBadge');
        if (!badge) return;
        if (withDiffCount > 0) {
            badge.style.display = 'inline-block';
            badge.textContent = withDiffCount;
        } else {
            badge.style.display = 'none';
        }
    };

    /* ============================================================
       STOCK MOVEMENTS SYSTEM
       ============================================================ */
    const MOVEMENT_TYPES = {
        sale:    { label: 'بيع',          icon: 'fa-cart-shopping',         color: 'sale' },
        return:  { label: 'مرتجع',        icon: 'fa-rotate-left',           color: 'return' },
        add:     { label: 'إضافة',        icon: 'fa-plus',                  color: 'add' },
        adjust:  { label: 'تسوية',        icon: 'fa-pen-to-square',         color: 'adjust' },
        reserve: { label: 'حجز',          icon: 'fa-lock',                  color: 'reserve' },
        cancel:  { label: 'إلغاء',        icon: 'fa-ban',                   color: 'cancel' },
        delete:  { label: 'حذف',          icon: 'fa-trash',                 color: 'delete' }
    };

    function logStockMovement(sku, type, qty, qtyBefore, qtyAfter, refId, note) {
        try {
            const movements = JSON.parse(localStorage.getItem('maqlis_stock_movements')) || [];
            const inventory = JSON.parse(localStorage.getItem('maqlis_inventory')) || [];
            const product = inventory.find(p => p.sku === sku);
            const admin = JSON.parse(localStorage.getItem('maqlis_currentUser'));

            movements.push({
                id: 'MOV-' + Date.now() + '-' + Math.floor(Math.random() * 10000),
                date: new Date().toISOString(),
                sku: sku,
                productName: product ? product.name : '—',
                color: product ? (product.color || '') : '',
                size: product ? (product.size || '') : '',
                type: type,
                qty: qty,
                qtyBefore: qtyBefore,
                qtyAfter: qtyAfter,
                refId: refId || null,
                userId: admin ? admin.id : null,
                userName: admin ? admin.name : 'غير معروف',
                shiftId: null,
                note: note || ''
            });

            localStorage.setItem('maqlis_stock_movements', JSON.stringify(movements));
        } catch (e) {
            console.error('Failed to log stock movement:', e);
        }
    }

    function getStockMovements() {
        try { return JSON.parse(localStorage.getItem('maqlis_stock_movements')) || []; }
        catch { return []; }
    }

    window.populateMovementFilters = function() {
        const movements = getStockMovements();
        const users = [...new Set(movements.map(m => m.userName).filter(Boolean))].sort();
        const select = document.getElementById('movFilterUser');
        if (!select) return;
        const currentVal = select.value;
        select.innerHTML = '<option value="all">جميع المستخدمين</option>';
        users.forEach(u => {
            select.innerHTML += '<option value="' + u + '">' + u + '</option>';
        });
        if (users.includes(currentVal)) select.value = currentVal;
    };

    window.updateMovementKPIs = function(movements) {
        const counts = { sale: 0, return: 0, add: 0, adjust: 0, reserve: 0, cancel: 0 };
        movements.forEach(m => {
            if (counts.hasOwnProperty(m.type)) counts[m.type]++;
        });
        const setEl = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        setEl('kpiMovSale', counts.sale);
        setEl('kpiMovReturn', counts.return);
        setEl('kpiMovAdd', counts.add);
        setEl('kpiMovAdjust', counts.adjust);
        setEl('kpiMovReserve', counts.reserve);
        setEl('kpiMovCancel', counts.cancel);
    };

    window.renderStockMovements = function() {
        const tbody = document.querySelector('#movementsTable tbody');
        const emptyState = document.getElementById('movementsEmptyState');
        if (!tbody) return;

        let movements = getStockMovements();
        movements.sort((a, b) => new Date(b.date) - new Date(a.date));

        window.populateMovementFilters();
        window.updateMovementKPIs(movements);

        const typeFilter = document.getElementById('movFilterType')?.value || 'all';
        const userFilter = document.getElementById('movFilterUser')?.value || 'all';
        const fromDate = document.getElementById('movFilterFrom')?.value || '';
        const toDate = document.getElementById('movFilterTo')?.value || '';
        const searchQuery = (document.getElementById('movFilterSearch')?.value || '').trim().toLowerCase();

        let filtered = movements;
        if (typeFilter !== 'all') filtered = filtered.filter(m => m.type === typeFilter);
        if (userFilter !== 'all') filtered = filtered.filter(m => m.userName === userFilter);
        if (fromDate) filtered = filtered.filter(m => new Date(m.date).toISOString().split('T')[0] >= fromDate);
        if (toDate) filtered = filtered.filter(m => new Date(m.date).toISOString().split('T')[0] <= toDate);

        if (searchQuery) {
            filtered = filtered.filter(m =>
                (m.sku || '').toLowerCase().includes(searchQuery) ||
                (m.productName || '').toLowerCase().includes(searchQuery) ||
                (m.refId || '').toLowerCase().includes(searchQuery) ||
                (m.note || '').toLowerCase().includes(searchQuery) ||
                (m.userName || '').toLowerCase().includes(searchQuery) ||
                (m.color || '').toLowerCase().includes(searchQuery) ||
                (m.size || '').toLowerCase().includes(searchQuery)
            );
        }

        if (filtered.length === 0) {
            tbody.innerHTML = '';
            if (emptyState) emptyState.style.display = 'block';
            return;
        }
        if (emptyState) emptyState.style.display = 'none';

        tbody.innerHTML = filtered.map(m => {
            const typeInfo = MOVEMENT_TYPES[m.type] || { label: m.type, icon: 'fa-circle', color: 'adjust' };
            const date = new Date(m.date);
            const dateStr = date.toLocaleDateString('ar-EG');
            const timeStr = date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
            const qtyClass = m.qty < 0 ? 'negative' : 'positive';
            const qtyDisplay = (m.qty > 0 ? '+' : '') + m.qty;

            return '<tr onclick="window.openStockMovementDetailModal(\'' + m.id + '\')">' +
                '<td data-label="التاريخ"><div style="font-size:12px; font-weight:700;">' + timeStr + '</div><div style="font-size:10.5px; color:var(--muted);">' + dateStr + '</div></td>' +
                '<td data-label="النوع"><span class="movement-type-badge ' + typeInfo.color + '"><i class="fa-solid ' + typeInfo.icon + '"></i> ' + typeInfo.label + '</span></td>' +
                '<td data-label="المنتج"><div style="font-weight:800; font-size:12.5px;">' + (m.productName || '—') + '</div><div style="font-size:10.5px; color:var(--muted);">' + (m.color || '') + (m.size ? ' • ' + m.size : '') + '</div><span class="movement-sku" style="margin-top:3px;">' + (m.sku || '') + '</span></td>' +
                '<td data-label="الكمية"><span class="movement-qty-badge ' + qtyClass + '">' + qtyDisplay + '</span></td>' +
                '<td data-label="قبل → بعد"><div class="movement-arrow"><span class="before">' + (m.qtyBefore || 0) + '</span> <i class="fa-solid fa-arrow-left" style="color:var(--muted); font-size:10px;"></i> <span class="after">' + (m.qtyAfter || 0) + '</span></div></td>' +
                '<td data-label="المرجع"><span style="font-family:monospace; font-size:11px; color:var(--muted);">' + (m.refId || '—') + '</span></td>' +
                '<td data-label="المستخدم"><div style="font-weight:700; font-size:12px;">' + (m.userName || '—') + '</div>' + (m.shiftId ? '<div style="font-size:10px; color:#0369A1;"><i class="fa-solid fa-cash-register"></i> ' + m.shiftId.split('-').pop() + '</div>' : '') + '</td>' +
            '</tr>';
        }).join('');
    };

    window.openStockMovementDetailModal = function(movementId) {
        const movements = getStockMovements();
        const m = movements.find(x => x.id === movementId);
        if (!m) { window.showToast('الحركة غير موجودة', 'error'); return; }

        const typeInfo = MOVEMENT_TYPES[m.type] || { label: m.type, icon: 'fa-circle', color: 'adjust' };
        const date = new Date(m.date);
        const qtyClass = m.qty < 0 ? 'negative' : 'positive';
        const qtyDisplay = (m.qty > 0 ? '+' : '') + m.qty;

        const body = document.getElementById('stockMovementDetailBody');
        body.innerHTML =
            '<div style="text-align:center; margin-bottom:20px;">' +
                '<span class="movement-type-badge ' + typeInfo.color + '" style="font-size:14px; padding:8px 18px;"><i class="fa-solid ' + typeInfo.icon + '"></i> ' + typeInfo.label + '</span>' +
            '</div>' +
            '<div class="info-row"><span class="label">📅 التاريخ والوقت</span><span class="value">' + date.toLocaleString('ar-EG') + '</span></div>' +
            '<div class="info-row"><span class="label">🏷️ المنتج</span><span class="value">' + (m.productName || '—') + '</span></div>' +
            '<div class="info-row"><span class="label">🎨 اللون والمقاس</span><span class="value">' + (m.color || '—') + ' / ' + (m.size || '—') + '</span></div>' +
            '<div class="info-row"><span class="label">🔖 SKU</span><span class="value" style="font-family:monospace; font-size:12px;">' + (m.sku || '—') + '</span></div>' +
            '<div class="info-row"><span class="label">📊 الكمية</span><span class="value"><span class="movement-qty-badge ' + qtyClass + '">' + qtyDisplay + '</span></span></div>' +
            '<div class="info-row"><span class="label">↔️ قبل → بعد</span><span class="value"><span class="movement-arrow"><span class="before">' + (m.qtyBefore || 0) + '</span> <i class="fa-solid fa-arrow-left" style="color:var(--muted); font-size:11px;"></i> <span class="after">' + (m.qtyAfter || 0) + '</span></span></span></div>' +
            '<div class="info-row"><span class="label">🔗 المرجع</span><span class="value" style="font-family:monospace; font-size:12px;">' + (m.refId || '—') + '</span></div>' +
            '<div class="info-row"><span class="label">👤 المستخدم</span><span class="value">' + (m.userName || '—') + '</span></div>' +
            (m.shiftId ? '<div class="info-row"><span class="label">💰 الوردية</span><span class="value" style="font-family:monospace;">#' + m.shiftId.split('-').pop() + '</span></div>' : '') +
            (m.note ? '<div class="movement-detail-note"><strong><i class="fa-solid fa-note-sticky"></i> ملاحظة:</strong> ' + m.note + '</div>' : '');

        const modal = document.getElementById('stockMovementDetailModal');
        modal.style.display = 'flex';
        setTimeout(() => modal.classList.add('show'), 10);
    };

    window.closeStockMovementDetailModal = function() {
        const modal = document.getElementById('stockMovementDetailModal');
        modal.classList.remove('show');
        setTimeout(() => modal.style.display = 'none', 300);
    };

    window.resetMovementFilters = function() {
        document.getElementById('movFilterType').value = 'all';
        document.getElementById('movFilterUser').value = 'all';
        document.getElementById('movFilterFrom').value = '';
        document.getElementById('movFilterTo').value = '';
        document.getElementById('movFilterSearch').value = '';
        window.renderStockMovements();
        window.showToast('تم مسح الفلاتر', 'success');
    };

    window.openProductMovements = function(sku) {
        const searchInput = document.getElementById('movFilterSearch');
        if (searchInput) searchInput.value = sku;
        window.switchPage('stock-movements', document.querySelector('[data-page="stock-movements"]'));
        window.renderStockMovements();
        window.showToast('عرض حركات المنتج: ' + sku);
    };

    window.exportStockMovementsToCSV = function() {
        const movements = getStockMovements();
        if (movements.length === 0) { window.showToast('لا توجد حركات للتصدير', 'error'); return; }

        let csv = '\uFEFF';
        csv += 'التاريخ,النوع,المنتج,اللون,المقاس,SKU,الكمية,قبل,بعد,المرجع,المستخدم,الوردية,ملاحظة\n';

        movements.sort((a, b) => new Date(b.date) - new Date(a.date)).forEach(m => {
            const typeInfo = MOVEMENT_TYPES[m.type] || { label: m.type };
            const date = new Date(m.date).toLocaleString('ar-EG');
            csv += '"' + date + '","' + typeInfo.label + '","' + (m.productName || '') + '","' + (m.color || '') + '","' + (m.size || '') + '","' + (m.sku || '') + '","' + m.qty + '","' + (m.qtyBefore || 0) + '","' + (m.qtyAfter || 0) + '","' + (m.refId || '') + '","' + (m.userName || '') + '","' + (m.shiftId ? '#' + m.shiftId.split('-').pop() : '') + '","' + (m.note || '') + '"\n';
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'maqlis-stock-movements-' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
        URL.revokeObjectURL(url);
        window.showToast('✅ تم تصدير ' + movements.length + ' حركة', 'success');
    };

    const currentUser = JSON.parse(localStorage.getItem('maqlis_currentUser'));
    if (currentUser) {
        const users = JSON.parse(localStorage.getItem('maqlis_users')) || [];
        const updated = users.find(u => u.id === currentUser.id);
        if (updated) localStorage.setItem('maqlis_currentUser', JSON.stringify(updated));
    }

    /* ============================================================
       ADMIN INTEGRATION MONITOR — read-only cross-module overview
       ============================================================ */
    window.refreshAdminSystemMonitor = function(showFeedback) {
        const statsEl = document.getElementById('adminMonitorStats');
        const alertsEl = document.getElementById('adminMonitorAlerts');
        const rowsEl = document.getElementById('adminMonitorOrders');
        if (!statsEl || !alertsEl || !rowsEl) return;
        const read = (key) => { try { const value = JSON.parse(localStorage.getItem(key) || '[]'); return Array.isArray(value) ? value : []; } catch (e) { return []; } };
        const orders = read('maqlis_pickup_orders');
        const inventory = read('maqlis_inventory');
        const couriers = read('maqlis_couriers');
        const deliveries = read('maqlis_courier_deliveries');
        const sales = read('maqlis_sales');
        const activeCouriers = couriers.filter(c => c.active !== false);
        const count = status => orders.filter(o => o.status === status).length;
        const lowStock = inventory.filter(p => Math.max(0, Number(p.qty) || 0) - Math.max(0, Number(p.reserved) || 0) <= 5).length;
        const availableUnits = inventory.reduce((sum, p) => sum + Math.max(0, (Number(p.qty) || 0) - (Number(p.reserved) || 0)), 0);
        const unsettled = deliveries.filter(d => !d.settled);
        const remitDue = unsettled.reduce((sum, d) => sum + (Number(d.cashToCashier != null ? d.cashToCashier : d.amount) || 0), 0);
        const feeDue = deliveries.reduce((sum, d) => sum + (Number(d.deliveryFee != null ? d.deliveryFee : d.courierEarning) || 0), 0);
        const cards = [
            ['قيد التجهيز', count('pending'), 'طلبات تنتظر المخزن'],
            ['جاهزة للاستلام', count('ready'), 'بانتظار الموصل أو الكاشير'],
            ['مع الموصل', count('picked_up'), 'خرجت للتوصيل'],
            ['بانتظار التوريد', count('delivered'), 'تم التسليم ولم تُسوَّ'],
            ['موصلون نشطون', activeCouriers.length, 'من إجمالي ' + couriers.length],
            ['وحدات متاحة', availableUnits, 'بعد خصم المحجوز'],
            ['أصناف منخفضة', lowStock, 'المتاح 5 قطع أو أقل'],
            ['توريد غير مسوّى', Math.round(remitDue).toLocaleString() + ' ر.ي', unsettled.length + ' عملية']
        ];
        statsEl.innerHTML = cards.map(c => '<div class="admin-monitor-stat"><div class="label">' + c[0] + '</div><div class="value">' + c[1] + '</div><div class="hint">' + c[2] + '</div></div>').join('');
        const issues = [];
        const orderIds = orders.map(o => String(o.id || '')).filter(Boolean);
        const duplicateOrders = orderIds.filter((id, i) => orderIds.indexOf(id) !== i);
        if (duplicateOrders.length) issues.push('يوجد ' + new Set(duplicateOrders).size + ' رقم طلب مكرر في سجل الطلبات.');
        const saleIds = sales.map(x => String(x.id || '')).filter(Boolean);
        if (saleIds.some((id, i) => saleIds.indexOf(id) !== i)) issues.push('يوجد رقم فاتورة مكرر في سجل المبيعات.');
        const courierIds = new Set(couriers.map(c => String(c.id)));
        const orphaned = orders.filter(o => o.courierId && !courierIds.has(String(o.courierId)) && !['completed', 'cancelled'].includes(o.status));
        if (orphaned.length) issues.push(orphaned.length + ' طلب نشط مرتبط بموصل غير موجود في سجل الموصلين.');
        const onlineUnassigned = orders.filter(o => o.source === 'online' && ['pending', 'ready'].includes(o.status) && !o.courierId);
        if (onlineUnassigned.length) issues.push(onlineUnassigned.length + ' طلب أونلاين لم يُعيَّن له موصل بعد.');
        const overReserved = inventory.filter(p => (Number(p.reserved) || 0) > (Number(p.qty) || 0));
        if (overReserved.length) issues.push(overReserved.length + ' صنف لديه كمية محجوزة أكبر من كمية المخزون.');
        const noSku = inventory.filter(p => !p.sku);
        if (noSku.length) issues.push(noSku.length + ' صنف في المخزون لا يحمل SKU.');
        const pendingNoDelivery = orders.filter(o => o.status === 'delivered' && !deliveries.some(d => String(d.orderId) === String(o.id)));
        if (pendingNoDelivery.length) issues.push(pendingNoDelivery.length + ' طلب حالته «تم التسليم» دون سجل توصيل مقابل.');
        alertsEl.innerHTML = issues.length ? issues.map(x => '<div class="admin-monitor-alert"><i class="fa-solid fa-triangle-exclamation"></i><span>' + x + '</span></div>').join('') : '<div class="admin-monitor-alert ok"><i class="fa-solid fa-circle-check"></i><span>لا توجد تعارضات أساسية مكتشفة في روابط الطلبات والمخزون والموصلين.</span></div>';
        const statusNames = { pending: 'قيد التجهيز', ready: 'جاهز', picked_up: 'مع الموصل', delivered: 'بانتظار التوريد', completed: 'مكتمل', cancelled: 'ملغي' };
        const recent = [...orders].sort((a, b) => new Date(b.updatedAt || b.deliveredAt || b.pickedUpAt || b.readyAt || b.date || 0) - new Date(a.updatedAt || a.deliveredAt || a.pickedUpAt || a.readyAt || a.date || 0)).slice(0, 8);
        const esc = v => String(v == null ? '—' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
        rowsEl.innerHTML = recent.length ? recent.map(o => {
            const date = o.updatedAt || o.deliveredAt || o.pickedUpAt || o.readyAt || o.date;
            const total = Number(o.invoiceTotal != null ? o.invoiceTotal : (Number(o.productTotal != null ? o.productTotal : o.total) || 0) + (Number(o.deliveryFee) || 0)) || 0;
            const customer = o.customer && o.customer.name ? o.customer.name : (o.customerName || '—');
            return '<tr><td style="font-family:monospace;font-weight:800">' + esc(o.id) + '</td><td>' + (o.source === 'online' ? 'أونلاين' : 'كاشير') + '</td><td>' + esc(customer) + '</td><td><span class="admin-monitor-status ' + esc(o.status) + '">' + esc(statusNames[o.status] || o.status || 'غير محدد') + '</span></td><td>' + esc(o.courierName || '—') + '</td><td style="font-weight:800">' + total.toLocaleString() + ' ر.ي</td><td>' + (date && !isNaN(new Date(date)) ? new Date(date).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }) : '—') + '</td></tr>';
        }).join('') : '<tr><td colspan="7" style="text-align:center;color:#929ba5;padding:18px">لا توجد طلبات مسجلة حتى الآن</td></tr>';
        const updated = document.getElementById('adminMonitorUpdated');
        if (updated) updated.textContent = 'آخر تحديث: ' + new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' • إجمالي أجور التوصيل المسجلة: ' + feeDue.toLocaleString() + ' ر.ي';
        if (showFeedback && typeof window.showToast === 'function') window.showToast('تم تحديث مؤشرات تكامل الأنظمة', 'success');
    };

})();
