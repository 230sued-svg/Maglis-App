(function() {
    'use strict';
    
    // ==================== STORAGE KEYS ====================
    const STORAGE = {
        users: 'maqlis_users',
        currentUser: 'maqlis_warehouseCurrent',
        pickupOrders: 'maqlis_pickup_orders',
        couriers: 'maqlis_couriers',
        inventory: 'maqlis_inventory',
        sales: 'maqlis_sales',
        shifts: 'maqlis_shifts',
        checked: 'maqlis_warehouse_checked'
    };

    // ==================== STATE ====================
    let currentUser = null;
    let allOrders = [];
    let pickedUpOrders = [];
    let deliveredOrders = [];
    let completedOrders = [];
    let inventory = [];
    let sales = [];
    let currentTab = 'pending';
    let currentFilter = 'all';
    let searchQuery = '';
    let knownOrderIds = [];
    let lastDataSignature = '';
    let checkedItems = JSON.parse(localStorage.getItem(STORAGE.checked) || '{}');
    let clockInterval = null;
    let ordersInterval = null;
    let timerUpdateInterval = null;
    let repeatAlertInterval = null;
    let audioActivated = false;
    let audioCtx = null;
    
    let completedFilters = {
        search: '', status: 'all', fromDate: '', toDate: '', cashier: 'all', expandedRows: new Set()
    };

    // Picker state
    let pickerOrderId = null;
    let pickerSelectedId = null;
    
    // ==================== HELPERS ====================
    function addOrderEvent(order, action, details) {
        if (!order) return;
        order.history = Array.isArray(order.history) ? order.history : [];
        order.history.push({ 
            action, 
            details: details || '', 
            at: new Date().toISOString(), 
            by: 'warehouse:' + (currentUser ? currentUser.username : '')
        });
    }

    function isWarehouseOrder(order) {
        if (order.orderType === 'warehouse') return true;
        if (order.orderType === 'sub_cashier') return false;
        if (order.source === 'online') return true;
        if (order.source === 'pos' && !order.subCashier) return true;
        return false;
    }
    
    function formatShiftRef(shiftId) {
        if (!shiftId) return null;
        return '#' + String(shiftId).split('-').pop();
    }
    
    function getOrderTotal(order) {
        if (order.productTotal != null && !isNaN(parseFloat(order.productTotal))) {
            return parseFloat(order.productTotal) || 0;
        }
        if (order.total != null && !isNaN(parseFloat(order.total))) {
            return parseFloat(order.total) || 0;
        }
        const linkedSale = (sales || []).find(s => String(s.id) === String(order.id));
        if (linkedSale && linkedSale.total != null && !isNaN(parseFloat(linkedSale.total))) {
            return parseFloat(linkedSale.total) || 0;
        }
        return (order.items || []).reduce((s, i) => {
            const p = parseFloat(i.price || i.sellPrice || i.unitPrice || 0);
            return s + (p * (parseInt(i.qty) || 0));
        }, 0);
    }
    
    function getOrderStatusInfo(order) {
        if (order.status === 'picked_up') {
            return { icon: 'fa-motorcycle', text: 'مع الموصل', color: '#1E40AF', bg: '#DBEAFE' };
        }
        if (order.status === 'delivered') {
            return { icon: 'fa-hourglass-half', text: 'بانتظار التوريد', color: '#92400E', bg: '#FEF3C7' };
        }
        if (order.status === 'completed') {
            return { icon: 'fa-check', text: 'تم التوريد', color: '#059669', bg: '#DEF7EC' };
        }
        if (order.status === 'cancelled') {
            return { icon: 'fa-times', text: 'ملغي', color: '#991B1B', bg: '#FEE2E2' };
        }
        return { icon: 'fa-question', text: '—', color: '#8B94A3', bg: '#F1F5F9' };
    }

    function getElapsedInfo(isoStr) {
        if (!isoStr) return { text: '', cls: 'ok' };
        const ms = Date.now() - new Date(isoStr).getTime();
        if (isNaN(ms) || ms < 0) return { text: '', cls: 'ok' };
        const mins = Math.floor(ms / 60000);
        let text;
        if (mins < 1) text = 'الآن';
        else if (mins < 60) text = mins + ' دقيقة';
        else {
            const hours = Math.floor(mins / 60);
            const remMins = mins % 60;
            text = hours + ' س' + (remMins > 0 ? ' و' + remMins + ' د' : '');
        }
        let cls = 'ok';
        if (mins >= 30 && mins < 60) cls = 'warn';
        else if (mins >= 60) cls = 'late';
        return { text, cls };
    }

    function escapeHtml(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    }
    
    // ==================== AUDIO ALERTS ====================
    document.addEventListener('click', function() {
        if (!audioActivated) {
            audioActivated = true;
            try {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                if (AudioContext && !audioCtx) audioCtx = new AudioContext();
                if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
            } catch (e) {}
        }
    }, { once: true });
    
    function playAlert() {
        if (!audioActivated) return;
        try {
            if (!audioCtx) {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                if (!AudioContext) return;
                audioCtx = new AudioContext();
            }
            if (audioCtx.state === 'suspended') audioCtx.resume();
            const notes = [880, 1046.50, 1318.51];
            notes.forEach((freq, i) => {
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, audioCtx.currentTime + (i * 0.15));
                gain.gain.setValueAtTime(0.25, audioCtx.currentTime + (i * 0.15));
                gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + (i * 0.15) + 0.3);
                osc.start(audioCtx.currentTime + (i * 0.15));
                osc.stop(audioCtx.currentTime + (i * 0.15) + 0.3);
            });
            localStorage.setItem('maqlis_last_spoken_time', Date.now());
        } catch (e) {}
    }
    
    function checkAndManageRepeatAlert() {
        const pendingOrders = allOrders.filter(o => o.status === 'pending');
        if (pendingOrders.length > 0) {
            const lastSpoken = parseInt(localStorage.getItem('maqlis_last_spoken_time') || '0');
            const now = Date.now();
            if (now - lastSpoken >= 60000) playAlert();
            if (!repeatAlertInterval) {
                repeatAlertInterval = setInterval(() => {
                    const currentPending = allOrders.filter(o => o.status === 'pending');
                    if (currentPending.length > 0) {
                        if (document.hidden) playAlert();
                    } else {
                        clearInterval(repeatAlertInterval);
                        repeatAlertInterval = null;
                    }
                }, 60000); 
            }
        } else {
            if (repeatAlertInterval) {
                clearInterval(repeatAlertInterval);
                repeatAlertInterval = null;
            }
        }
    }
    
    document.addEventListener('visibilitychange', () => {
        if (!document.hidden) {
            checkAndManageRepeatAlert();
            loadData();
        }
    });
    
    // ==================== TOAST ====================
    function showToast(msg, type) {
        type = type || 'success';
        const toast = document.createElement('div');
        toast.className = 'toast ' + (type === 'error' ? 'error' : '');
        toast.innerHTML = '<i class="fa-solid ' + (type === 'success' ? 'fa-check-circle' : 'fa-circle-exclamation') + '"></i><span>' + msg + '</span>';
        document.getElementById('toastContainer').appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 300); }, 2800);
    }
    
    // ==================== CLOCK ====================
    function updateClock() {
        const el = document.getElementById('clock');
        if (el) el.textContent = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
    
    // ==================== LOGIN ====================
    window.warehouseLogin = function() {
        const u = document.getElementById('loginUser').value.trim();
        const p = document.getElementById('loginPass').value.trim();
        const errEl = document.getElementById('loginError');
        errEl.style.display = 'none';
        if (!u || !p) { errEl.textContent = 'أدخل اسم المستخدم وكلمة المرور'; errEl.style.display = 'block'; return; }

        const users = JSON.parse(localStorage.getItem(STORAGE.users) || '[]');
        const user = users.find(x => x.username === u && x.password === p && ['warehouse','admin','stock','inventory'].includes(x.role));
        if (!user) { errEl.textContent = 'بيانات الدخول غير صحيحة أو الحساب ليس له صلاحية المخزن'; errEl.style.display = 'block'; return; }

        currentUser = user;
        localStorage.setItem(STORAGE.currentUser, JSON.stringify(user));
        enterApp();
    };

    window.warehouseLogout = function() {
        if (!confirm('تسجيل الخروج من شاشة المخزن؟')) return;
        localStorage.removeItem(STORAGE.currentUser);
        location.reload();
    };

    function enterApp() {
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('app-container').classList.add('active');
        document.getElementById('currentUserName').textContent = currentUser.username || 'مستخدم';
        updateClock();
        clockInterval = setInterval(updateClock, 1000);
        loadData();
        ordersInterval = setInterval(() => {
            if (!document.hidden) loadData();
        }, 3000);
        timerUpdateInterval = setInterval(updateTimersOnly, 1000);

        window.addEventListener('storage', (e) => {
            if ([STORAGE.pickupOrders, STORAGE.couriers, STORAGE.inventory].includes(e.key)) {
                loadData();
            }
        });
    }
    
    // ==================== LOAD DATA ====================
    function computeDataSignature(warehouseOnly) {
        return JSON.stringify(warehouseOnly.map(o => [
            o.id, o.status, o.courierId, o.pickedUpAt, o.deliveredAt, o.completedAt,
            o.items ? o.items.length : 0, o.deliveryFailureReason || '', o.deliveryFee || 0
        ]));
    }

    function loadData() {
        inventory = JSON.parse(localStorage.getItem(STORAGE.inventory)) || [];
        sales = JSON.parse(localStorage.getItem(STORAGE.sales)) || [];
        
        const raw = JSON.parse(localStorage.getItem(STORAGE.pickupOrders)) || [];
        const warehouseOnly = raw.filter(isWarehouseOrder);
        
        const newSig = computeDataSignature(warehouseOnly);
        const dataChanged = newSig !== lastDataSignature;
        
        if (dataChanged) {
            allOrders = warehouseOnly.filter(o => ['pending','ready'].includes(o.status));
            
            pickedUpOrders = warehouseOnly.filter(o => o.status === 'picked_up' && o.pickedUpAt);
            pickedUpOrders.sort((a, b) => new Date(a.pickedUpAt) - new Date(b.pickedUpAt));
            
            deliveredOrders = warehouseOnly.filter(o => o.status === 'delivered' && o.deliveredAt);
            deliveredOrders.sort((a, b) => new Date(b.deliveredAt) - new Date(a.deliveredAt));
            
            completedOrders = warehouseOnly.filter(o => o.status === 'completed' && o.completedAt);
            completedOrders.sort((a, b) => new Date(b.completedAt) - new Date(a.completedAt));
            
            const newOrders = allOrders.filter(o => !knownOrderIds.includes(o.id) && o.status === 'pending');
            if (newOrders.length > 0 && knownOrderIds.length > 0) {
                playAlert();
                showToast('🔔 ' + newOrders.length + ' طلب جديد', 'success');
            }
            knownOrderIds = allOrders.map(o => o.id);
            
            checkAndManageRepeatAlert();
            populateCompletedCashierFilter();
            lastDataSignature = newSig;
            render();
        } else {
            updateCountsOnly();
        }
        
        // تحديث عدد الموصلين دائماً (خفيف)
        const cCountEl = document.getElementById('tabCouriersCount');
        if (cCountEl) cCountEl.textContent = getAllCouriers().filter(c => c.active !== false).length;
        
        // إعادة رسم تبويب الموصلين إن كان مفتوحاً (لأن الإحصائيات تتغير)
        if (currentTab === 'couriers') renderCouriersTab();
    }

    function updateCountsOnly() {
        const filtered = allOrders.filter(matchesFilter);
        const pending = filtered.filter(o => o.status === 'pending');
        const ready = filtered.filter(o => o.status === 'ready');
        const pendingItems = pending.reduce((sum, o) => sum + o.items.reduce((s, i) => s + i.qty, 0), 0);
        
        const elP = document.getElementById('statPending'); if (elP) elP.textContent = pending.length;
        const elR = document.getElementById('statReady'); if (elR) elR.textContent = ready.length;
        const elT = document.getElementById('statTransit'); if (elT) elT.textContent = pickedUpOrders.length;
        const elI = document.getElementById('statItems'); if (elI) elI.textContent = pendingItems;
        const tP = document.getElementById('tabPendingCount'); if (tP) tP.textContent = pending.length;
        const tR = document.getElementById('tabReadyCount'); if (tR) tR.textContent = ready.length;
        const tT = document.getElementById('tabTransitCount'); if (tT) tT.textContent = pickedUpOrders.length;
        const tC = document.getElementById('tabCompletedCount'); if (tC) tC.textContent = deliveredOrders.length + completedOrders.length;
    }

    function updateTimersOnly() {
        allOrders.forEach(order => {
            if (order.status !== 'pending') return;
            const el = document.querySelector('.timer[data-timer-id="' + CSS.escape(order.id) + '"]');
            if (!el) return;
            const t = calculateTimer(order.date);
            el.textContent = t.text;
            el.className = 'timer ' + t.cls;
        });
        pickedUpOrders.forEach(order => {
            const el = document.querySelector('.elapsed[data-elapsed-id="' + CSS.escape(order.id) + '"]');
            if (!el) return;
            const info = getElapsedInfo(order.pickedUpAt);
            el.textContent = info.text;
            el.className = 'elapsed ' + info.cls;
        });
    }
    
    // ==================== TABS / FILTERS ====================
    window.switchTab = function(tab, btn) {
        currentTab = tab;
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        const target = document.getElementById('tab-' + tab);
        if (target) target.classList.add('active');
        if (tab === 'couriers') renderCouriersTab();
        else render();
    };
    
    window.setFilter = function(filter, btn) {
        currentFilter = filter;
        document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
        render();
    };
    
    window.applyFilters = function() {
        searchQuery = document.getElementById('searchInput').value.trim().toLowerCase();
        render();
    };
    
    window.manualRefresh = function(btn) {
        btn.classList.add('spinning');
        loadData();
        setTimeout(() => btn.classList.remove('spinning'), 600);
        showToast('تم التحديث', 'success');
    };
    
    function matchesFilter(o) {
        if (currentFilter !== 'all' && o.source !== currentFilter) return false;
        if (searchQuery) {
            const orderNum = o.id.split('-').pop().toLowerCase();
            const customerNo = o.customerNo ? String(o.customerNo) : '';
            const cashier = (o.subCashier || o.cashier || '').toLowerCase();
            const onlineName = o.customer ? (o.customer.name || '').toLowerCase() : '';
            const courierName = (o.courierName || '').toLowerCase();
            return orderNum.includes(searchQuery) || customerNo.includes(searchQuery) || cashier.includes(searchQuery) || onlineName.includes(searchQuery) || courierName.includes(searchQuery) || o.id.toLowerCase().includes(searchQuery);
        }
        return true;
    }
    
    function findInvoiceForOrder(pickupOrderId) {
        return sales.find(s => s.originalPickupOrder === pickupOrderId);
    }
    
    // ==================== RENDER MAIN ====================
    function render() {
        const filtered = allOrders.filter(matchesFilter);
        const pending = filtered.filter(o => o.status === 'pending');
        const ready = filtered.filter(o => o.status === 'ready');
        const transit = pickedUpOrders.filter(matchesFilter);
        
        pending.sort((a, b) => new Date(a.date) - new Date(b.date));
        ready.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        const pendingItems = pending.reduce((sum, o) => sum + o.items.reduce((s, i) => s + i.qty, 0), 0);
        document.getElementById('statPending').textContent = pending.length;
        document.getElementById('statReady').textContent = ready.length;
        document.getElementById('statTransit').textContent = pickedUpOrders.length;
        document.getElementById('statItems').textContent = pendingItems;
        document.getElementById('tabPendingCount').textContent = pending.length;
        document.getElementById('tabReadyCount').textContent = ready.length;
        document.getElementById('tabTransitCount').textContent = pickedUpOrders.length;
        
        const pendingGrid = document.getElementById('pendingGrid');
        if (pending.length === 0) {
            pendingGrid.innerHTML = '<div class="empty-state pending-empty" style="grid-column: 1/-1;"><div class="empty-icon"><i class="fa-solid fa-hourglass-half"></i></div><h3>لا توجد طلبات قيد التجهيز</h3><p>الشاشة جاهزة لاستقبال الطلبات.</p></div>';
        } else {
            pendingGrid.innerHTML = pending.map(o => renderCard(o, 'pending')).join('');
        }
        
        const readyGrid = document.getElementById('readyGrid');
        if (ready.length === 0) {
            readyGrid.innerHTML = '<div class="empty-state ready-empty" style="grid-column: 1/-1;"><div class="empty-icon"><i class="fa-solid fa-check-double"></i></div><h3>لا توجد طلبات جاهزة</h3><p>بعد تجهيز الطلبات، ستنتقل إلى هنا.</p></div>';
        } else {
            readyGrid.innerHTML = ready.map(o => renderCard(o, 'ready')).join('');
        }
        
        const transitGrid = document.getElementById('transitGrid');
        if (transit.length === 0) {
            transitGrid.innerHTML = '<div class="empty-state transit-empty" style="grid-column: 1/-1;"><div class="empty-icon"><i class="fa-solid fa-motorcycle"></i></div><h3>لا توجد طلبات مع الموصل</h3><p>عندما يستلم الموصل طلباً من المخزن سيظهر هنا حتى تسليمه.</p></div>';
        } else {
            transitGrid.innerHTML = transit.map(o => renderTransitCard(o)).join('');
        }
        
        renderCompletedTab();
    }
    
    // ==================== COMPLETED FILTER ====================
    function populateCompletedCashierFilter() {
        const select = document.getElementById('completedCashierFilter');
        if (!select) return;
        const allPeople = [...pickedUpOrders, ...deliveredOrders, ...completedOrders];
        const cashiers = [...new Set(allPeople.map(o => o.subCashier || o.cashier).filter(Boolean))];
        const currentVal = select.value;
        select.innerHTML = '<option value="all">جميع الكاشيرين</option>';
        cashiers.sort().forEach(c => {
            select.innerHTML += '<option value="' + c + '">' + c + '</option>';
        });
        if (cashiers.includes(currentVal)) select.value = currentVal;
    }
    
    window.applyCompletedFilters = function() {
        completedFilters.search = (document.getElementById('completedSearch').value || '').trim().toLowerCase();
        completedFilters.status = document.getElementById('completedStatusFilter').value;
        completedFilters.fromDate = document.getElementById('completedFromDate').value;
        completedFilters.toDate = document.getElementById('completedToDate').value;
        completedFilters.cashier = document.getElementById('completedCashierFilter').value;
        renderCompletedTab();
    };
    
    window.clearCompletedFilters = function() {
        document.getElementById('completedSearch').value = '';
        document.getElementById('completedStatusFilter').value = 'all';
        document.getElementById('completedFromDate').value = '';
        document.getElementById('completedToDate').value = '';
        document.getElementById('completedCashierFilter').value = 'all';
        completedFilters = { search: '', status: 'all', fromDate: '', toDate: '', cashier: 'all', expandedRows: new Set() };
        renderCompletedTab();
        showToast('تم مسح الفلاتر', 'success');
    };
    
    window.toggleDetailRow = function(invoiceId, event) {
        if (event) event.stopPropagation();
        const row = document.querySelector('tr.main-row[data-invoice-id="' + invoiceId + '"]');
        const detailRow = document.querySelector('tr.detail-row[data-detail-for="' + invoiceId + '"]');
        if (!row || !detailRow) return;
        
        if (detailRow.classList.contains('open')) {
            detailRow.classList.remove('open');
            row.classList.remove('expanded');
            completedFilters.expandedRows.delete(invoiceId);
        } else {
            detailRow.classList.add('open');
            row.classList.add('expanded');
            completedFilters.expandedRows.add(invoiceId);
        }
    };
    
    function getCompletedFilteredList() {
        const combined = [...deliveredOrders, ...completedOrders];
        
        return combined.filter(o => {
            if (completedFilters.status !== 'all' && o.status !== completedFilters.status) return false;
            
            const dateToCheck = o.completedAt || o.deliveredAt;
            if (completedFilters.fromDate) {
                const from = new Date(completedFilters.fromDate);
                from.setHours(0, 0, 0, 0);
                if (new Date(dateToCheck) < from) return false;
            }
            if (completedFilters.toDate) {
                const to = new Date(completedFilters.toDate);
                to.setHours(23, 59, 59, 999);
                if (new Date(dateToCheck) > to) return false;
            }
            const cashierName = o.subCashier || o.cashier || '';
            if (completedFilters.cashier !== 'all' && cashierName !== completedFilters.cashier) return false;
            
            if (completedFilters.search) {
                const q = completedFilters.search;
                const invoice = findInvoiceForOrder(o.id);
                const invoiceId = (invoice?.id || '').toLowerCase();
                const customerName = (o.customer?.name || '').toLowerCase();
                const customerNo = o.customerNo ? String(o.customerNo) : '';
                const cashierMatch = cashierName.toLowerCase().includes(q);
                const courierMatch = (o.courierName || '').toLowerCase().includes(q);
                const orderNum = o.id.split('-').pop().toLowerCase();
                const itemsMatch = o.items.some(item => 
                    (item.name || '').toLowerCase().includes(q) ||
                    (item.sku || '').toLowerCase().includes(q) ||
                    (item.color || '').toLowerCase().includes(q) ||
                    (item.size || '').toLowerCase().includes(q)
                );
                if (!invoiceId.includes(q) && !customerName.includes(q) && !customerNo.includes(q) && !cashierMatch && !courierMatch && !orderNum.includes(q) && !itemsMatch) return false;
            }
            return true;
        }).sort((a, b) => {
            const da = a.completedAt || a.deliveredAt;
            const db = b.completedAt || b.deliveredAt;
            return new Date(db) - new Date(da);
        });
    }
    
    // ==================== RENDER COMPLETED TAB ====================
    function renderCompletedTab() {
        const wrapper = document.getElementById('completedWrapper');
        const statsEl = document.getElementById('completedStats');
        if (!wrapper) return;
        
        const list = getCompletedFilteredList();
        const tabCount = document.getElementById('tabCompletedCount');
        if (tabCount) tabCount.textContent = deliveredOrders.length + completedOrders.length;
        
        const totalItems = list.reduce((sum, o) => sum + o.items.reduce((s, i) => s + i.qty, 0), 0);
        const pendingRemitCount = list.filter(o => o.status === 'delivered').length;
        const remittedCount = list.filter(o => o.status === 'completed').length;
        const totalAmount = list.reduce((sum, o) => sum + getOrderTotal(o), 0);
        
        if (statsEl) {
            statsEl.innerHTML = 
                '<div class="cs-card cs-orders"><span class="cs-label"><i class="fa-solid fa-receipt"></i> إجمالي الطلبات</span><span class="cs-value">' + list.length + '</span></div>' +
                '<div class="cs-card" style="background:#FEF3C7;border-right-color:#D97706;"><span class="cs-label" style="color:#92400E;"><i class="fa-solid fa-hourglass-half"></i> بانتظار التوريد</span><span class="cs-value" style="color:#92400E;">' + pendingRemitCount + '</span></div>' +
                '<div class="cs-card" style="background:#DEF7EC;border-right-color:#059669;"><span class="cs-label" style="color:#059669;"><i class="fa-solid fa-check-circle"></i> تم التوريد</span><span class="cs-value" style="color:#059669;">' + remittedCount + '</span></div>' +
                '<div class="cs-card cs-items"><span class="cs-label"><i class="fa-solid fa-box"></i> القطع</span><span class="cs-value">' + totalItems + '</span></div>' +
                '<div class="cs-card cs-amount" style="background:linear-gradient(135deg,#FFFEF9,#FFF9E6);border-right-color:#C9A961;"><span class="cs-label" style="color:#B08D45;"><i class="fa-solid fa-coins"></i> الإجمالي</span><span class="cs-value" style="color:#B08D45;font-size:15px;">' + totalAmount.toLocaleString('en-US') + '</span></div>';
        }
        
        if (list.length === 0) {
            const hasAny = (deliveredOrders.length + completedOrders.length) > 0;
            wrapper.innerHTML = '<div class="empty-state completed-empty"><div class="empty-icon"><i class="fa-solid fa-circle-check"></i></div><h3>لا توجد طلبات مطابقة</h3><p>' + (hasAny ? 'لا توجد نتائج تطابق الفلاتر الحالية.' : 'ستظهر هنا الطلبات المسلّمة والمسوّاة.') + '</p></div>';
            return;
        }
        
        wrapper.innerHTML = '<table class="completed-table"><thead><tr>' +
                '<th style="width:50px;"></th>' +
                '<th>رقم الفاتورة</th>' +
                '<th>العميلة</th>' +
                '<th>الكاشير / الموصل</th>' +
                '<th>القطع</th>' +
                '<th>المبلغ</th>' +
                '<th>الحالة</th>' +
                '<th>الوقت</th>' +
            '</tr></thead><tbody>' +
            list.map(o => {
                const invoice = findInvoiceForOrder(o.id);
                const invoiceId = invoice ? invoice.id : '—';
                const itemsCount = o.items.reduce((s, i) => s + i.qty, 0);
                const customer = o.customer ? o.customer.name : (o.customerNo ? 'زبونة #' + o.customerNo : '—');
                const cashier = o.subCashier || o.cashier || '—';
                const courier = o.courierName || null;
                const total = getOrderTotal(o);
                const status = getOrderStatusInfo(o);
                const timeSource = o.completedAt || o.deliveredAt;
                const time = new Date(timeSource).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
                const dateStr = new Date(timeSource).toLocaleDateString('ar-EG');
                const isExpanded = completedFilters.expandedRows.has(invoiceId);
                
                const detailItems = o.items.map(item => 
                    '<div class="detail-item">' +
                        '<div class="di-left">' +
                            '<div class="di-name">' + item.name + '</div>' +
                            '<div class="di-meta">' +
                                (item.color ? '<span><i class="fa-solid fa-palette"></i> ' + item.color + '</span>' : '') +
                                (item.size ? '<span><i class="fa-solid fa-ruler"></i> ' + item.size + '</span>' : '') +
                                '<span class="di-sku">' + item.sku + '</span>' +
                            '</div>' +
                        '</div>' +
                        '<span class="di-qty">× ' + item.qty + '</span>' +
                    '</div>'
                ).join('');
                
                return '<tr class="main-row ' + (isExpanded ? 'expanded' : '') + '" data-invoice-id="' + invoiceId + '" onclick="toggleDetailRow(\'' + invoiceId + '\', event)">' +
                        '<td style="text-align:center;"><i class="fa-solid fa-chevron-down expand-icon"></i></td>' +
                        '<td><span class="inv-number">' + invoiceId + '</span></td>' +
                        '<td><div class="completed-customer"><strong>' + customer + '</strong>' + (o.customerNo ? '<span>زبونة #' + o.customerNo + '</span>' : '') + '</div></td>' +
                        '<td>' +
                            '<strong>' + cashier + '</strong>' +
                            (o.shiftId ? '<div style="font-size:10px; color:#0369A1; margin-top:2px;"><i class="fa-solid fa-cash-register"></i> ' + formatShiftRef(o.shiftId) + '</div>' : '') +
                            (courier ? '<div style="font-size:10px; color:#B08D45; margin-top:2px;"><i class="fa-solid fa-motorcycle"></i> ' + courier + '</div>' : '') +
                        '</td>' +
                        '<td><strong>' + itemsCount + '</strong> قطعة</td>' +
                        '<td><strong style="color:#B08D45;">' + total.toLocaleString('en-US') + '</strong></td>' +
                        '<td><span style="background:' + status.bg + ';color:' + status.color + ';padding:4px 10px;border-radius:20px;font-size:10.5px;font-weight:800;display:inline-flex;align-items:center;gap:4px;white-space:nowrap;"><i class="fa-solid ' + status.icon + '"></i> ' + status.text + '</span></td>' +
                        '<td><div class="completed-time"><i class="fa-regular fa-clock"></i> ' + time + '</div><div style="font-size:10px;color:var(--muted);">' + dateStr + '</div></td>' +
                    '</tr>' +
                    '<tr class="detail-row ' + (isExpanded ? 'open' : '') + '" data-detail-for="' + invoiceId + '">' +
                        '<td colspan="8">' +
                            '<div class="detail-content">' +
                                '<h4><i class="fa-solid fa-box-open" style="color:var(--gold);"></i> تفاصيل القطع (' + o.items.length + ' صنف)</h4>' +
                                '<div class="detail-items">' + detailItems + '</div>' +
                            '</div>' +
                        '</td>' +
                    '</tr>';
            }).join('') +
            '</tbody></table>';
    }
    
    // ==================== STOCK ====================
    function getCurrentStock(sku) {
        const item = inventory.find(i => i.sku === sku);
        return item ? item.qty : 0;
    }
    
    // ==================== COURIERS ====================
    function getAllCouriers() {
        return JSON.parse(localStorage.getItem(STORAGE.couriers) || '[]') || [];
    }

    function getCourierStats(courierId) {
        const cid = String(courierId);
        const inHand = pickedUpOrders.filter(o => String(o.courierId) === cid).length;
        const todayStr = new Date().toDateString();
        const allDeliveries = [...deliveredOrders, ...completedOrders];
        const todayCount = allDeliveries.filter(o =>
            String(o.courierId) === cid && new Date(o.deliveredAt).toDateString() === todayStr
        ).length;
        const unsettled = deliveredOrders.filter(o => String(o.courierId) === cid);
        return { inHand, today: todayCount, unsettled: unsettled.length };
    }

    window.renderCouriersTab = function() {
        const grid = document.getElementById('couriersGrid');
        if (!grid) return;
        const searchEl = document.getElementById('courierSearchInput');
        const q = (searchEl ? searchEl.value : '').trim().toLowerCase();
        const all = getAllCouriers();
        let filtered = all;
        if (q) {
            filtered = all.filter(c =>
                (c.name || '').toLowerCase().includes(q) ||
                (c.phone || '').toLowerCase().includes(q) ||
                (c.areas || []).some(a => (a || '').toLowerCase().includes(q))
            );
        }
        const countEl = document.getElementById('tabCouriersCount');
        if (countEl) countEl.textContent = all.filter(c => c.active !== false).length;

        if (!filtered.length) {
            grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><div class="empty-icon"><i class="fa-solid fa-users"></i></div><h3>لا يوجد موصلون</h3><p>' + (q ? 'لا نتائج مطابقة للبحث.' : 'أضف موصلين من لوحة الإدارة.') + '</p></div>';
            return;
        }

        grid.innerHTML = filtered.map(c => {
            const stats = getCourierStats(c.id);
            const isActive = c.active !== false;
            const isBusy = stats.inHand > 0;
            const statusCls = !isActive ? 'inactive' : (isBusy ? 'busy' : 'free');
            const statusText = !isActive ? 'معطّل' : (isBusy ? 'مشغول' : 'متاح');
            const areas = (c.areas || []).filter(Boolean).join(' • ') || 'بدون مناطق';
            return '<div class="courier-card ' + statusCls + '">' +
                '<div class="courier-header">' +
                    '<div class="courier-name">' + escapeHtml(c.name || '—') + '</div>' +
                    '<span class="courier-status-badge ' + statusCls + '">' + statusText + '</span>' +
                '</div>' +
                '<div class="courier-contact">' +
                    (c.phone ? '<div><i class="fa-solid fa-phone"></i> ' + escapeHtml(c.phone) + '</div>' : '') +
                    '<div><i class="fa-solid fa-location-dot"></i> ' + escapeHtml(areas) + '</div>' +
                '</div>' +
                '<div class="courier-stats-mini">' +
                    '<div class="courier-stat-mini' + (stats.inHand > 0 ? ' highlight' : '') + '"><div class="v">' + stats.inHand + '</div><div class="l">في اليد</div></div>' +
                    '<div class="courier-stat-mini"><div class="v">' + stats.today + '</div><div class="l">اليوم</div></div>' +
                    '<div class="courier-stat-mini"><div class="v">' + stats.unsettled + '</div><div class="l">غير مسوّى</div></div>' +
                '</div>' +
                '<div class="courier-actions">' +
                    '<button class="btn-show-orders" ' + (stats.inHand === 0 ? 'disabled' : '') + ' onclick="showCourierOrders(\'' + c.id + '\')"><i class="fa-solid fa-list"></i> طلباته (' + stats.inHand + ')</button>' +
                '</div>' +
            '</div>';
        }).join('');
    };

    window.showCourierOrders = function(courierId) {
        const courier = getAllCouriers().find(c => String(c.id) === String(courierId));
        if (!courier) return showToast('الموصل غير موجود', 'error');
        const orders = pickedUpOrders.filter(o => String(o.courierId) === String(courierId));
        if (!orders.length) return showToast('لا يوجد طلبات حالياً مع هذا الموصل', 'error');
        document.getElementById('searchInput').value = courier.name;
        searchQuery = courier.name.toLowerCase();
        switchTab('transit', document.querySelector('.tab-btn.transit-tab'));
        showToast('عرض طلبات ' + courier.name, 'success');
    };

    // ==================== COURIER PICKER MODAL ====================
    window.openCourierPicker = function(orderId, event) {
        if (event) event.stopPropagation();
        pickerOrderId = orderId;
        pickerSelectedId = null;
        const orders = JSON.parse(localStorage.getItem(STORAGE.pickupOrders) || '[]');
        const order = orders.find(o => String(o.id) === String(orderId));
        if (!order) return showToast('الطلب غير موجود', 'error');
        if (order.pickedUpAt) return showToast('الطلب مستلم بالفعل', 'error');

        document.getElementById('courierPickerTitle').textContent = 'تعيين موصل لطلب REQ-' + order.id.split('-').pop();
        document.getElementById('courierPickerSearch').value = '';
        document.getElementById('courierPickerFee').value = parseFloat(order.deliveryFee) || 0;
        document.getElementById('courierPickerSaveBtn').disabled = true;
        document.getElementById('courierPickerModal').classList.add('open');
        renderCourierPickerList();
        setTimeout(() => document.getElementById('courierPickerSearch').focus(), 100);
    };

    window.closeCourierPicker = function() {
        document.getElementById('courierPickerModal').classList.remove('open');
        pickerOrderId = null;
        pickerSelectedId = null;
    };

    function renderCourierPickerList() {
        const list = document.getElementById('courierPickerList');
        const q = (document.getElementById('courierPickerSearch').value || '').trim().toLowerCase();
        let couriers = getAllCouriers().filter(c => c.active !== false);
        if (q) {
            couriers = couriers.filter(c =>
                (c.name || '').toLowerCase().includes(q) ||
                (c.phone || '').toLowerCase().includes(q) ||
                (c.areas || []).some(a => (a || '').toLowerCase().includes(q))
            );
        }
        if (!couriers.length) {
            list.innerHTML = '<div style="text-align:center;padding:30px 10px;color:var(--muted);font-size:13px;">' + (q ? 'لا نتائج مطابقة' : 'لا يوجد موصلون نشطون') + '</div>';
            return;
        }
        list.innerHTML = couriers.map(c => {
            const stats = getCourierStats(c.id);
            const isSel = String(c.id) === String(pickerSelectedId);
            const badgeCls = stats.inHand > 0 ? 'busy' : 'free';
            const badgeTxt = stats.inHand > 0 ? stats.inHand + ' في اليد' : 'متاح';
            return '<div class="courier-pick-item ' + (isSel ? 'selected' : '') + '" onclick="selectCourierInPicker(\'' + c.id + '\')">' +
                '<div class="info">' +
                    '<div class="name">' + escapeHtml(c.name || '—') + '</div>' +
                    '<div class="meta">' + (c.phone ? escapeHtml(c.phone) + ' • ' : '') + escapeHtml((c.areas || []).join(' • ') || 'بدون مناطق') + '</div>' +
                '</div>' +
                '<span class="badge-mini ' + badgeCls + '">' + badgeTxt + '</span>' +
            '</div>';
        }).join('');
    }

    window.selectCourierInPicker = function(courierId) {
        pickerSelectedId = courierId;
        document.getElementById('courierPickerSaveBtn').disabled = false;
        renderCourierPickerList();
    };

    window.confirmCourierAssign = function() {
        if (!pickerSelectedId) return showToast('اختر موصلاً أولاً', 'error');
        const feeInput = document.getElementById('courierPickerFee');
        const deliveryFee = Number(feeInput.value);
        if (!Number.isFinite(deliveryFee) || deliveryFee < 0) return showToast('أدخل رسوم توصيل صحيحة', 'error');

        const orders = JSON.parse(localStorage.getItem(STORAGE.pickupOrders) || '[]');
        const idx = orders.findIndex(o => String(o.id) === String(pickerOrderId));
        if (idx < 0) return showToast('الطلب غير موجود', 'error');
        const order = orders[idx];
        if (order.pickedUpAt) return showToast('الطلب مستلم بالفعل — لا يمكن تغيير الموصل', 'error');

        const courier = getAllCouriers().find(c => String(c.id) === String(pickerSelectedId));
        if (!courier) return showToast('الموصل غير موجود', 'error');

        const productTotal = getOrderTotal(order);
        order.productTotal = productTotal;
        order.total = productTotal;
        order.deliveryFee = deliveryFee;
        order.invoiceTotal = productTotal + deliveryFee;
        order.courierId = courier.id;
        order.courierName = courier.name;
        order.assignedAt = new Date().toISOString();
        order.assignedBy = 'warehouse:' + (currentUser ? currentUser.username : '');
        addOrderEvent(order, 'courier_assigned', 'تم تعيين ' + courier.name + ' برسوم توصيل ' + deliveryFee);
        localStorage.setItem(STORAGE.pickupOrders, JSON.stringify(orders));
        showToast('✅ تم تعيين ' + courier.name + ' — رسوم ' + deliveryFee + ' ر.ي', 'success');
        closeCourierPicker();
        loadData();
    };

    // ==================== RENDER COURIER ASSIGNMENT BLOCK ====================
    function renderCourierAssignment(order) {
        const isOnline = order.source === 'online';
        const productTotal = getOrderTotal(order);
        const deliveryFee = Math.max(0, parseFloat(order.deliveryFee) || 0);
        const invoiceTotal = productTotal + deliveryFee;
        const locked = !!order.pickedUpAt || !!order.deliveredAt || ['delivered','completed'].includes(order.status);
        const orderIdJs = "'" + String(order.id).replace(/\\/g, "\\\\").replace(/'/g, "\\'") + "'";

        const btnBg = locked ? '#F1F5F9' : (order.courierId ? '#EFF6FF' : '#2563EB');
        const btnColor = locked ? '#94A3B8' : (order.courierId ? '#1E40AF' : 'white');
        const btnText = locked ? 'تم قفل التعيين' :
            (order.courierId ? 'تغيير الموصل (' + escapeHtml(order.courierName || '') + ')' : 'اختر موصلاً');
        const btnIcon = order.courierId ? 'user-pen' : 'user-plus';

        return '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:10px;padding:10px;' +
            (isOnline ? 'background:#EFF6FF;border:1px solid #BFDBFE;' : 'background:#FFFBEB;border:1px solid #FDE68A;') +
            'border-radius:10px;">' +
            '<div style="width:100%;display:flex;gap:12px;flex-wrap:wrap;font-size:11.5px;color:#334155;">' +
                '<span>قيمة الطلب: <b>' + productTotal.toLocaleString('en-US') + ' ر.ي</b></span>' +
                '<span>رسوم الموصل: <b>' + deliveryFee.toLocaleString('en-US') + ' ر.ي</b></span>' +
                '<span>إجمالي الفاتورة: <b>' + invoiceTotal.toLocaleString('en-US') + ' ر.ي</b></span>' +
            '</div>' +
            '<button ' + (locked ? 'disabled' : '') + ' onclick="openCourierPicker(' + orderIdJs + ', event)" ' +
                'style="width:100%;padding:11px 14px;border:0;border-radius:9px;background:' + btnBg + ';color:' + btnColor + ';font-weight:800;cursor:' + (locked ? 'not-allowed' : 'pointer') + ';font-family:inherit;font-size:12.5px;">' +
                '<i class="fa-solid fa-' + btnIcon + '"></i> ' + btnText +
            '</button>' +
            (!isOnline && !order.courierId ? '<span style="width:100%;font-size:10.5px;color:#92400E;">ℹ️ سيظهر لكل الموصلين عند التحويل لجاهز</span>' : '') +
            (isOnline && !order.courierId && !locked ? '<span style="width:100%;font-size:10.5px;color:#B45309;font-weight:700;">⚠️ لا يمكن التحويل لجاهز قبل تعيين سائق</span>' : '') +
        '</div>';
    }

    // ==================== CALCULATE TIMER ====================
    function calculateTimer(startIso) {
        const elapsed = (Date.now() - new Date(startIso).getTime()) / 60000;
        const mins = Math.floor(elapsed);
        let cls = 'fresh', text;
        if (mins < 5) { cls = 'fresh'; text = mins + 'د'; }
        else if (mins < 15) { cls = 'medium'; text = mins + 'د'; }
        else { cls = 'urgent'; text = mins + 'د'; }
        return { mins, cls, text };
    }
    
    // ==================== RENDER CARD (pending/ready) ====================
    function renderCard(order, mode) {
        const isOnline = order.source === 'online';
        const cashierName = order.subCashier || order.cashier || 'غير محدد';
        const customerNo = order.customerNo;
        const orderShort = order.id.split('-').pop();
        const timer = calculateTimer(order.date);
        const checked = checkedItems[order.id] || [];
        const isReady = mode === 'ready';
        const isLate = timer.mins >= 15 && !isReady;
        const isNew = (Date.now() - new Date(order.date).getTime()) < 30000 && !isReady;
        const totalItems = order.items.reduce((s, i) => s + i.qty, 0);
        const requestTime = new Date(order.date).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
        const shiftRef = order.shiftId ? formatShiftRef(order.shiftId) : null;
        const totalAmount = getOrderTotal(order);
        const wasReturned = !!order.deliveryFailedAt;
        
        let customerHtml = '';
        if (isOnline && order.customer) {
            customerHtml = '<div class="customer-info">' +
                '<div><i class="fa-solid fa-user"></i> <strong>' + (order.customer.name || '—') + '</strong></div>' +
                (order.customer.phone ? '<div><i class="fa-solid fa-phone"></i> ' + order.customer.phone + '</div>' : '') +
                (order.customer.address ? '<div><i class="fa-solid fa-location-dot"></i> ' + (order.customer.city || '') + ' ' + order.customer.address + '</div>' : '') +
                '</div>';
        }
        
        const cardClasses = [
            'order-card',
            isOnline ? 'online-order' : 'pos-order',
            isReady ? 'is-ready' : '',
            isLate ? 'is-late' : '',
            isNew ? 'is-new' : '',
            wasReturned && !isReady ? 'is-returned' : ''
        ].filter(Boolean).join(' ');
        
        let returnedHtml = '';
        if (wasReturned) {
            returnedHtml = '<div class="returned-info">' +
                '<div><i class="fa-solid fa-triangle-exclamation"></i> <strong>مُعاد من الموصل:</strong> ' + (order.lastCourierName || 'موصل') + '</div>' +
                '<div><i class="fa-solid fa-comment-dots"></i> السبب: ' + (order.deliveryFailureReason || '—') + '</div>' +
                '</div>';
        }
        
        const itemsHtml = order.items.map(item => {
            const stock = getCurrentStock(item.sku);
            const isChecked = checked.includes(item.sku);
            let stockClass = '';
            let stockText = '';
            if (stock <= 0) { stockClass = 'out-stock'; stockText = '⚠️ غير متوفر'; }
            else if (stock < item.qty) { stockClass = 'low-stock'; stockText = '⚠️ متوفر ' + stock; }
            
            return '<div class="checklist-item ' + stockClass + ' ' + (isChecked ? 'checked' : '') + ' ' + (isReady ? 'readonly' : '') + '" ' +
                (isReady ? '' : 'onclick="toggleChecklistItem(\'' + order.id + '\', \'' + item.sku + '\')"') + '>' +
                '<div class="check-box"><i class="fa-solid fa-check"></i></div>' +
                '<div class="item-info">' +
                    '<div class="item-name">' + item.name + '</div>' +
                    '<div class="item-meta">' +
                        (item.color ? '<span>' + item.color + '</span>' : '') +
                        (item.size ? '<span>' + item.size + '</span>' : '') +
                        (item.sku ? '<span class="item-sku">' + item.sku + '</span>' : '') +
                        (stockText ? '<span class="stock-warning ' + (stockClass === 'low-stock' ? 'low' : '') + '">' + stockText + '</span>' : '') +
                    '</div>' +
                '</div>' +
                '<span class="item-qty">× ' + item.qty + '</span>' +
            '</div>';
        }).join('');
        
        let actionsHtml = '';
        if (isReady) {
            actionsHtml = '<div class="card-actions">' +
                '<button class="btn-print" onclick="window.printOrder(\'' + order.id + '\', event)"><i class="fa-solid fa-print"></i> طباعة</button>' +
                '<button class="btn-undo" onclick="window.undoReady(\'' + order.id + '\', event)"><i class="fa-solid fa-undo"></i> إرجاع للتجهيز</button>' +
                '</div>';
        } else {
            const allChecked = order.items.every(i => checked.includes(i.sku));
            const needsCourier = isOnline && !order.courierId;
            const disabled = needsCourier || !allChecked;
            const title = needsCourier ? 'عيّن سائقاً أولاً' : (!allChecked ? 'أكمل تجهيز القطع أولاً' : '');
            actionsHtml = '<div class="card-actions">' +
                '<button class="btn-print" onclick="window.printOrder(\'' + order.id + '\', event)"><i class="fa-solid fa-print"></i> طباعة</button>' +
                '<button class="btn-mark-ready" ' + (disabled ? 'disabled' : '') + ' ' + (title ? 'title="' + title + '"' : '') + ' onclick="window.markReady(\'' + order.id + '\', event)"><i class="fa-solid fa-check"></i> جاهز للاستلام</button>' +
                '</div>';
        }
        
        return '<div class="' + cardClasses + '">' +
            '<div class="card-top">' +
                '<div class="order-number"><i class="fa-solid fa-hashtag"></i> REQ-' + orderShort + '</div>' +
                '<div class="card-time-info">' +
                    '<span class="request-time">' + requestTime + '</span>' +
                    '<span class="timer ' + timer.cls + '" data-timer-id="' + order.id + '">' + timer.text + '</span>' +
                '</div>' +
            '</div>' +
            '<div class="card-meta">' +
                '<span class="badge badge-source-' + (isOnline ? 'online' : 'pos') + '">' + (isOnline ? '🌐 أونلاين' : '📦 كاشير') + '</span>' +
                '<span class="badge badge-cashier"><i class="fa-solid fa-cash-register"></i> ' + cashierName + '</span>' +
                (shiftRef ? '<span class="badge badge-shift"><i class="fa-solid fa-clock-rotate-left"></i> وردية ' + shiftRef + '</span>' : '') +
                (customerNo ? '<span class="badge badge-customer">زبونة #' + customerNo + '</span>' : '') +
                '<span class="badge badge-items"><i class="fa-solid fa-box"></i> ' + totalItems + ' قطعة</span>' +
                (isLate ? '<span class="badge badge-late"><i class="fa-solid fa-triangle-exclamation"></i> متأخر</span>' : '') +
                (wasReturned ? '<span class="badge badge-returned"><i class="fa-solid fa-rotate-left"></i> مُعاد</span>' : '') +
                (isReady ? '<span class="ready-stamp"><i class="fa-solid fa-check"></i> جاهز</span>' : '') +
            '</div>' +
            customerHtml +
            returnedHtml +
            '<div class="items-checklist">' + (itemsHtml || '<div style="color:var(--muted);font-size:12px;padding:8px;">لا توجد أصناف</div>') + '</div>' +
            '<div style="font-size:11.5px;color:var(--muted);margin-bottom:8px;">قيمة الطلب: <b style="color:#B08D45;font-size:13px;">' + totalAmount.toLocaleString('en-US') + ' ر.ي</b></div>' +
            renderCourierAssignment(order) +
            actionsHtml +
        '</div>';
    }
    
    // ==================== RENDER TRANSIT CARD ====================
    function renderTransitCard(order) {
        const isOnline = order.source === 'online';
        const orderShort = order.id.split('-').pop();
        const elapsed = getElapsedInfo(order.pickedUpAt);
        const totalItems = order.items.reduce((s, i) => s + i.qty, 0);
        const pickedUpTime = new Date(order.pickedUpAt).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
        const totalAmount = getOrderTotal(order);
        const customer = order.customer ? order.customer.name : (order.customerNo ? 'زبونة #' + order.customerNo : '—');
        const cardCls = 'order-card is-transit ' + (elapsed.cls === 'late' ? 'is-transit-late' : '');
        
        return '<div class="' + cardCls + '">' +
            '<div class="card-top">' +
                '<div class="order-number"><i class="fa-solid fa-motorcycle"></i> REQ-' + orderShort + '</div>' +
                '<span class="badge badge-transit"><i class="fa-solid fa-motorcycle"></i> في الطريق</span>' +
            '</div>' +
            '<div class="card-meta">' +
                '<span class="badge badge-source-' + (isOnline ? 'online' : 'pos') + '">' + (isOnline ? '🌐 أونلاين' : '📦 كاشير') + '</span>' +
                '<span class="badge badge-items"><i class="fa-solid fa-box"></i> ' + totalItems + ' قطعة</span>' +
            '</div>' +
            '<div class="transit-info">' +
                '<div><i class="fa-solid fa-motorcycle"></i> الموصل: <strong>' + (order.courierName || '—') + '</strong></div>' +
                '<div><i class="fa-solid fa-user"></i> العميلة: <strong>' + customer + '</strong></div>' +
                '<div><i class="fa-solid fa-clock"></i> استُلم الساعة ' + pickedUpTime + ' — منذ <span class="elapsed ' + elapsed.cls + '" data-elapsed-id="' + order.id + '">' + elapsed.text + '</span></div>' +
                '<div><i class="fa-solid fa-coins"></i> إجمالي: <strong>' + totalAmount.toLocaleString('en-US') + ' ر.ي</strong> (رسوم الموصل: ' + (parseFloat(order.deliveryFee) || 0) + ' ر.ي)</div>' +
            '</div>' +
            '<div class="card-actions">' +
                '<button class="btn-print" onclick="window.printOrder(\'' + order.id + '\', event)"><i class="fa-solid fa-print"></i> طباعة</button>' +
                '<button class="btn-recall" onclick="window.recallOrder(\'' + order.id + '\', event)"><i class="fa-solid fa-rotate-left"></i> استرجاع</button>' +
            '</div>' +
        '</div>';
    }
    
    // ==================== CHECKLIST ====================
    window.toggleChecklistItem = function(orderId, sku) {
        if (!checkedItems[orderId]) checkedItems[orderId] = [];
        const idx = checkedItems[orderId].indexOf(sku);
        if (idx >= 0) checkedItems[orderId].splice(idx, 1);
        else checkedItems[orderId].push(sku);
        localStorage.setItem(STORAGE.checked, JSON.stringify(checkedItems));
        render();
    };
    
    // ==================== ACTIONS ====================
    window.markReady = function(orderId, event) {
        if (event) event.stopPropagation();
        const orders = JSON.parse(localStorage.getItem(STORAGE.pickupOrders) || '[]');
        const idx = orders.findIndex(o => o.id === orderId);
        if (idx < 0) return showToast('الطلب غير موجود', 'error');
        const order = orders[idx];
        if (order.status !== 'pending') return showToast('الطلب ليس قيد التجهيز', 'error');
        if (order.source === 'online' && !order.courierId) return showToast('عيّن سائقاً أولاً لطلب الأونلاين', 'error');
        const checked = checkedItems[orderId] || [];
        const allChecked = order.items.every(i => checked.includes(i.sku));
        if (!allChecked) return showToast('أكمل تجهيز كل القطع أولاً', 'error');
        
        order.status = 'ready';
        order.readyAt = new Date().toISOString();
        order.readyBy = currentUser ? currentUser.username : 'warehouse';
        addOrderEvent(order, 'marked_ready', 'تم تجهيز الطلب وتحديده كجاهز للاستلام');
        localStorage.setItem(STORAGE.pickupOrders, JSON.stringify(orders));
        delete checkedItems[orderId];
        localStorage.setItem(STORAGE.checked, JSON.stringify(checkedItems));
        showToast('تم تجهيز الطلب — جاهز للاستلام من المخزن', 'success');
        loadData();
    };
    
    window.undoReady = function(orderId, event) {
        if (event) event.stopPropagation();
        if (!confirm('إرجاع الطلب لقيد التجهيز؟')) return;
        const orders = JSON.parse(localStorage.getItem(STORAGE.pickupOrders) || '[]');
        const idx = orders.findIndex(o => o.id === orderId);
        if (idx < 0) return showToast('الطلب غير موجود', 'error');
        const order = orders[idx];
        if (order.status !== 'ready') return showToast('لا يمكن إرجاع هذا الطلب', 'error');
        if (order.pickedUpAt) return showToast('الطلب مستلم من الموصل بالفعل', 'error');
        order.status = 'pending';
        order.readyAt = null;
        order.readyBy = null;
        addOrderEvent(order, 'unmarked_ready', 'أُعيد الطلب لقيد التجهيز');
        localStorage.setItem(STORAGE.pickupOrders, JSON.stringify(orders));
        showToast('تم إرجاع الطلب لقيد التجهيز', 'success');
        loadData();
    };
    
    window.recallOrder = function(orderId, event) {
        if (event) event.stopPropagation();
        if (!confirm('استرجاع الطلب من الموصل وإعادته لقائمة الجاهزة؟\n\nسيُلغى تعيين الموصل الحالي وسيظهر الطلب لجميع الموصلين.')) return;
        const orders = JSON.parse(localStorage.getItem(STORAGE.pickupOrders) || '[]');
        const idx = orders.findIndex(o => o.id === orderId);
        if (idx < 0) return showToast('الطلب غير موجود', 'error');
        const order = orders[idx];
        if (order.status !== 'picked_up') return showToast('لا يمكن استرجاع هذا الطلب', 'error');
        
        const courierName = order.courierName || 'الموصل';
        order.status = 'ready';
        order.courierId = null;
        order.courierName = null;
        order.pickedUpAt = null;
        order.lastCourierId = null;
        order.lastCourierName = courierName + ' (استُعيد)';
        addOrderEvent(order, 'recalled_from_courier', 'استُرجع الطلب من الموصل ' + courierName);
        localStorage.setItem(STORAGE.pickupOrders, JSON.stringify(orders));
        showToast('تم استرجاع الطلب من ' + courierName, 'success');
        loadData();
    };
    
    // ==================== PRINT ====================
    window.printOrder = function(orderId, event) {
        if (event) event.stopPropagation();
        const orders = JSON.parse(localStorage.getItem(STORAGE.pickupOrders) || '[]');
        const order = orders.find(o => o.id === orderId);
        if (!order) return;
        const orderShort = order.id.split('-').pop();
        const customer = order.customer || {};
        const printArea = document.getElementById('print-area');
        printArea.innerHTML = '<div class="slip-header">' +
                '<h1>بوتيك مقليس</h1>' +
                '<div style="font-size:12px;color:#666;">قسيمة تجهيز طلب</div>' +
            '</div>' +
            '<div class="slip-info">' +
                '<div><strong>رقم:</strong> REQ-' + orderShort + '</div>' +
                '<div><strong>التاريخ:</strong> ' + new Date().toLocaleDateString('ar-EG') + '</div>' +
                '<div><strong>المصدر:</strong> ' + (order.source === 'online' ? 'أونلاين' : 'كاشير') + '</div>' +
            '</div>' +
            (customer.name || customer.phone ? '<div class="slip-customer">' +
                (customer.name ? '<div><strong>العميلة:</strong> ' + customer.name + '</div>' : '') +
                (customer.phone ? '<div><strong>الهاتف:</strong> ' + customer.phone + '</div>' : '') +
                (customer.address ? '<div><strong>العنوان:</strong> ' + (customer.city || '') + ' ' + customer.address + '</div>' : '') +
            '</div>' : '') +
            '<div class="slip-items">' +
                '<h3 style="margin-bottom:10px;font-size:14px;">القطع المطلوبة:</h3>' +
                order.items.map(i => '<div class="slip-item">' +
                    '<div>☐ ' + i.name + (i.color ? ' — ' + i.color : '') + (i.size ? ' — ' + i.size : '') + (i.sku ? ' (' + i.sku + ')' : '') + '</div>' +
                    '<span class="slip-qty">× ' + i.qty + '</span>' +
                '</div>').join('') +
            '</div>' +
            '<div class="slip-footer">تم التجهيز بواسطة: ' + (currentUser ? currentUser.username : 'warehouse') + '</div>';
        window.print();
    };
    
    // ==================== INIT ====================
    window.addEventListener('DOMContentLoaded', () => {
        const saved = JSON.parse(localStorage.getItem(STORAGE.currentUser) || 'null');
        if (saved) {
            const users = JSON.parse(localStorage.getItem(STORAGE.users) || '[]');
            const found = users.find(u => String(u.id) === String(saved.id) && ['warehouse','admin','stock','inventory'].includes(u.role));
            if (found) {
                currentUser = found;
                enterApp();
            } else {
                localStorage.removeItem(STORAGE.currentUser);
            }
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && document.getElementById('login-screen').style.display !== 'none') {
            if (document.activeElement && ['loginUser','loginPass'].includes(document.activeElement.id)) {
                window.warehouseLogin();
            }
        }
    });

})();
