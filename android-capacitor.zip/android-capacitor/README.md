# تحويل تطبيقات مقليس إلى أندرويد (Capacitor)

كل مجلد هنا مشروع Capacitor مستقل لتطبيق واحد، وينتج ملف APK خاص به:

| المجلد | التطبيق | appId |
|---|---|---|
| cashier | نظام الكاشير | com.maqlis.cashier |
| admin-hazem | لوحة التحكم المالية | com.maqlis.admin |
| maqlis | واجهة المتجر | com.maqlis.shop |
| store-orders | شاشة تجهيز الطلبات (المخزن) | com.maqlis.store |

أكواد الواجهة داخل `www/` (index.html و css/style.css و js/script.js) وهي نسخ مطابقة تماماً للملفات التي قسمناها.
غيّر `appId` في `capacitor.config.json` إلى اسم حزمتك الخاص قبل النشر على Google Play.

## المتطلبات (مرة واحدة على جهازك)
1. Node.js (النسخة LTS)
2. Android Studio (يثبّت معه Android SDK)
3. JDK 21 (يأتي مع Android Studio)

## الخطوات لكل تطبيق
```bash
cd store-orders        # أو أي مجلد آخر
bash setup.sh          # أو نفّذ الأوامر يدوياً أدناه
npx cap open android   # يفتح Android Studio
```
ثم من Android Studio: وصّل هاتفك بكابل (مع تفعيل USB debugging) واضغط Run، أو
Build ‹ Build APK(s) للحصول على الملف.

### بدون سكربت (ويندوز)
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
ثم أضف الصلاحيات يدوياً داخل `android/app/src/main/AndroidManifest.xml` قبل وسم `<application`:
```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
<!-- للكاشير فقط (قارئ الباركود): -->
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera" android:required="false" />
```

## بعد تعديل أي كود
عدّل الملفات داخل `www/` ثم نفّذ `npx cap sync android` وأعد التشغيل من Android Studio.

## ملاحظات مهمة
- **الإنترنت:** المكتبات (Chart.js وJsBarcode وhtml5-qrcode والخطوط وFont Awesome) تُحمَّل من CDN، فالتطبيق يحتاج إنترنت لأول تحميل لها. لتشغيله بدون إنترنت نحمّل هذه المكتبات داخل `www/` لاحقاً.
- **الطباعة:** `window.print()` لا تعمل داخل تطبيق أندرويد كما في المتصفح، فنحتاج إضافة طباعة أو تصدير PDF.
- **البيانات:** ما زالت في `localStorage` على كل جهاز. الخطوة التالية هي ربطها بـ Supabase.
- **الإشعارات:** الإضافتان `local-notifications` و`push-notifications` مثبتتان في المشروع لكن لم تُربطا بالكود بعد. الإشعارات بين الأجهزة تحتاج Supabase + Firebase (FCM)، وهي الخطوة التالية.

## البناء من الهاتف بدون كمبيوتر (GitHub Actions)
1. أنشئ مستودعاً جديداً على github.com (من متصفح الهاتف).
2. ارفع محتويات هذا المجلد كما هي (بما فيها المجلد المخفي `.github`) إلى الفرع `main`.
3. افتح تبويب Actions ‹ Build APK ‹ Run workflow.
4. بعد انتهاء البناء (نحو 5 إلى 10 دقائق) افتح التشغيل ونزّل الـ APK من قسم Artifacts، ثم ثبّته على هاتفك.
