(function(){
'use strict';

/* ============================================================
   CONSTANTS
   ============================================================ */
const TAX_RATE = 0.15;
const CURRENCY = 'ر.ي';
const STORAGE = {
  INVENTORY: 'maqlis_inventory',
  SALES: 'maqlis_sales',
  PICKUP: 'maqlis_pickup_orders',
  STOCK_MOVEMENTS: 'maqlis_stock_movements',
  CART: 'maqlis_store_cart_v2',
  WISHLIST: 'maqlis_store_wishlist_v2',
  THEME: 'maqlis_theme_v1',
  VERSION: 'maqlis_store_version'
};

const STORE_VERSION = '2';

/* ============================================================
   HELPERS
   ============================================================ */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
const fmt = (n) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 }) + ' ' + CURRENCY;

/* ============================================================
   ⭐ STOCK MOVEMENT LOGGER
   ============================================================ */
function logStockMovement(sku, type, qty, qtyBefore, qtyAfter, refId, note) {
  try {
    const movements = JSON.parse(localStorage.getItem(STORAGE.STOCK_MOVEMENTS)) || [];
    const variant = INVENTORY.find(v => v.sku === sku);
    movements.push({
      id: 'MOV-' + Date.now() + '-' + Math.floor(Math.random() * 10000),
      date: new Date().toISOString(),
      sku: sku,
      productName: variant ? variant.name : '—',
      color: variant ? (variant.color || '') : '',
      size: variant ? (variant.size || '') : '',
      type: type,
      qty: qty,
      qtyBefore: qtyBefore,
      qtyAfter: qtyAfter,
      refId: refId || null,
      userId: null,
      userName: 'المتجر الإلكتروني',
      shiftId: null,
      note: note || ''
    });
    localStorage.setItem(STORAGE.STOCK_MOVEMENTS, JSON.stringify(movements));
  } catch (e) {
    console.error('Failed to log stock movement:', e);
  }
}

/* ============================================================
   STATE
   ============================================================ */
let INVENTORY = [];
let PRODUCTS = [];
let CATEGORIES = {};

const state = {
  cart: [],
  wishlist: [],
  filterCat: 'all',
  filterSub: 'all',
  search: ''
};

/* ============================================================
   VERSION MIGRATION
   ============================================================ */
(function migrate(){
  if (localStorage.getItem(STORAGE.VERSION) !== STORE_VERSION) {
    localStorage.removeItem('maqlis_cart_v1');
    localStorage.removeItem('maqlis_wishlist_v1');
    localStorage.removeItem(STORAGE.CART);
    localStorage.removeItem(STORAGE.WISHLIST);
    localStorage.setItem(STORAGE.VERSION, STORE_VERSION);
  }
})();

/* ============================================================
   THEME
   ============================================================ */
(function initTheme(){
  const saved = localStorage.getItem(STORAGE.THEME) || 'light';
  document.documentElement.setAttribute('data-theme', saved);
})();

$('#themeToggle').addEventListener('click', () => {
  const cur = document.documentElement.getAttribute('data-theme');
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem(STORAGE.THEME, next);
});

/* ============================================================
   TOAST
   ============================================================ */
let toastTimer;
function showToast(msg, type='success'){
  const t = $('#toast');
  $('#toastText').textContent = msg;
  t.classList.toggle('is-error', type === 'error');
  t.classList.add('is-visible');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('is-visible'), 2600);
}

/* ============================================================
   MODAL HELPERS
   ============================================================ */
function openModal(id){
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.add('is-open');
  el.setAttribute('aria-hidden','false');
  document.body.style.overflow = 'hidden';
}
function closeModal(id){
  const el = document.getElementById(id);
  if (!el) return;
  el.classList.remove('is-open');
  el.setAttribute('aria-hidden','true');
  document.body.style.overflow = '';
}

/* ============================================================
   LOAD INVENTORY & GROUP PRODUCTS
   ============================================================ */
function loadInventory(){
  INVENTORY = JSON.parse(localStorage.getItem(STORAGE.INVENTORY)) || [];
  groupProducts();
  buildCategories();
  renderAll();
}

function groupProducts(){
  const grouped = {};
  INVENTORY.forEach(v => {
    const key = v.name || 'منتج غير مسمى';
    if (!grouped[key]) {
      grouped[key] = {
        name: key,
        image: v.image,
        mainCategory: v.mainCategory || 'أخرى',
        subCategory: v.subCategory || '',
        variants: []
      };
    }
    grouped[key].variants.push(v);
    if (!grouped[key].image && v.image) grouped[key].image = v.image;
  });

  PRODUCTS = Object.values(grouped).map(g => {
    const totalAvailable = g.variants.reduce((s, v) => s + Math.max(0, (v.qty||0) - (v.reserved||0)), 0);
    const totalQty = g.variants.reduce((s, v) => s + (v.qty||0), 0);
    const prices = [...new Set(g.variants.map(v => v.price))];
    const minPrice = Math.min(...prices);
    const maxPrice = Math.max(...prices);
    return {
      ...g,
      totalAvailable,
      totalQty,
      price: minPrice,
      maxPrice,
      priceVaried: prices.length > 1,
      colors: [...new Set(g.variants.map(v => v.color))],
      sizes: [...new Set(g.variants.map(v => v.size))]
    };
  });
}

function buildCategories(){
  CATEGORIES = {};
  INVENTORY.forEach(v => {
    const mc = v.mainCategory || 'أخرى';
    if (!CATEGORIES[mc]) CATEGORIES[mc] = { count: 0, subs: {}, image: v.image };
    CATEGORIES[mc].count++;
    if (!CATEGORIES[mc].image && v.image) CATEGORIES[mc].image = v.image;
    if (v.subCategory) {
      CATEGORIES[mc].subs[v.subCategory] = (CATEGORIES[mc].subs[v.subCategory] || 0) + 1;
    }
  });
}

/* ============================================================
   RENDER ALL
   ============================================================ */
function renderAll(){
  renderNav();
  renderCategories();
  renderFilterTabs();
  renderSubcategoryNav();
  renderProducts();
  renderFooterCategories();
  updateCartUI();
  updateWishlistUI();
}

/* ============================================================
   NAV & CATEGORIES
   ============================================================ */
function renderNav(){
  const list = $('#mainNavList');
  const cats = Object.keys(CATEGORIES);
  list.innerHTML = `
    <li><a class="nav-link ${state.filterCat==='all'?'is-active':''}" data-cat="all" href="#products">الكل</a></li>
    ${cats.map(c => `<li><a class="nav-link ${state.filterCat===c?'is-active':''}" data-cat="${c}" href="#products">${c}</a></li>`).join('')}
  `;
  list.querySelectorAll('.nav-link').forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      setFilter(a.dataset.cat, 'all');
      $('#products').scrollIntoView({ behavior: 'smooth' });
      closeMobileNav();
    });
  });
}

function renderCategories(){
  const grid = $('#categoriesGrid');
  const cats = Object.entries(CATEGORIES);
  if (cats.length === 0) { grid.innerHTML = ''; return; }
  grid.innerHTML = cats.map(([name, data]) => `
    <div class="cat-card" data-cat="${name}" role="button" tabindex="0">
      <div class="cat-avatar">
        <img src="${data.image || 'https://via.placeholder.com/300'}" alt="${name}" loading="lazy" onerror="this.src='https://via.placeholder.com/300'">
      </div>
      <span class="cat-name">${name}</span>
      <span class="cat-count">${data.count} منتج</span>
    </div>
  `).join('');
  grid.querySelectorAll('.cat-card').forEach(card => {
    const activate = () => {
      setFilter(card.dataset.cat, 'all');
      $('#products').scrollIntoView({ behavior: 'smooth' });
    };
    card.addEventListener('click', activate);
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activate(); } });
  });
}

function renderFooterCategories(){
  const list = $('#footerCategories');
  if (!list) return;
  const cats = Object.keys(CATEGORIES);
  list.innerHTML = cats.map(c => `<li><a data-cat="${c}">${c}</a></li>`).join('') || '<li><a>لا توجد أقسام بعد</a></li>';
  list.querySelectorAll('a[data-cat]').forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      setFilter(a.dataset.cat, 'all');
      $('#products').scrollIntoView({ behavior: 'smooth' });
    });
  });
}

/* ============================================================
   FILTER TABS
   ============================================================ */
function renderFilterTabs(){
  const container = $('#filterTabs');
  const cats = Object.keys(CATEGORIES);
  container.innerHTML = `
    <button class="filter-tab ${state.filterCat==='all'?'is-active':''}" data-filter="all" type="button">الكل</button>
    ${cats.map(c => `<button class="filter-tab ${state.filterCat===c?'is-active':''}" data-filter="${c}" type="button">${c}</button>`).join('')}
  `;
  container.querySelectorAll('.filter-tab').forEach(btn => {
    btn.addEventListener('click', () => setFilter(btn.dataset.filter, 'all'));
  });
}

function renderSubcategoryNav(){
  const nav = $('#subCategoryNav');
  if (state.filterCat === 'all' || !CATEGORIES[state.filterCat]) {
    nav.classList.remove('is-active');
    nav.innerHTML = '';
    return;
  }
  const subs = Object.keys(CATEGORIES[state.filterCat].subs);
  if (subs.length === 0) {
    nav.classList.remove('is-active');
    nav.innerHTML = '';
    return;
  }
  nav.classList.add('is-active');
  nav.innerHTML = `
    <button class="subcategory-btn ${state.filterSub==='all'?'is-active':''}" data-sub="all">الكل</button>
    ${subs.map(s => `<button class="subcategory-btn ${state.filterSub===s?'is-active':''}" data-sub="${s}">${s}</button>`).join('')}
  `;
  nav.querySelectorAll('.subcategory-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.filterSub = btn.dataset.sub;
      renderSubcategoryNav();
      renderProducts();
    });
  });
}

function setFilter(cat, sub){
  state.filterCat = cat;
  state.filterSub = sub;
  renderNav();
  renderFilterTabs();
  renderSubcategoryNav();
  renderProducts();
}

/* ============================================================
   PRODUCTS RENDER
   ============================================================ */
function renderProducts(){
  const grid = $('#productsGrid');
  const titleEl = $('#productsSectionTitle');
  const subEl = $('#productsSectionSub');

  let filtered = PRODUCTS.filter(p => {
    if (state.filterCat !== 'all' && p.mainCategory !== state.filterCat) return false;
    if (state.filterSub !== 'all' && p.subCategory !== state.filterSub) return false;
    if (state.search) {
      const q = state.search.toLowerCase();
      const hay = `${p.name} ${p.mainCategory} ${p.subCategory}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });

  if (state.search) {
    titleEl.textContent = 'نتائج البحث';
    subEl.textContent = `عن: "${state.search}"`;
  } else if (state.filterSub !== 'all') {
    titleEl.textContent = `${state.filterSub} — ${state.filterCat}`;
    subEl.textContent = 'تشكيلة مختارة بعناية';
  } else if (state.filterCat !== 'all') {
    titleEl.textContent = `تسوقي ${state.filterCat}`;
    subEl.textContent = 'تشكيلة مميزة مختارة لكِ';
  } else {
    titleEl.textContent = 'كل المنتجات';
    subEl.textContent = 'تصفحي تشكيلتنا الكاملة';
  }

  if (filtered.length === 0) {
    const isSearch = state.search.length > 0;
    const isEmptyInv = INVENTORY.length === 0;
    grid.innerHTML = `
      <div class="products-empty">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/></svg>
        <h3>${isEmptyInv ? 'المتجر قيد التجهيز' : (isSearch ? 'لا توجد نتائج مطابقة' : 'لا توجد منتجات في هذا القسم')}</h3>
        <p>${isEmptyInv ? 'لم تتم إضافة منتجات بعد. يرجى العودة قريباً.' : (isSearch ? `لم نجد منتجات تطابق "${state.search}". جربي كلمة أخرى.` : 'تفضلي بتصفح الأقسام الأخرى أو عرض كل المنتجات.')}</p>
        ${(isSearch || state.filterCat !== 'all') ? '<button class="btn btn--outline" id="clearFiltersBtn" type="button">عرض كل المنتجات</button>' : ''}
      </div>
    `;
    const clr = $('#clearFiltersBtn');
    if (clr) clr.addEventListener('click', () => { state.search=''; state.filterCat='all'; state.filterSub='all'; $('#siteSearch').value=''; setFilter('all','all'); });
    return;
  }

  grid.innerHTML = filtered.map(productCardHTML).join('');
  bindProductCardEvents();
}

function productCardHTML(p){
  const inWish = state.wishlist.includes(p.name);
  const isOut = p.totalAvailable === 0;
  const showStock = p.totalAvailable > 0 && p.totalAvailable <= 5;
  return `
    <article class="product-card ${isOut ? 'is-out' : ''}">
      <div class="product-media" data-open="${p.name}" role="button" tabindex="0" aria-label="${p.name}">
        ${isOut ? '<span class="badge badge--out">نفد المخزون</span>' : ''}
        <div class="product-tools">
          <button class="tool-btn ${inWish ? 'is-active' : ''}" type="button" data-wish="${p.name}" aria-label="المفضلة">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20.6 8.6a4.9 4.9 0 0 0-8.6-3.1A4.9 4.9 0 0 0 3.4 8.6c0 4.3 5.1 7.8 8.6 10.2 3.5-2.4 8.6-5.9 8.6-10.2Z"/></svg>
          </button>
        </div>
        ${showStock ? `<span class="stock-pill">آخر ${p.totalAvailable} قطع</span>` : (p.totalAvailable > 5 ? `<span class="stock-pill">متوفر</span>` : '')}
        <img src="${p.image || 'https://via.placeholder.com/400'}" alt="${p.name}" loading="lazy" onerror="this.src='https://via.placeholder.com/400'">
      </div>
      <div class="product-body" data-open="${p.name}">
        <span class="product-cat">${p.mainCategory}${p.subCategory ? ' • ' + p.subCategory : ''}</span>
        <h3 class="product-title">${p.name}</h3>
        <div class="price-row">
          <span class="price-now">${p.priceVaried ? 'من ' : ''}${fmt(p.price)}</span>
          ${p.priceVaried ? `<span style="font-size:12px;color:var(--muted);">حتى ${fmt(p.maxPrice)}</span>` : ''}
        </div>
      </div>
    </article>
  `;
}

function bindProductCardEvents(){
  $$('#productsGrid [data-open]').forEach(el => {
    el.addEventListener('click', e => {
      if (e.target.closest('[data-wish]')) return;
      openVariantModal(el.dataset.open);
    });
  });
  $$('#productsGrid [data-wish]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      toggleWish(btn.dataset.wish);
    });
  });
}

/* ============================================================
   VARIANT MODAL
   ============================================================ */
let vSelectedColor = null;
let vSelectedSize = null;
let vSelectedQty = 1;
let vProduct = null;

function openVariantModal(productName){
  const p = PRODUCTS.find(x => x.name === productName);
  if (!p) return;
  if (p.totalAvailable === 0) { showToast('هذا المنتج نفد من المخزون', 'error'); return; }

  vProduct = p;
  const availVariants = p.variants.filter(v => ((v.qty||0) - (v.reserved||0)) > 0);
  if (availVariants.length === 0) { showToast('لا توجد نسخ متاحة', 'error'); return; }

  const colors = [...new Set(availVariants.map(v => v.color))];
  vSelectedColor = colors[0];
  vSelectedSize = null;
  vSelectedQty = 1;

  $('#variantContent').innerHTML = `
    <div class="variant-media">
      <img src="${p.image || 'https://via.placeholder.com/400'}" alt="${p.name}" onerror="this.src='https://via.placeholder.com/400'">
    </div>
    <div class="variant-info">
      <span class="product-cat">${p.mainCategory}${p.subCategory ? ' • ' + p.subCategory : ''}</span>
      <h2>${p.name}</h2>
      <div class="variant-price" id="vPrice">${fmt(p.price)}</div>

      <div class="variant-group">
        <label>اللون:</label>
        <div class="variant-options" id="vColors">
          ${colors.map((c, i) => {
            const sample = availVariants.find(v => v.color === c);
            return `<button type="button" class="variant-btn color-btn ${i===0?'is-active':''}" data-color="${c}">
              <span class="color-dot" style="background:${sample.colorHex || '#ccc'}"></span>${c}
            </button>`;
          }).join('')}
        </div>
      </div>

      <div class="variant-group">
        <label>المقاس:</label>
        <div class="variant-options" id="vSizes"></div>
      </div>

      <div class="variant-group">
        <label>الكمية:</label>
        <div class="qty-picker">
          <button type="button" data-qty="-1">−</button>
          <input type="number" id="vQty" value="1" min="1" readonly>
          <button type="button" data-qty="1">+</button>
        </div>
      </div>

      <button class="btn btn--gold" id="vAddBtn" type="button" style="width:100%;margin-top:10px;padding:14px;">
        أضيفي إلى السلة
      </button>
    </div>
  `;

  function renderSizes(){
    const sizesForColor = availVariants.filter(v => v.color === vSelectedColor);
    const el = $('#vSizes');
    el.innerHTML = sizesForColor.map((v, i) => {
      const avail = Math.max(0, (v.qty||0) - (v.reserved||0));
      return `<button type="button" class="variant-btn size-btn ${i===0?'is-active':''}" data-size="${v.size}">
        ${v.size} <span style="font-size:10.5px;opacity:.75;">(${avail})</span>
      </button>`;
    }).join('');
    vSelectedSize = sizesForColor[0]?.size || null;
    vSelectedQty = 1;
    const qEl = $('#vQty'); if (qEl) qEl.value = 1;
    updatePrice();
    el.querySelectorAll('.size-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        el.querySelectorAll('.size-btn').forEach(b => b.classList.remove('is-active'));
        btn.classList.add('is-active');
        vSelectedSize = btn.dataset.size;
        vSelectedQty = 1;
        const qi = $('#vQty'); if (qi) qi.value = 1;
        updatePrice();
      });
    });
  }

  function updatePrice(){
    const v = availVariants.find(x => x.color === vSelectedColor && x.size === vSelectedSize);
    if (v) $('#vPrice').textContent = fmt(v.price);
  }

  $('#variantContent').querySelectorAll('#vColors .color-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      $('#variantContent').querySelectorAll('#vColors .color-btn').forEach(b => b.classList.remove('is-active'));
      btn.classList.add('is-active');
      vSelectedColor = btn.dataset.color;
      renderSizes();
    });
  });

  $('#variantContent').querySelectorAll('.qty-picker button').forEach(btn => {
    btn.addEventListener('click', () => {
      const delta = parseInt(btn.dataset.qty);
      const variant = availVariants.find(x => x.color === vSelectedColor && x.size === vSelectedSize);
      const max = variant ? Math.max(0, (variant.qty||0) - (variant.reserved||0)) : 1;
      vSelectedQty = Math.max(1, Math.min(max, vSelectedQty + delta));
      const qi = $('#vQty'); if (qi) qi.value = vSelectedQty;
    });
  });

  $('#vAddBtn').addEventListener('click', () => {
    const variant = availVariants.find(x => x.color === vSelectedColor && x.size === vSelectedSize);
    if (!variant) { showToast('اختاري المقاس', 'error'); return; }
    addToCart(variant.sku, vSelectedQty);
    closeModal('variantModal');
  });

  renderSizes();
  openModal('variantModal');
}

/* ============================================================
   CART
   ============================================================ */
function loadCartFromStorage(){
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE.CART)) || [];
    const validSkus = new Set(INVENTORY.map(i => i.sku));
    return saved.filter(it => validSkus.has(it.sku));
  } catch { return []; }
}
function saveCartToStorage(){
  localStorage.setItem(STORAGE.CART, JSON.stringify(state.cart));
}

function addToCart(sku, qty = 1){
  const inv = INVENTORY.find(v => v.sku === sku);
  if (!inv) { showToast('المنتج غير موجود', 'error'); return; }
  const maxAvail = Math.max(0, (inv.qty||0) - (inv.reserved||0));
  const existing = state.cart.find(c => c.sku === sku);
  const cur = existing ? existing.qty : 0;
  if (cur + qty > maxAvail) { showToast(`الكمية المتاحة ${maxAvail} فقط`, 'error'); return; }

  if (existing) {
    existing.qty += qty;
  } else {
    state.cart.push({
      sku: inv.sku,
      name: inv.name,
      price: inv.price,
      image: inv.image,
      color: inv.color,
      size: inv.size,
      qty: qty
    });
  }
  saveCartToStorage();
  updateCartUI();
  showToast('أُضيفت القطعة إلى السلة ✓');
}

function removeFromCart(sku){
  state.cart = state.cart.filter(c => c.sku !== sku);
  saveCartToStorage();
  updateCartUI();
}
function changeCartQty(sku, delta){
  const item = state.cart.find(c => c.sku === sku);
  if (!item) return;
  if (delta > 0) {
    const inv = INVENTORY.find(v => v.sku === sku);
    const maxAvail = inv ? Math.max(0, (inv.qty||0) - (inv.reserved||0)) : 0;
    if (item.qty + delta > maxAvail) { showToast(`الكمية المتاحة ${maxAvail} فقط`, 'error'); return; }
  }
  item.qty += delta;
  if (item.qty <= 0) removeFromCart(sku);
  else { saveCartToStorage(); updateCartUI(); }
}

function updateCartUI(){
  const cartBody = $('#cartBody');
  const cartSummary = $('#cartSummary');
  const badge = $('#cartCount');
  const title = $('#cartTitleCount');
  const totalQty = state.cart.reduce((s, i) => s + i.qty, 0);
  badge.textContent = totalQty;
  badge.setAttribute('data-count', totalQty);
  title.textContent = `(${totalQty})`;

  if (state.cart.length === 0) {
    cartBody.innerHTML = `
      <div class="cart-empty">
        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M5.8 7h12.4l-1.2 11.2a2 2 0 0 1-2 1.8H9a2 2 0 0 1-2-1.8L5.8 7Z"/><path d="M9 7a3 3 0 0 1 6 0"/></svg>
        <h3>سلتكِ فارغة</h3>
        <p>ابدئي التسوق واكتشفي تشكيلتنا</p>
      </div>
    `;
    cartSummary.innerHTML = '';
    return;
  }

  cartBody.innerHTML = state.cart.map(item => `
    <div class="cart-item" data-sku="${item.sku}">
      <button class="cart-item__remove" type="button" data-remove aria-label="حذف">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M18 6 6 18M6 6l12 12"/></svg>
      </button>
      <img class="cart-item__img" src="${item.image || 'https://via.placeholder.com/74'}" alt="${item.name}" onerror="this.src='https://via.placeholder.com/74'">
      <div class="cart-item__info">
        <h4 class="cart-item__name">${item.name}</h4>
        <div class="cart-item__meta">${item.color || ''}${item.size ? ' • ' + item.size : ''}</div>
        <div class="cart-item__bottom">
          <div class="qty-control">
            <button type="button" data-qty="-1">−</button>
            <span>${item.qty}</span>
            <button type="button" data-qty="1">+</button>
          </div>
          <span class="cart-item__price">${fmt(item.price * item.qty)}</span>
        </div>
      </div>
    </div>
  `).join('');

  const subtotal = state.cart.reduce((s, i) => s + i.price * i.qty, 0);
  const tax = subtotal * TAX_RATE;
  const total = subtotal + tax;
  cartSummary.innerHTML = `
    <div class="cart-row"><span>المجموع الفرعي</span><span>${fmt(subtotal)}</span></div>
    <div class="cart-row"><span>الضريبة (15%)</span><span>${fmt(tax)}</span></div>
    <div class="cart-row total"><span>الإجمالي</span><span>${fmt(total)}</span></div>
  `;

  cartBody.querySelectorAll('.cart-item').forEach(row => {
    const sku = row.dataset.sku;
    row.querySelectorAll('[data-qty]').forEach(btn => {
      btn.addEventListener('click', () => changeCartQty(sku, parseInt(btn.dataset.qty)));
    });
    row.querySelector('[data-remove]').addEventListener('click', () => removeFromCart(sku));
  });
}

/* ============================================================
   WISHLIST
   ============================================================ */
function loadWishlistFromStorage(){
  try { return JSON.parse(localStorage.getItem(STORAGE.WISHLIST)) || []; }
  catch { return []; }
}
function saveWishlist(){ localStorage.setItem(STORAGE.WISHLIST, JSON.stringify(state.wishlist)); }

function toggleWish(name){
  const i = state.wishlist.indexOf(name);
  if (i >= 0) { state.wishlist.splice(i, 1); showToast('أُزيلت من المفضلة'); }
  else { state.wishlist.push(name); showToast('أُضيفت للمفضلة ♥'); }
  saveWishlist();
  updateWishlistUI();
  renderProducts();
}

function updateWishlistUI(){
  const badge = $('#wishCount');
  const title = $('#wishTitleCount');
  badge.textContent = state.wishlist.length;
  badge.setAttribute('data-count', state.wishlist.length);
  title.textContent = `(${state.wishlist.length})`;

  const body = $('#wishlistBody');
  if (state.wishlist.length === 0) {
    body.innerHTML = `
      <div class="cart-empty">
        <svg width="80" height="80" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M20.6 8.6a4.9 4.9 0 0 0-8.6-3.1A4.9 4.9 0 0 0 3.4 8.6c0 4.3 5.1 7.8 8.6 10.2 3.5-2.4 8.6-5.9 8.6-10.2Z"/></svg>
        <h3>لا توجد منتجات مفضلة</h3>
        <p>اضغطي على القلب لحفظ القطع التي تعجبك</p>
      </div>
    `;
    return;
  }

  body.innerHTML = state.wishlist.map(name => {
    const p = PRODUCTS.find(x => x.name === name);
    if (!p) return '';
    return `
      <div class="cart-item" data-wish-name="${name}">
        <button class="cart-item__remove" type="button" data-wish-remove>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
        <img class="cart-item__img" src="${p.image || 'https://via.placeholder.com/74'}" alt="${p.name}" style="cursor:pointer" data-wish-open>
        <div class="cart-item__info">
          <h4 class="cart-item__name">${p.name}</h4>
          <div class="cart-item__meta">${p.mainCategory}</div>
          <div class="cart-item__bottom">
            <span class="cart-item__price">${fmt(p.price)}</span>
            <button class="btn btn--gold" type="button" data-wish-add style="padding:6px 14px;font-size:12px;border-radius:999px;">أضيفي</button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  body.querySelectorAll('.cart-item').forEach(row => {
    const name = row.dataset.wishName;
    const removeBtn = row.querySelector('[data-wish-remove]');
    if (removeBtn) removeBtn.addEventListener('click', () => toggleWish(name));
    const addBtn = row.querySelector('[data-wish-add]');
    if (addBtn) addBtn.addEventListener('click', () => { closeModal('wishlistDrawer'); openVariantModal(name); });
    const img = row.querySelector('[data-wish-open]');
    if (img) img.addEventListener('click', () => { closeModal('wishlistDrawer'); openVariantModal(name); });
  });
}

/* ============================================================
   CHECKOUT
   ============================================================ */
function openCheckoutModal(){
  if (state.cart.length === 0) { showToast('السلة فارغة', 'error'); return; }

  for (const item of state.cart) {
    const inv = INVENTORY.find(v => v.sku === item.sku);
    const avail = inv ? Math.max(0, (inv.qty||0) - (inv.reserved||0)) : 0;
    if (avail < item.qty) {
      showToast(`الكمية المتاحة من "${item.name}" هي ${avail} فقط`, 'error');
      return;
    }
  }

  const summary = $('#checkoutSummary');
  summary.innerHTML = state.cart.map(item => `
    <div class="summary-item">
      <div>
        <div class="sname">${item.name}</div>
        <div class="smeta">${item.color || ''}${item.size ? ' • ' + item.size : ''} × ${item.qty}</div>
      </div>
      <div style="font-weight:700;">${fmt(item.price * item.qty)}</div>
    </div>
  `).join('');

  const subtotal = state.cart.reduce((s, i) => s + i.price * i.qty, 0);
  const tax = subtotal * TAX_RATE;
  const total = subtotal + tax;
  summary.innerHTML += `
    <div class="summary-totals">
      <div class="row"><span>المجموع الفرعي</span><span>${fmt(subtotal)}</span></div>
      <div class="row"><span>الضريبة (15%)</span><span>${fmt(tax)}</span></div>
      <div class="row total"><span>الإجمالي</span><span>${fmt(total)}</span></div>
    </div>
  `;

  closeModal('cartDrawer');
  openModal('checkoutModal');
}

function submitOrder(e){
  e.preventDefault();
  const form = e.target;
  const customer = {
    name: form.querySelector('[name="customerName"]').value.trim(),
    phone: form.querySelector('[name="customerPhone"]').value.trim(),
    city: form.querySelector('[name="customerCity"]').value.trim(),
    address: form.querySelector('[name="customerAddress"]').value.trim()
  };

  if (!customer.name || !customer.phone) {
    showToast('يرجى إدخال الاسم والجوال', 'error');
    return;
  }

  const inventory = JSON.parse(localStorage.getItem(STORAGE.INVENTORY)) || [];
  for (const item of state.cart) {
    const inv = inventory.find(v => v.sku === item.sku);
    const avail = inv ? Math.max(0, (inv.qty||0) - (inv.reserved||0)) : 0;
    if (avail < item.qty) {
      showToast(`الكمية المتاحة من "${item.name}" هي ${avail} فقط`, 'error');
      return;
    }
  }

  /* ⭐ التعديل: خصم المخزون + جمع الحركات */
  const pendingMovements = [];
  state.cart.forEach(item => {
    const inv = inventory.find(v => v.sku === item.sku);
    if (inv) {
      const before = inv.qty || 0;
      const after = Math.max(0, before - item.qty);
      pendingMovements.push({ sku: item.sku, qty: -item.qty, before, after });
      inv.qty = after;
    }
  });
  localStorage.setItem(STORAGE.INVENTORY, JSON.stringify(inventory));

  const items = state.cart.map(item => {
    const inv = INVENTORY.find(v => v.sku === item.sku);
    return {
      name: item.name,
      sku: item.sku,
      color: item.color || '',
      size: item.size || '',
      price: item.price,
      costPrice: inv ? (inv.costPrice || 0) : 0,
      qty: item.qty,
      discount: 0
    };
  });

  const subtotal = state.cart.reduce((s, i) => s + i.price * i.qty, 0);
  const tax = subtotal * TAX_RATE;
  const total = subtotal + tax;
  const saleId = 'ONL-' + Date.now();

  /* ⭐ التعديل: تسجيل حركات المخزون */
  pendingMovements.forEach(m => {
    logStockMovement(m.sku, 'sale', m.qty, m.before, m.after, saleId, 'طلب أونلاين');
  });

  const sales = JSON.parse(localStorage.getItem(STORAGE.SALES)) || [];
  sales.push({
    id: saleId,
    date: new Date().toISOString(),
    cashier: 'المتجر الإلكتروني',
    subCashier: null,
    mainCashier: null,
    customerNo: null,
    customer: customer,
    items: items,
    subtotal: subtotal,
    tax: tax,
    total: total,
    paymentMethod: 'الدفع الإلكتروني / عند الاستلام',
    source: 'online'
  });
  localStorage.setItem(STORAGE.SALES, JSON.stringify(sales));

  const pickup = JSON.parse(localStorage.getItem(STORAGE.PICKUP)) || [];
  pickup.push({
    id: saleId,
    date: new Date().toISOString(),
    cashier: 'المتجر الإلكتروني',
    subCashier: null,
    mainCashier: null,
    customerNo: null,
    customer: customer,
    items: items,
    subtotal: subtotal,
    tax: tax,
    productTotal: total,
    total: total,
    deliveryFee: 0,
    invoiceTotal: total,
    status: 'pending',
    source: 'online',
    stockDeducted: true,
    stockDeductedAt: new Date().toISOString(),
    history: [{ action: 'created', details: 'إنشاء طلب من المتجر الإلكتروني وخصم المخزون مرة واحدة', at: new Date().toISOString(), by: 'store' }]
  });
  localStorage.setItem(STORAGE.PICKUP, JSON.stringify(pickup));

  const orderInfo = { id: saleId, customer, items: [...items], subtotal, tax, total };

  state.cart = [];
  saveCartToStorage();
  updateCartUI();

  loadInventory();

  closeModal('checkoutModal');
  showSuccessModal(orderInfo);
}

function showSuccessModal(order){
  $('#successOrderId').textContent = order.id;
  const itemsCount = order.items.reduce((s, i) => s + i.qty, 0);
  $('#successDetails').innerHTML = `
    <div class="row"><span>العميلة</span><span>${order.customer.name}</span></div>
    <div class="row"><span>الجوال</span><span dir="ltr">${order.customer.phone}</span></div>
    <div class="row"><span>عدد القطع</span><span>${itemsCount}</span></div>
    <div class="row"><span>الإجمالي</span><span style="color:var(--gold-2);">${fmt(order.total)}</span></div>
  `;
  openModal('successModal');
}

/* ============================================================
   EVENT BINDINGS
   ============================================================ */
$('#cartToggle').addEventListener('click', () => openModal('cartDrawer'));
$$('[data-close-cart]').forEach(el => el.addEventListener('click', () => closeModal('cartDrawer')));
$('#wishlistToggle').addEventListener('click', () => openModal('wishlistDrawer'));
$$('[data-close-wishlist]').forEach(el => el.addEventListener('click', () => closeModal('wishlistDrawer')));
$$('[data-close-variant]').forEach(el => el.addEventListener('click', () => closeModal('variantModal')));
$$('[data-close-checkout]').forEach(el => el.addEventListener('click', () => closeModal('checkoutModal')));
$('#successCloseBtn').addEventListener('click', () => closeModal('successModal'));

$('#cartCheckout').addEventListener('click', openCheckoutModal);
$('#checkoutForm').addEventListener('submit', submitOrder);

let searchTimer;
$('#siteSearch').addEventListener('input', (e) => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    state.search = e.target.value.trim().toLowerCase();
    renderProducts();
  }, 220);
});
$('#siteSearch').addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { e.target.value = ''; state.search = ''; renderProducts(); }
});

function closeMobileNav(){
  $('#mainNav').classList.remove('is-open');
  $('#navToggle').setAttribute('aria-expanded', 'false');
}
$('#navToggle').addEventListener('click', () => {
  const open = $('#mainNav').classList.toggle('is-open');
  $('#navToggle').setAttribute('aria-expanded', open);
});

$('#newsletterForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const email = $('#newsEmail').value.trim();
  const msg = $('#newsletterMsg');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    msg.textContent = 'يرجى إدخال بريد إلكتروني صحيح';
    msg.style.color = '#E06A85';
    return;
  }
  msg.textContent = '✓ تم اشتراكك بنجاح';
  msg.style.color = 'var(--gold-light)';
  $('#newsEmail').value = '';
});

$('#backToTop').addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
window.addEventListener('scroll', () => {
  $('#backToTop').classList.toggle('is-visible', window.scrollY > 600);
  $('#siteHeader').classList.toggle('is-scrolled', window.scrollY > 10);
}, { passive: true });

document.addEventListener('keydown', (e) => {
  if (e.key !== 'Escape') return;
  ['cartDrawer','wishlistDrawer','variantModal','checkoutModal','successModal'].forEach(id => {
    if (document.getElementById(id)?.classList.contains('is-open')) closeModal(id);
  });
});

window.addEventListener('storage', (e) => {
  if (e.key === STORAGE.INVENTORY) loadInventory();
});

/* ============================================================
   INIT
   ============================================================ */
loadInventory();
state.cart = loadCartFromStorage();
state.wishlist = loadWishlistFromStorage();
updateCartUI();
updateWishlistUI();

})();
