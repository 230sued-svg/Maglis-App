(function(){
    'use strict';

    const STORAGE = {
        couriers:      'maqlis_couriers',
        users:         'maqlis_users',
        pickupOrders:  'maqlis_pickup_orders',
        deliveries:    'maqlis_courier_deliveries',
        settlements:   'maqlis_courier_settlements',
        currentUser:   'maqlis_courierCurrent'
    };

    let currentCourier = null;

    // تتبع الطلبات لمعرفة الجديد والمحذوف
    let knownReadyIds = [];
    let knownPickedUpIds = [];
    let initialSyncDone = false;

    // توقيع البيانات لمنع إعادة الرسم المتكرر
    let lastDataSignature = '';

    // قفل أزرار لمنع النقر المزدوج
    let actionLock = false;
    function lockAction() {
        if (actionLock) return false;
        actionLock = true;
        setTimeout(() => { actionLock = false; }, 1500);
        return true;
    }

    // Audio context للتنبيه الصوتي
    let audioCtx = null;
    let audioActivated = false;

    /* ============ HELPERS ============ */
    function toast(msg, type) {
        const c = document.getElementById('toastContainer');
        const el = document.createElement('div');
        el.className = 'toast ' + (type || '');
        el.innerHTML = `<i class="fa-solid ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-circle-exclamation' : 'fa-info-circle'}"></i> <span>${msg}</span>`;
        c.appendChild(el);
        setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(-20px)'; setTimeout(() => el.remove(), 300); }, 3500);
    }

    function fmt(n) { return (parseFloat(n) || 0).toLocaleString('en-US'); }

    function getCouriers()     { return JSON.parse(localStorage.getItem(STORAGE.couriers) || '[]'); }
    function getPickupOrders() { return JSON.parse(localStorage.getItem(STORAGE.pickupOrders) || '[]'); }
    function getDeliveries()   { return JSON.parse(localStorage.getItem(STORAGE.deliveries) || '[]'); }
    function getSettlements()  { return JSON.parse(localStorage.getItem(STORAGE.settlements) || '[]'); }
    function addOrderEvent(order, action, details) {
        order.history = Array.isArray(order.history) ? order.history : [];
        order.history.push({ action, details: details || '', at: new Date().toISOString(), by: 'courier:' + (currentCourier ? currentCourier.id : '') });
    }
    function productAmount(order) {
        if (order.productTotal != null) return Math.max(0, Number(order.productTotal) || 0);
        return Math.max(0, Number(order.total) || 0);
    }
    function deliveryFee(order) { return Math.max(0, Number(order.deliveryFee) || 0); }

    function elapsedSince(isoStr) {
        if (!isoStr) return '';
        const ms = Date.now() - new Date(isoStr).getTime();
        if (isNaN(ms) || ms < 0) return '';
        const mins = Math.floor(ms / 60000);
        if (mins < 1) return 'الآن';
        if (mins < 60) return mins + ' دقيقة';
        const hours = Math.floor(mins / 60);
        const remMins = mins % 60;
        if (hours < 24) return hours + ' ساعة' + (remMins > 0 ? ' و' + remMins + ' د' : '');
        const days = Math.floor(hours / 24);
        return days + ' يوم';
    }

    function elapsedMinutes(isoStr) {
        if (!isoStr) return 0;
        const ms = Date.now() - new Date(isoStr).getTime();
        if (isNaN(ms) || ms < 0) return 0;
        return Math.floor(ms / 60000);
    }

    function playAlert() {
        if (!audioActivated) return;
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            if (!audioCtx) audioCtx = new AudioContext();
            if (audioCtx.state === 'suspended') audioCtx.resume();
            const notes = [880, 1046.5, 1318.51];
            notes.forEach((freq, i) => {
                const osc = audioCtx.createOscillator();
                const gain = audioCtx.createGain();
                osc.connect(gain);
                gain.connect(audioCtx.destination);
                osc.type = 'sine';
                osc.frequency.setValueAtTime(freq, audioCtx.currentTime + (i * 0.15));
                gain.gain.setValueAtTime(0.25, audioCtx.currentTime + (i * 0.15));
                gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + (i * 0.15) + 0.3);
                osc.start(audioCtx.currentTime + (i * 0.15));
                osc.stop(audioCtx.currentTime + (i * 0.15) + 0.3);
            });
        } catch (e) {}
    }

    document.addEventListener('click', function activateAudio() {
        if (!audioActivated) {
            audioActivated = true;
            try {
                const AudioContext = window.AudioContext || window.webkitAudioContext;
                if (AudioContext && !audioCtx) audioCtx = new AudioContext();
                if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
            } catch (e) {}
        }
    }, { once: true });

    /* ============ ORDERS FOR THIS COURIER ============ */
    function getReadyOrders() {
        return getPickupOrders().filter(o => {
            if (!['ready','picked_up'].includes(o.status) || o.deliveredAt) return false;
            if (o.source === 'online') return !!o.courierId && String(o.courierId) === String(currentCourier.id);
            return !o.courierId || String(o.courierId) === String(currentCourier.id);
        }).sort((a, b) => new Date(a.date) - new Date(b.date));
    }
    function getReadyOnly()  { return getReadyOrders().filter(o => o.status === 'ready'); }
    function getPickedUp()   { return getReadyOrders().filter(o => o.status === 'picked_up'); }

    /* ============ DELIVERIES FOR THIS COURIER ============ */
    function getMyDeliveries() {
        return getDeliveries()
            .filter(d => String(d.courierId) === String(currentCourier.id))
            .sort((a, b) => new Date(b.deliveredAt) - new Date(a.deliveredAt));
    }
    function getUnsettledDeliveries() { return getMyDeliveries().filter(d => !d.settled); }

    /* ============ DATA SIGNATURE ============ */
    function computeSignature() {
        const ready = getReadyOnly().map(o => o.id + '|' + o.status + '|' + (o.pickedUpAt || '') + '|' + (o.deliveryFee || 0));
        const picked = getPickedUp().map(o => o.id + '|' + (o.pickedUpAt || ''));
        const deliveries = getMyDeliveries().slice(0, 80).map(d => d.id + '|' + d.settled + '|' + (d.settledAt || ''));
        const settlements = getSettlements().filter(s => String(s.courierId) === String(currentCourier?.id)).map(s => s.id);
        return JSON.stringify({ ready, picked, deliveries, settlements });
    }

    /* ============ LOGIN ============ */
    window.login = function() {
        const u = document.getElementById('loginUser').value.trim();
        const p = document.getElementById('loginPass').value.trim();
        const errEl = document.getElementById('loginError');
        errEl.style.display = 'none';

        if (!u || !p) { errEl.textContent = 'أدخل اسم المستخدم وكلمة المرور'; errEl.style.display = 'block'; return; }

        const users = JSON.parse(localStorage.getItem(STORAGE.users) || '[]');
        const user = users.find(x => x.username === u && x.password === p && x.role === 'courier');

        if (!user) { errEl.textContent = 'بيانات الدخول غير صحيحة'; errEl.style.display = 'block'; return; }

        const courier = getCouriers().find(c => String(c.userId) === String(user.id));
        if (!courier) { errEl.textContent = 'لم يتم العثور على حساب موصل مرتبط'; errEl.style.display = 'block'; return; }
        if (courier.active === false) { errEl.textContent = 'حساب الموصل معطّل. تواصل مع الإدارة'; errEl.style.display = 'block'; return; }

        currentCourier = courier;
        localStorage.setItem(STORAGE.currentUser, JSON.stringify(user));
        enterApp();
    };

    function enterApp() {
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('app-container').style.display = 'flex';
        document.getElementById('courierName').textContent = currentCourier.name;
        document.getElementById('courierAreas').textContent =
            (currentCourier.areas && currentCourier.areas.length) ? currentCourier.areas.join(' • ') : 'بدون مناطق';
        refreshAll();
        initialSyncDone = true;
        lastDataSignature = computeSignature();

        window.addEventListener('storage', (e) => {
            if (e.key === STORAGE.pickupOrders || e.key === STORAGE.deliveries ||
                e.key === STORAGE.settlements || e.key === STORAGE.couriers) {
                refreshAll();
            }
        });

        setInterval(() => {
            if (!document.hidden) refreshAll();
        }, 5000);
    }

    window.logout = function() {
        if (!confirm('تسجيل الخروج؟')) return;
        localStorage.removeItem(STORAGE.currentUser);
        location.reload();
    };

    /* ============ NAV ============ */
    window.switchPage = function(page, btn) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
        const el = document.getElementById('page-' + page);
        if (el) el.classList.add('active');
        if (btn) btn.classList.add('active');
        if (page === 'home')    renderHome();
        if (page === 'orders')  renderOrders();
        if (page === 'history') renderHistory();
        if (page === 'settle')  renderSettle();
    };

    window.manualRefresh = function(btn) {
        if (btn) {
            btn.classList.add('spinning');
            setTimeout(() => btn.classList.remove('spinning'), 600);
        }
        lastDataSignature = '';
        refreshAll();
        toast('تم التحديث', 'success');
    };

    /* ============ CHANGE DETECTION ============ */
    function detectChanges() {
        const readyAll = getReadyOrders();
        const currentReadyIds = readyAll.filter(o => o.status === 'ready').map(o => String(o.id));
        const currentPickedUpIds = readyAll.filter(o => o.status === 'picked_up').map(o => String(o.id));

        if (initialSyncDone) {
            const newReady = currentReadyIds.filter(id => !knownReadyIds.includes(id));
            if (newReady.length > 0) {
                playAlert();
                toast(`🔔 ${newReady.length} طلب جديد جاهز للتوصيل`, 'success');
            }

            const removedReady = knownReadyIds.filter(id => !currentReadyIds.includes(id));
            for (const id of removedReady) {
                const order = getPickupOrders().find(o => String(o.id) === id);
                if (!order) continue;
                if (order.status === 'cancelled') {
                    toast(`⚠️ الطلب #${id.split('-').pop()} تم إلغاؤه من المخزن`, 'error');
                } else if (order.courierId && String(order.courierId) !== String(currentCourier.id)) {
                    toast(`⚠️ الطلب #${id.split('-').pop()} أُعيد تعيينه لموصل آخر`, 'error');
                }
            }

            const removedPickedUp = knownPickedUpIds.filter(id => !currentPickedUpIds.includes(id));
            for (const id of removedPickedUp) {
                const order = getPickupOrders().find(o => String(o.id) === id);
                if (!order) continue;
                if (order.status === 'cancelled') {
                    toast(`🚨 الطلب #${id.split('-').pop()} أُلغي أثناء توصيله — رجاءً إرجاعه للمخزن`, 'error');
                } else if (order.courierId && String(order.courierId) !== String(currentCourier.id)) {
                    toast(`⚠️ الطلب #${id.split('-').pop()} حُوّل لموصل آخر`, 'error');
                } else if (order.status === 'ready') {
                    toast(`ℹ️ الطلب #${id.split('-').pop()} أُعيد للمخزن`, 'success');
                }
            }
        }

        knownReadyIds = currentReadyIds;
        knownPickedUpIds = currentPickedUpIds;
    }

    /* ============ REFRESH (Smart — no redraw if no change) ============ */
    function refreshAll() {
        const refreshed = getCouriers().find(c => String(c.id) === String(currentCourier.id));
        if (!refreshed) {
            toast('تم حذف حسابك. سيتم تسجيل الخروج...', 'error');
            setTimeout(() => { localStorage.removeItem(STORAGE.currentUser); location.reload(); }, 2000);
            return;
        }
        if (refreshed.active === false) {
            toast('تم تعطيل حسابك. سيتم تسجيل الخروج...', 'error');
            setTimeout(() => { localStorage.removeItem(STORAGE.currentUser); location.reload(); }, 2000);
            return;
        }
        currentCourier = refreshed;
        document.getElementById('courierName').textContent = currentCourier.name;
        document.getElementById('courierAreas').textContent =
            (currentCourier.areas && currentCourier.areas.length) ? currentCourier.areas.join(' • ') : 'بدون مناطق';

        detectChanges();

        const newSig = computeSignature();
        if (newSig !== lastDataSignature) {
            lastDataSignature = newSig;
            const wasHome = document.getElementById('page-home').classList.contains('active');
            const wasOrders = document.getElementById('page-orders').classList.contains('active');
            const wasHistory = document.getElementById('page-history').classList.contains('active');
            const wasSettle = document.getElementById('page-settle').classList.contains('active');
            if (wasHome) renderHome();
            if (wasOrders) renderOrders();
            if (wasHistory) renderHistory();
            if (wasSettle) renderSettle();
        }
        updateNavBadges();
        updateElapsedLive();
    }

    /* تحديث العدادات الزمنية فقط دون إعادة رسم */
    function updateElapsedLive() {
        document.querySelectorAll('[data-elapsed-id]').forEach(el => {
            const id = el.getAttribute('data-elapsed-id');
            const order = getPickupOrders().find(o => String(o.id) === id);
            if (!order || !order.pickedUpAt) return;
            const txt = elapsedSince(order.pickedUpAt);
            if (el.textContent !== txt) el.textContent = txt;
            const mins = elapsedMinutes(order.pickedUpAt);
            const wrap = el.closest('.info-strip');
            if (wrap) {
                if (mins >= 60) wrap.classList.add('late');
                else wrap.classList.remove('late');
            }
        });
    }

    function updateNavBadges() {
        const activeCount = getReadyOrders().length;
        const bHome = document.getElementById('navBadgeHome');
        const bOrders = document.getElementById('navBadgeOrders');
        if (activeCount > 0) {
            bHome.style.display = 'flex'; bHome.textContent = activeCount;
            bOrders.style.display = 'flex'; bOrders.textContent = activeCount;
        } else {
            bHome.style.display = 'none';
            bOrders.style.display = 'none';
        }
    }

    /* ============ RENDER HOME ============ */
    function renderHome() {
        const unsettled = getUnsettledDeliveries();
        const collected = unsettled.reduce((s, d) => s + (Number(d.cashToCashier != null ? d.cashToCashier : d.amount) || 0), 0);
        const unsettledEarned = unsettled.reduce((s, d) => s + (Number(d.deliveryFee != null ? d.deliveryFee : 0) || 0), 0);

        const earningsEl = document.getElementById('homeEarnings');
        if (earningsEl) earningsEl.textContent = fmt(unsettledEarned) + ' ر.ي';

        const el = document.getElementById('homeCollected');
        const prevVal = parseInt(el.dataset.val || '0');
        el.textContent = fmt(collected);
        el.dataset.val = collected;
        if (collected !== prevVal) { el.classList.add('bump'); setTimeout(() => el.classList.remove('bump'), 600); }

        document.getElementById('homeDeliveredCount').textContent = unsettled.length;

        const ready = getReadyOnly();
        const pickedUp = getPickedUp();
        document.getElementById('kpiPending').textContent = ready.length;

        const todayStr = new Date().toDateString();
        const todayDeliveries = getMyDeliveries().filter(d => new Date(d.deliveredAt).toDateString() === todayStr);
        document.getElementById('kpiTodayDelivered').textContent = todayDeliveries.length;
        const todayAmount = todayDeliveries.reduce((s, d) => s + (Number(d.deliveryFee != null ? d.deliveryFee : 0) || 0), 0);
        document.getElementById('kpiTodayAmount').textContent = fmt(todayAmount);

        const inHandSection = document.getElementById('homeInHandSection');
        const inHandList = document.getElementById('homeInHandList');
        const inHandBadge = document.getElementById('homeInHandBadge');
        if (pickedUp.length > 0) {
            inHandSection.style.display = 'block';
            inHandBadge.textContent = pickedUp.length + ' في اليد';
            inHandList.innerHTML = pickedUp.map(renderOrderCard).join('');
        } else {
            inHandSection.style.display = 'none';
            inHandList.innerHTML = '';
        }

        document.getElementById('pendingBadge').textContent = ready.length + ' طلب';
        const list = document.getElementById('homeOrdersList');
        if (!ready.length) {
            list.innerHTML = `
                <div class="empty-state" style="padding:30px 20px;">
                    <div class="icon" style="width:60px;height:60px;"><i class="fa-solid fa-inbox" style="font-size:24px;"></i></div>
                    <h3 style="font-size:14px;">لا توجد طلبات جاهزة</h3>
                    <p>ستظهر الطلبات هنا عندما يجهزها المخزن ويعينها لك.</p>
                </div>`;
        } else {
            list.innerHTML = ready.slice(0, 5).map(renderOrderCard).join('');
        }
        updateNavBadges();
    }

    /* ============ RENDER ORDERS ============ */
    function renderOrders() {
        const ready = getReadyOnly();
        const pickedUp = getPickedUp();
        const list = document.getElementById('ordersList');

        if (!ready.length && !pickedUp.length) {
            list.innerHTML = `
                <div class="empty-state">
                    <div class="icon"><i class="fa-solid fa-box-open"></i></div>
                    <h3>لا توجد طلبات نشطة</h3>
                    <p>الطلبات التي يجهزها المخزن ويعينها لك ستظهر هنا مباشرة.</p>
                </div>`;
            return;
        }

        let html = '';

        if (pickedUp.length > 0) {
            html += `<div class="section-header" style="margin-top:0;">
                <h2 class="in-hand"><i class="fa-solid fa-motorcycle"></i> في يدك — بانتظار التسليم</h2>
                <span class="section-badge in-hand">${pickedUp.length} طلب</span>
            </div>`;
            html += pickedUp.map(renderOrderCard).join('');
        }

        if (ready.length > 0) {
            html += `<div class="section-header" style="margin-top:${pickedUp.length > 0 ? '20px' : '0'};">
                <h2><i class="fa-solid fa-box-open"></i> جاهزة للاستلام من المخزن</h2>
                <span class="section-badge">${ready.length} طلب</span>
            </div>`;
            html += ready.map(renderOrderCard).join('');
        }

        list.innerHTML = html;
    }

    function renderOrderCard(order) {
        const orderShort = order.id.split('-').pop();
        const amount = Number(order.invoiceTotal != null ? order.invoiceTotal : (productAmount(order) + deliveryFee(order))) || 0;
        const fee = deliveryFee(order);
        const isInHand = order.status === 'picked_up';
        const isOnline = order.source === 'online';

        const itemsHtml = (order.items || []).map(i =>
            `<div class="oc-item">
                <span><b>${i.name}</b> <span class="meta">${i.color || ''} ${i.size ? '• ' + i.size : ''}</span></span>
                <span>× ${i.qty}</span>
            </div>`
        ).join('');

        let contactHtml = '';
        if (order.customer) {
            contactHtml = `
                <div class="oc-contact">
                    ${order.customer.name ? `<div><i class="fa-solid fa-user"></i> ${order.customer.name}</div>` : ''}
                    ${order.customer.phone ? `<div><i class="fa-solid fa-phone"></i> ${order.customer.phone}</div>` : ''}
                    ${order.customer.address || order.customer.city ? `<div><i class="fa-solid fa-location-dot"></i> ${order.customer.city || ''} ${order.customer.address || ''}</div>` : ''}
                </div>`;
        } else if (order.customerNo) {
            contactHtml = `<div class="oc-contact"><div><i class="fa-solid fa-user"></i> زبونة #${order.customerNo}</div></div>`;
        }

        let feeWarnHtml = '';
        if (isOnline && fee === 0) {
            feeWarnHtml = `<div class="info-strip danger">
                <i class="fa-solid fa-triangle-exclamation"></i>
                <span>لم تُحدَّد أجرة توصيل لهذا الطلب. تواصل مع المخزن قبل الاستلام.</span>
            </div>`;
        } else if (!isOnline && fee === 0) {
            feeWarnHtml = `<div class="info-strip warn">
                <i class="fa-solid fa-info-circle"></i>
                <span>هذا طلب كاشير بدون رسوم توصيل مسجلة.</span>
            </div>`;
        }

        let elapsedHtml = '';
        if (isInHand && order.pickedUpAt) {
            const mins = elapsedMinutes(order.pickedUpAt);
            const lateCls = mins >= 60 ? ' late' : '';
            elapsedHtml = `<div class="info-strip elapsed${lateCls}">
                <i class="fa-solid fa-clock"></i>
                <span>في يدك منذ <b data-elapsed-id="${order.id}">${elapsedSince(order.pickedUpAt)}</b>${mins >= 60 ? ' — ⚠️ تأخر' : ''}</span>
            </div>`;
        }

        return `
            <div class="order-card ${isInHand ? 'in-hand' : ''}">
                <div class="oc-top">
                    <span class="oc-id">REQ-${orderShort}</span>
                    <span class="oc-amount">${fmt(amount)} ر.ي</span>
                </div>
                ${order.customer ? `<div class="oc-customer"><i class="fa-solid fa-user"></i>${order.customer.name || 'زبونة'}</div>` : ''}
                ${contactHtml}
                <div class="oc-items">${itemsHtml || '<div style="color:var(--muted);">لا توجد أصناف</div>'}</div>
                <div class="info-strip pricing">
                    <div>قيمة المنتجات المطلوب توريدها للكاشير: <b>${fmt(productAmount(order))} ر.ي</b></div>
                    <div class="earn">أجرة التوصيل المستحقة لك: <b>${fmt(fee)} ر.ي</b></div>
                    <div>إجمالي ما يدفعه العميل: <b>${fmt(productAmount(order) + fee)} ر.ي</b></div>
                </div>
                ${feeWarnHtml}
                ${elapsedHtml}
                ${isInHand
                    ? `<button class="oc-btn" onclick="window.deliverOrder('${order.id}', event)"><i class="fa-solid fa-check-circle"></i> تأكيد التسليم للعميل</button>
                       <button class="oc-btn" style="background:#b45309;margin-top:7px;box-shadow:0 4px 15px rgba(180,83,9,0.4);" onclick="window.failDelivery('${order.id}', event)"><i class="fa-solid fa-rotate-left"></i> تعذر التوصيل — إعادة للمخزن</button>`
                    : `<button class="oc-btn pickup" onclick="window.pickupOrder('${order.id}', event)"><i class="fa-solid fa-box"></i> استلام الطلب من المخزن</button>`}
            </div>`;
    }

    /* ============ PICKUP FROM WAREHOUSE (Race-safe) ============ */
    window.pickupOrder = function(orderId, event) {
        if (event) event.stopPropagation();
        if (!lockAction()) return toast('جارٍ التنفيذ — انتظر لحظة', 'error');

        let orders = getPickupOrders();
        let order = orders.find(o => String(o.id) === String(orderId));
        if (!order) return toast('الطلب غير موجود', 'error');
        if (order.status !== 'ready' || order.pickedUpAt) return toast('الطلب ليس جاهزاً أو تم استلامه مسبقاً', 'error');
        if (order.courierId && String(order.courierId) !== String(currentCourier.id)) return toast('هذا الطلب مُسند لموصل آخر', 'error');

        const fee = deliveryFee(order);
        let msg = `تأكيد استلام الطلب REQ-${order.id.split('-').pop()} من المخزن؟\n\n`;
        msg += `قيمة المنتجات (توردها للكاشير): ${fmt(productAmount(order))} ر.ي\n`;
        msg += `أجرة توصيلك: ${fmt(fee)} ر.ي\n`;
        msg += `إجمالي ما ستدفعه/تحصل عليه: ${fmt(productAmount(order) + fee)} ر.ي\n\n`;
        if (order.source === 'online' && fee === 0) {
            msg += `⚠️ تحذير: أجرة التوصيل = 0. تواصل مع المخزن أولاً.\n\n`;
        } else if (order.source === 'pos' && fee === 0) {
            msg += `ℹ️ ملاحظة: هذا طلب كاشير بدون رسوم توصيل مسجلة.\n\n`;
        }
        msg += `بعد التأكيد لن يمكن تغيير الموصل.`;
        if (!confirm(msg)) return;

        // إعادة القراءة لمنع السبق
        orders = getPickupOrders();
        const freshIdx = orders.findIndex(o => String(o.id) === String(orderId));
        if (freshIdx < 0) return toast('الطلب حُذف من النظام', 'error');
        const fresh = orders[freshIdx];
        if (fresh.status !== 'ready' || fresh.pickedUpAt) {
            toast('⚠️ سبقك موصل آخر لهذا الطلب', 'error');
            lastDataSignature = '';
            refreshAll();
            return;
        }
        if (fresh.courierId && String(fresh.courierId) !== String(currentCourier.id)) {
            toast('هذا الطلب أُسند لموصل آخر', 'error');
            lastDataSignature = '';
            refreshAll();
            return;
        }

        const now = new Date().toISOString();
        fresh.status = 'picked_up';
        fresh.pickedUpAt = now;
        fresh.courierId = currentCourier.id;
        fresh.courierName = currentCourier.name;
        addOrderEvent(fresh, 'courier_picked_up', 'استلم الموصل الطلب من المخزن');
        localStorage.setItem(STORAGE.pickupOrders, JSON.stringify(orders));
        toast('✅ تم تأكيد الاستلام. يمكنك الآن توصيله للعميل.', 'success');
        lastDataSignature = '';
        refreshAll();
    };

    /* ============ DELIVER ORDER ============ */
    window.deliverOrder = function(orderId, event) {
        if (event) event.stopPropagation();
        if (!lockAction()) return toast('جارٍ التنفيذ — انتظر لحظة', 'error');

        const orders = getPickupOrders();
        const idx = orders.findIndex(o => String(o.id) === String(orderId));
        if (idx < 0) return toast('الطلب غير موجود', 'error');
        const order = orders[idx];
        if (order.status !== 'picked_up' || !order.pickedUpAt) return toast('يجب تأكيد استلام الطلب من المخزن أولاً', 'error');
        if (order.deliveredAt || getDeliveries().some(d => String(d.orderId) === String(orderId))) return toast('تم تسجيل توصيل هذا الطلب مسبقاً', 'error');
        if (String(order.courierId) !== String(currentCourier.id)) return toast('هذا الطلب مُسند لموصل آخر', 'error');

        const remitAmount = productAmount(order);
        const earnedFee = deliveryFee(order);
        if (!confirm(`تأكيد تسليم الطلب REQ-${order.id.split('-').pop()}؟\n\nقيمة المنتجات التي توردها للكاشير: ${fmt(remitAmount)} ر.ي\nأجرة التوصيل المستحقة لك: ${fmt(earnedFee)} ر.ي\nإجمالي ما دفعه العميل: ${fmt(remitAmount + earnedFee)} ر.ي`)) return;

        const now = new Date().toISOString();
        order.status = 'delivered';
        order.deliveredAt = now;
        order.cashierRemittance = remitAmount;
        order.courierEarning = earnedFee;
        addOrderEvent(order, 'delivered', 'تم التسليم؛ توريد المنتجات ' + remitAmount + '؛ أجرة الموصل ' + earnedFee);
        localStorage.setItem(STORAGE.pickupOrders, JSON.stringify(orders));

        const deliveries = getDeliveries();
        deliveries.push({
            id: 'DEL-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
            orderId, orderShort: order.id.split('-').pop(),
            courierId: currentCourier.id, courierName: currentCourier.name,
            amount: remitAmount, cashToCashier: remitAmount,
            deliveryFee: earnedFee, courierEarning: earnedFee,
            items: order.items || [], customer: order.customer || null,
            customerNo: order.customerNo || null, deliveredAt: now,
            settled: false, settledAt: null
        });
        localStorage.setItem(STORAGE.deliveries, JSON.stringify(deliveries));
        toast('تم تسجيل التسليم. أجرة التوصيل لك، وقيمة المنتجات تُورّد للكاشير.', 'success');
        lastDataSignature = '';
        refreshAll();
    };

    /* ============ DELIVERY FAILED / RETURN TO WAREHOUSE ============ */
    window.failDelivery = function(orderId, event) {
        if (event) event.stopPropagation();
        if (!lockAction()) return toast('جارٍ التنفيذ — انتظر لحظة', 'error');

        const reason = prompt('اكتب سبب تعذر التوصيل (مثال: العميل لا يرد، العنوان غير صحيح، رفض الاستلام):');
        if (!reason || !reason.trim()) return toast('يجب كتابة سبب التعذر', 'error');
        const orders = getPickupOrders();
        const idx = orders.findIndex(o => String(o.id) === String(orderId));
        if (idx < 0) return toast('الطلب غير موجود', 'error');
        const order = orders[idx];
        if (order.status !== 'picked_up' || String(order.courierId) !== String(currentCourier.id)) return toast('لا يمكن إرجاع هذا الطلب من حسابك', 'error');
        const now = new Date().toISOString();
        order.status = 'ready';
        order.deliveryFailedAt = now;
        order.deliveryFailureReason = reason.trim();
        order.lastCourierId = currentCourier.id;
        order.lastCourierName = currentCourier.name;
        order.courierId = null;
        order.courierName = null;
        delete order.pickedUpAt;
        addOrderEvent(order, 'delivery_failed', 'تعذر التوصيل: ' + reason.trim() + ' — أُعيد للمخزن لإعادة التعيين');
        localStorage.setItem(STORAGE.pickupOrders, JSON.stringify(orders));
        toast('تم إرجاع الطلب للمخزن مع تسجيل السبب', 'success');
        lastDataSignature = '';
        refreshAll();
    };

    /* ============ RENDER HISTORY ============ */
    function renderHistory() {
        const all = getMyDeliveries();
        const unsettled = all.filter(d => !d.settled);
        const settled = all.filter(d => d.settled);

        document.getElementById('histUnsettled').textContent = unsettled.length;
        document.getElementById('histSettled').textContent = settled.length;

        const totalEarned = all.reduce((s, d) => s + (Number(d.deliveryFee != null ? d.deliveryFee : 0) || 0), 0);
        document.getElementById('histTotalEarnings').textContent = fmt(totalEarned) + ' ر.ي';

        const list = document.getElementById('historyList');
        if (!all.length) {
            list.innerHTML = `
                <div class="empty-state">
                    <div class="icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
                    <h3>لا توجد توصيلات بعد</h3>
                    <p>ستظهر هنا كل عمليات التوصيل التي تسجلها.</p>
                </div>`;
            return;
        }

        list.innerHTML = all.map(d => {
            const time = new Date(d.deliveredAt).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });
            const statusBadge = d.settled
                ? `<span class="status-badge settled"><i class="fa-solid fa-check"></i> مُسوّى</span>`
                : `<span class="status-badge unsettled"><i class="fa-solid fa-clock"></i> غير مُسوّى</span>`;
            const custName = d.customer?.name || (d.customerNo ? 'زبونة #' + d.customerNo : '—');
            return `
                <div class="history-item">
                    <div class="hi-top">
                        <span class="hi-id">REQ-${d.orderShort || d.orderId.split('-').pop()}</span>
                        <span class="hi-amount">توريد: ${fmt(d.amount)} ر.ي</span>
                    </div>
                    <div class="hi-customer"><i class="fa-solid fa-user"></i>${custName}</div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:8px; flex-wrap:wrap; gap:6px;">
                        <span class="hi-time"><i class="fa-regular fa-clock"></i> ${time}</span>
                        <span style="color:#047857;font-size:11px;font-weight:800;">أجرتك: ${fmt(d.deliveryFee != null ? d.deliveryFee : 0)} ر.ي</span>
                        ${statusBadge}
                    </div>
                </div>`;
        }).join('');
    }

    /* ============ RENDER SETTLE ============ */
    function renderSettle() {
        const unsettled = getUnsettledDeliveries();
        const total = unsettled.reduce((s, d) => s + (Number(d.cashToCashier != null ? d.cashToCashier : d.amount) || 0), 0);
        document.getElementById('settleAmount').textContent = fmt(total);
        document.getElementById('settleCount').textContent = unsettled.length;
        document.getElementById('settleBtn').disabled = unsettled.length === 0;

        const settlements = getSettlements()
            .filter(s => String(s.courierId) === String(currentCourier.id))
            .sort((a, b) => new Date(b.settledAt) - new Date(a.settledAt));

        const list = document.getElementById('settleHistoryList');
        if (!settlements.length) {
            list.innerHTML = `<div class="empty-state" style="padding:30px 20px;"><div class="icon" style="width:60px;height:60px;"><i class="fa-solid fa-receipt" style="font-size:24px;"></i></div><h3 style="font-size:13px;">لا توجد عمليات تصفير سابقة</h3></div>`;
            return;
        }
        list.innerHTML = settlements.slice(0, 10).map(s => {
            const time = new Date(s.settledAt).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' });
            return `
                <div class="history-item">
                    <div class="hi-top">
                        <span class="hi-id">${s.id.split('-').pop()}</span>
                        <span class="hi-amount">توريد: ${fmt(s.amount)} ر.ي</span>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-top:6px; flex-wrap:wrap; gap:6px;">
                        <span class="hi-time"><i class="fa-regular fa-clock"></i> ${time}</span>
                        <span style="font-size:11px;color:#047857;font-weight:800;">أجورك: ${fmt(s.courierEarnings || 0)} ر.ي</span>
                        <span style="font-size:11px; color:var(--muted);">${s.count} عملية</span>
                    </div>
                </div>`;
        }).join('');
    }

    /* ============ SETTLE ACCOUNT ============ */
    window.settleAccount = function() {
        if (!lockAction()) return toast('جارٍ التنفيذ — انتظر لحظة', 'error');

        const unsettled = getUnsettledDeliveries();
        if (!unsettled.length) return toast('لا يوجد مبلغ لتصفيره', 'error');

        const total = unsettled.reduce((s, d) => s + (Number(d.cashToCashier != null ? d.cashToCashier : d.amount) || 0), 0);
        const earned = unsettled.reduce((s, d) => s + (Number(d.deliveryFee != null ? d.deliveryFee : 0) || 0), 0);

        if (!confirm(`⚠️ تأكيد توريد قيمة المنتجات للكاشير\n\nالمبلغ: ${fmt(total)} ر.ي\nأجورك من هذه العمليات: ${fmt(earned)} ر.ي\nعدد العمليات: ${unsettled.length}\n\nسيتم تسوية قيمة المنتجات فقط. أجور التوصيل تبقى مستحقة لك. هل سلّمت المبلغ يدوياً؟`)) return;

        const now = new Date().toISOString();
        const idsToSettle = unsettled.map(d => d.id);
        const orderIds = unsettled.map(d => d.orderId);

        const deliveries = getDeliveries();
        let changed = 0;
        deliveries.forEach(d => {
            if (idsToSettle.includes(d.id) && !d.settled) {
                d.settled = true;
                d.settledAt = now;
                changed++;
            }
        });
        if (!changed) return toast('تمت تسوية هذه العمليات مسبقاً', 'error');
        localStorage.setItem(STORAGE.deliveries, JSON.stringify(deliveries));

        const orders = getPickupOrders();
        orders.forEach(o => {
            if (orderIds.includes(o.id) && o.status !== 'completed') {
                o.status = 'completed';
                o.completedAt = now;
                addOrderEvent(o, 'cash_remitted', 'تم توريد قيمة المنتجات للكاشير');
            }
        });
        localStorage.setItem(STORAGE.pickupOrders, JSON.stringify(orders));

        const settlements = getSettlements();
        settlements.push({
            id: 'SET-' + Date.now(),
            courierId: currentCourier.id,
            courierName: currentCourier.name,
            amount: total,
            courierEarnings: earned,
            count: idsToSettle.length,
            settledAt: now
        });
        localStorage.setItem(STORAGE.settlements, JSON.stringify(settlements));

        toast(`✅ تم توريد ${fmt(total)} ر.ي. أجورك من هذه العمليات ${fmt(earned)} ر.ي تبقى لك.`, 'success');
        lastDataSignature = '';
        refreshAll();
    };

    /* ============ AUTO LOGIN ============ */
    window.addEventListener('DOMContentLoaded', () => {
        const saved = JSON.parse(localStorage.getItem(STORAGE.currentUser) || 'null');
        if (saved) {
            const courier = getCouriers().find(c => String(c.userId) === String(saved.id));
            if (courier && courier.active !== false) {
                currentCourier = courier;
                enterApp();
            } else {
                localStorage.removeItem(STORAGE.currentUser);
            }
        }
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && document.getElementById('login-screen').style.display !== 'none') {
            if (document.activeElement && ['loginUser','loginPass'].includes(document.activeElement.id)) window.login();
        }
    });

})();
