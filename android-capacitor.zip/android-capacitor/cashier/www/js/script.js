(function() {
    'use strict';
    
    let rawProducts = [];
    let products = [];
    let cart = [];
    let currentUser = null;
    let html5QrcodeScanner = null;
    let currentReturnInvoice = null;
    let currentManualReturnItem = null;
    let pendingReadyOrder = null;
    let knownReadyOrders = JSON.parse(localStorage.getItem('maqlis_pos_known_ready') || '[]');
    let readyOrdersInterval = null;
    let clockInterval = null;
    let shiftTimerInterval = null;
    
    let customerBaskets = [];
    let activeBasketId = null;
    
    let currentFilters = { cat: 'all', subcat: 'all', date: 'all', search: '' };
    const TAX_RATE = 0.15;
    
    let currentShift = null;
    let lastClosedShift = null;
    let shiftLiveStats = { invoices: 0, items: 0, total: 0, cash: 0, wallets: 0, online: 0, returns: 0, breakdown: {} };
    
    const WALLET_METHODS = ['جيب', 'كريمي', 'فلوسك', 'جوالي', 'موبايل موني'];
    
    const STORAGE_KEYS = {
        SHIFTS: 'maqlis_shifts',
        OPEN_SHIFT_PREFIX: 'maqlis_open_shift_',
        SALES: 'maqlis_sales',
        INVENTORY: 'maqlis_inventory',
        PICKUP: 'maqlis_pickup_orders',
        USERS: 'maqlis_users',
        CURRENT_USER: 'maqlis_currentUser_pos',
        CART_PREFIX: 'maqlis_pos_cart_',
        BASKETS_PREFIX: 'maqlis_sub_baskets_',
        KNOWN_READY: 'maqlis_pos_known_ready',
        STOCK_MOVEMENTS: 'maqlis_stock_movements'
    };
    
    const CATEGORIES_MAP = {
        'أحذية': { key: 'shoes', icon: '👟', sub: ['كعب', 'سبورت', 'طبي', 'سليبر'] },
        'شنط': { key: 'bags', icon: '👜', sub: ['جامعي', 'عرائسي', 'شنط يد', 'شنط سفر', 'شنط ظهر'] },
        'اكسسوارات': { key: 'accessories', icon: '💍', sub: ['خواتم', 'اساور', 'طقوم', 'ساعات'] },
        'ملابس': { key: 'dresses', icon: '👗', sub: ['فساتين', 'بجايم', 'طقوم', 'بلايز', 'بناطيل'] },
        'أخرى': { key: 'other', icon: '📦', sub: ['منتجات أخرى'] }
    };
    
    function fmt(n) {
        return Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 }) + ' ر.ي';
    }
    
    /* ============================================================
       ⭐ STOCK MOVEMENT LOGGER — التعديل الأساسي
       ============================================================ */
    function logStockMovement(sku, type, qty, qtyBefore, qtyAfter, refId, note) {
        try {
            const movements = JSON.parse(localStorage.getItem(STORAGE_KEYS.STOCK_MOVEMENTS)) || [];
            const product = rawProducts.find(p => p.sku === sku);
            const shift = currentShift || getCurrentShiftFromStorage();
            
            movements.push({
                id: 'MOV-' + Date.now() + '-' + Math.floor(Math.random() * 10000),
                date: new Date().toISOString(),
                sku: sku,
                productName: product ? product.name : '—',
                color: product ? (product.color || '') : '',
                size: product ? (product.size || '') : '',
                type: type,
                qty: qty,
                qtyBefore: qtyBefore,
                qtyAfter: qtyAfter,
                refId: refId || null,
                userId: currentUser ? currentUser.id : null,
                userName: currentUser ? currentUser.name : 'غير معروف',
                shiftId: shift ? shift.id : null,
                note: note || ''
            });
            
            localStorage.setItem(STORAGE_KEYS.STOCK_MOVEMENTS, JSON.stringify(movements));
        } catch (e) {
            console.error('Failed to log stock movement:', e);
        }
    }
    
    function generateShiftId(userId) {
        return 'SHIFT-' + userId + '-' + Date.now();
    }
    
    function getShiftsRegistry() {
        try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.SHIFTS)) || []; }
        catch { return []; }
    }
    
    function saveShiftsRegistry(shifts) {
        localStorage.setItem(STORAGE_KEYS.SHIFTS, JSON.stringify(shifts));
    }
    
    function getOpenShiftId(userId) {
        return localStorage.getItem(STORAGE_KEYS.OPEN_SHIFT_PREFIX + userId);
    }
    
    function setOpenShiftId(userId, shiftId) {
        localStorage.setItem(STORAGE_KEYS.OPEN_SHIFT_PREFIX + userId, shiftId);
    }
    
    function clearOpenShiftId(userId) {
        localStorage.removeItem(STORAGE_KEYS.OPEN_SHIFT_PREFIX + userId);
    }
    
    function formatDuration(ms) {
        if (ms < 0) ms = 0;
        const totalSec = Math.floor(ms / 1000);
        const h = Math.floor(totalSec / 3600);
        const m = Math.floor((totalSec % 3600) / 60);
        const s = totalSec % 60;
        return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    }
    
    let globalAudioCtx = null;
    function playBeep(type) {
        type = type || 'success';
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            if (!globalAudioCtx) globalAudioCtx = new AudioContext();
            if (globalAudioCtx.state === 'suspended') globalAudioCtx.resume();
            const osc = globalAudioCtx.createOscillator();
            const gain = globalAudioCtx.createGain();
            osc.connect(gain);
            gain.connect(globalAudioCtx.destination);
            if (type === 'success') {
                osc.type = 'sine';
                osc.frequency.setValueAtTime(880, globalAudioCtx.currentTime);
                osc.frequency.setValueAtTime(1318.51, globalAudioCtx.currentTime + 0.1);
                gain.gain.setValueAtTime(0.2, globalAudioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, globalAudioCtx.currentTime + 0.3);
                osc.start(globalAudioCtx.currentTime);
                osc.stop(globalAudioCtx.currentTime + 0.3);
            } else {
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(200, globalAudioCtx.currentTime);
                gain.gain.setValueAtTime(0.2, globalAudioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, globalAudioCtx.currentTime + 0.2);
                osc.start(globalAudioCtx.currentTime);
                osc.stop(globalAudioCtx.currentTime + 0.2);
            }
        } catch (e) {}
    }
    
    function showToast(msg, type) {
        type = type || 'success';
        const toast = document.createElement('div');
        toast.className = 'toast ' + (type === 'error' ? 'error' : '');
        toast.innerHTML = '<i class="fa-solid ' + (type === 'success' ? 'fa-check-circle' : 'fa-circle-exclamation') + '"></i><span>' + msg + '</span>';
        document.getElementById('toastContainer').appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);
        setTimeout(() => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 300); }, 2800);
    }
    
    /* ============================================================
       SHIFT ENGINE
       ============================================================ */
    function computeShiftStats(shiftId) {
        const sales = JSON.parse(localStorage.getItem(STORAGE_KEYS.SALES)) || [];
        const shiftSales = sales.filter(s => s.shiftId === shiftId);
        const stats = { invoices: 0, items: 0, total: 0, cash: 0, wallets: 0, online: 0, returns: 0, breakdown: {} };
        
        shiftSales.forEach(sale => {
            const isReturn = sale.source === 'return' || (sale.total < 0);
            const amount = Math.abs(sale.total || 0);
            const method = sale.paymentMethod || 'غير محدد';
            if (!stats.breakdown[method]) stats.breakdown[method] = { sales: 0, returns: 0, net: 0, count: 0 };
            if (isReturn) {
                stats.returns += amount;
                stats.breakdown[method].returns += amount;
                stats.breakdown[method].net -= amount;
                stats.total -= amount;
            } else {
                stats.invoices++;
                stats.items += (sale.items || []).reduce((sum, i) => sum + (i.qty || 0), 0);
                stats.total += amount;
                stats.breakdown[method].sales += amount;
                stats.breakdown[method].net += amount;
                stats.breakdown[method].count++;
                if (method === 'نقدي') stats.cash += amount;
                else if (method === 'طلب من المخزن') {}
                else if (WALLET_METHODS.includes(method)) stats.wallets += amount;
            }
        });
        return stats;
    }
    
    function getCurrentShiftFromStorage() {
        if (!currentUser) return null;
        const shiftId = getOpenShiftId(currentUser.id);
        if (!shiftId) return null;
        const shifts = getShiftsRegistry();
        return shifts.find(s => s.id === shiftId) || null;
    }
    
    function startShiftTimer() {
        if (shiftTimerInterval) clearInterval(shiftTimerInterval);
        shiftTimerInterval = setInterval(() => {
            if (!currentShift) return;
            const duration = formatDuration(Date.now() - new Date(currentShift.openedAt).getTime());
            const el = document.getElementById('shiftDuration');
            if (el) el.textContent = duration;
        }, 1000);
    }
    
    function updateShiftBar() {
        if (!currentShift) return;
        shiftLiveStats = computeShiftStats(currentShift.id);
        const duration = formatDuration(Date.now() - new Date(currentShift.openedAt).getTime());
        const statusText = document.getElementById('shiftStatusText');
        const durationEl = document.getElementById('shiftDuration');
        const invoicesEl = document.getElementById('shiftInvoices');
        const totalEl = document.getElementById('shiftTotal');
        if (statusText) statusText.textContent = 'الوردية مفتوحة';
        if (durationEl) durationEl.textContent = duration;
        if (invoicesEl) invoicesEl.textContent = shiftLiveStats.invoices + ' فاتورة';
        if (totalEl) totalEl.textContent = fmt(shiftLiveStats.total);
    }
    
    window.openOpenShiftModal = function() {
        const modal = document.getElementById('openShiftModal');
        document.getElementById('openShiftUserName').textContent = currentUser ? currentUser.name : '—';
        document.getElementById('openShiftFloat').value = 0;
        document.getElementById('openShiftNote').value = '';
        modal.classList.add('show');
    };
    
    window.cancelOpenShift = function() {
        document.getElementById('openShiftModal').classList.remove('show');
        window.logout(false);
    };
    
    window.confirmOpenShift = function() {
        const float = parseFloat(document.getElementById('openShiftFloat').value) || 0;
        const note = document.getElementById('openShiftNote').value.trim();
        if (float < 0) { showToast('العهدة لا يمكن أن تكون سالبة', 'error'); return; }
        
        const shiftId = generateShiftId(currentUser.id);
        const shift = {
            id: shiftId, cashierId: currentUser.id, cashierName: currentUser.name,
            openedAt: new Date().toISOString(), closedAt: null, status: 'open',
            openingFloat: float, openingNote: note,
            expected: null, actual: null, difference: null, breakdown: null, note: ''
        };
        
        const shifts = getShiftsRegistry();
        shifts.push(shift);
        saveShiftsRegistry(shifts);
        setOpenShiftId(currentUser.id, shiftId);
        currentShift = shift;
        document.getElementById('openShiftModal').classList.remove('show');
        startShiftTimer();
        updateShiftBar();
        showToast('✅ تم فتح الوردية بنجاح');
    };
    
    window.openShiftSummary = function() {
        if (!currentShift) return;
        const stats = computeShiftStats(currentShift.id);
        const duration = formatDuration(Date.now() - new Date(currentShift.openedAt).getTime());
        const openedAtStr = new Date(currentShift.openedAt).toLocaleString('ar-EG');
        
        const body = document.getElementById('shiftSummaryBody');
        body.innerHTML = '<div class="shift-stats-grid">' +
                '<div class="shift-stat-card gold"><div class="label"><i class="fa-solid fa-coins"></i> إجمالي المبيعات</div><div class="value">' + fmt(stats.total) + '</div></div>' +
                '<div class="shift-stat-card blue"><div class="label"><i class="fa-solid fa-receipt"></i> الفواتير</div><div class="value">' + stats.invoices + '</div></div>' +
                '<div class="shift-stat-card green"><div class="label"><i class="fa-solid fa-box"></i> القطع</div><div class="value">' + stats.items + '</div></div>' +
                '<div class="shift-stat-card red"><div class="label"><i class="fa-solid fa-rotate-left"></i> المرتجعات</div><div class="value">' + fmt(stats.returns) + '</div></div>' +
            '</div>' +
            '<div style="display:grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 18px;">' +
                '<div style="background:#F8FAFC; padding: 12px; border-radius: 10px;"><div style="font-size: 11px; color: var(--muted); font-weight: 700; margin-bottom: 4px;">⏱ مدة الوردية</div><div style="font-size: 18px; font-weight: 900; color: var(--dark); font-variant-numeric: tabular-nums;">' + duration + '</div></div>' +
                '<div style="background:#F8FAFC; padding: 12px; border-radius: 10px;"><div style="font-size: 11px; color: var(--muted); font-weight: 700; margin-bottom: 4px;">🕐 وقت الفتح</div><div style="font-size: 13px; font-weight: 700; color: var(--dark);">' + openedAtStr + '</div></div>' +
            '</div>' +
            '<h3 style="font-size: 14px; color: var(--dark); margin-bottom: 10px; display: flex; align-items: center; gap: 6px;"><i class="fa-solid fa-list" style="color: var(--gold);"></i> تفصيل حسب طريقة الدفع</h3>' +
            '<table class="shift-breakdown-table"><thead><tr><th>الطريقة</th><th>الفواتير</th><th>مبيعات</th><th>مرتجعات</th><th>الصافي</th></tr></thead><tbody>' +
                (Object.keys(stats.breakdown).length === 0 
                    ? '<tr><td colspan="5" style="text-align:center; color:var(--muted); padding: 20px;">لا توجد عمليات بعد</td></tr>'
                    : Object.entries(stats.breakdown).map(([method, data]) => 
                        '<tr><td>' + method + '</td><td>' + (data.count || 0) + '</td><td>' + fmt(data.sales) + '</td><td style="color: ' + (data.returns > 0 ? 'var(--danger)' : 'var(--muted)') + ';">' + (data.returns > 0 ? '-' + fmt(data.returns) : '—') + '</td><td style="color: var(--gold-hover); font-weight: 900;">' + fmt(data.net) + '</td></tr>'
                    ).join('')
                ) +
            '</tbody></table>' +
            '<div style="background: linear-gradient(135deg, #FFFEF9, #FFF9E6); border: 2px solid var(--gold); border-radius: 12px; padding: 14px; margin-top: 15px;">' +
                '<div style="display: flex; justify-content: space-between; align-items: center;"><span style="font-size: 13px; font-weight: 800; color: var(--gold-hover);">💰 العهدة الابتدائية:</span><span style="font-size: 15px; font-weight: 900; color: var(--dark);">' + fmt(currentShift.openingFloat || 0) + '</span></div>' +
                '<div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px; padding-top: 8px; border-top: 1px dashed rgba(201,169,97,0.4);"><span style="font-size: 13px; font-weight: 800; color: var(--gold-hover);">📊 المتوقع في الدرج (نقدي):</span><span style="font-size: 17px; font-weight: 900; color: var(--gold-hover);">' + fmt((currentShift.openingFloat || 0) + stats.cash) + '</span></div>' +
            '</div>';
        
        document.getElementById('shiftSummaryModal').classList.add('show');
    };
    
    window.closeShiftSummary = function() {
        document.getElementById('shiftSummaryModal').classList.remove('show');
    };
    
    window.openCloseShiftModal = function() {
        if (!currentShift) { showToast('لا توجد وردية مفتوحة', 'error'); return; }
        const stats = computeShiftStats(currentShift.id);
        const openingFloat = currentShift.openingFloat || 0;
        const expectedCash = openingFloat + stats.cash;
        const expectedWallets = stats.wallets;
        const duration = formatDuration(Date.now() - new Date(currentShift.openedAt).getTime());
        
        const body = document.getElementById('closeShiftBody');
        body.innerHTML = '<div class="shift-warning info"><i class="fa-solid fa-circle-info"></i><div>راجع الأرقام المتوقعة من النظام، ثم أدخل المبالغ الفعلية الموجودة لديك.</div></div>' +
            '<div class="shift-stats-grid">' +
                '<div class="shift-stat-card blue"><div class="label"><i class="fa-solid fa-clock"></i> المدة</div><div class="value" style="font-size: 16px;">' + duration + '</div></div>' +
                '<div class="shift-stat-card gold"><div class="label"><i class="fa-solid fa-receipt"></i> الفواتير</div><div class="value">' + stats.invoices + '</div></div>' +
                '<div class="shift-stat-card green"><div class="label"><i class="fa-solid fa-box"></i> القطع</div><div class="value">' + stats.items + '</div></div>' +
                '<div class="shift-stat-card red"><div class="label"><i class="fa-solid fa-rotate-left"></i> المرتجعات</div><div class="value">' + fmt(stats.returns) + '</div></div>' +
            '</div>' +
            '<div class="close-shift-summary">' +
                '<h3><i class="fa-solid fa-calculator"></i> المتوقع من النظام</h3>' +
                '<div class="close-shift-row"><span>💰 العهدة الابتدائية</span><span class="val">' + fmt(openingFloat) + '</span></div>' +
                '<div class="close-shift-row"><span>💵 مبيعات نقدية</span><span class="val" style="color: var(--success);">+ ' + fmt(stats.cash) + '</span></div>' +
                '<div class="close-shift-row"><span>💳 مبيعات محافظ إلكترونية</span><span class="val" style="color: var(--blue);">' + fmt(expectedWallets) + '</span></div>' +
                '<div class="close-shift-row"><span>📊 <strong>المتوقع في الدرج (نقدي)</strong></span><span class="val" style="color: var(--gold-hover);">' + fmt(expectedCash) + '</span></div>' +
            '</div>' +
            '<div class="actual-inputs"><h3><i class="fa-solid fa-hand-holding-dollar"></i> الفعلي (أدخله يدوياً)</h3>' +
                '<div class="actual-input-row"><div class="actual-input-label"><i class="fa-solid fa-money-bill-wave"></i> النقدية في الدرج</div><div class="actual-input-wrap"><input type="number" id="closeActualCash" min="0" step="100" value="' + expectedCash + '" oninput="window.onActualCashChange()"><span class="unit">ر.ي</span></div></div>' +
                '<div class="actual-input-row"><div class="actual-input-label"><i class="fa-solid fa-wallet"></i> المحافظ الإلكترونية</div><div class="actual-input-wrap"><input type="number" id="closeActualWallets" min="0" step="100" value="' + expectedWallets + '" oninput="window.onActualCashChange()"><span class="unit">ر.ي</span></div></div>' +
            '</div>' +
            '<div id="diffDisplayContainer"></div>' +
            '<div class="shift-form-group" style="margin-top: 15px;"><label>📝 ملاحظة (إجبارية عند وجود فرق)</label><input type="text" id="closeShiftNote" class="shift-input" placeholder="سبب الفرق إن وجد..."><div class="shift-hint" id="closeShiftNoteHint">مثال: عجز 500 ر.ي بسبب خطأ في إرجاع الباقي</div></div>' +
            '<div id="closeShiftWarningContainer"></div>';
        
        document.getElementById('closeShiftModal').classList.add('show');
        window.onActualCashChange();
    };
    
    window.onActualCashChange = function() {
        if (!currentShift) return;
        const stats = computeShiftStats(currentShift.id);
        const openingFloat = currentShift.openingFloat || 0;
        const expectedCash = openingFloat + stats.cash;
        const expectedWallets = stats.wallets;
        const actualCash = parseFloat(document.getElementById('closeActualCash').value) || 0;
        const actualWallets = parseFloat(document.getElementById('closeActualWallets').value) || 0;
        const cashDiff = actualCash - expectedCash;
        const walletsDiff = actualWallets - expectedWallets;
        const totalDiff = cashDiff + walletsDiff;
        
        const container = document.getElementById('diffDisplayContainer');
        const warningContainer = document.getElementById('closeShiftWarningContainer');
        const noteInput = document.getElementById('closeShiftNote');
        
        function diffBadge(val) {
            const cls = val === 0 ? 'zero' : (val > 0 ? 'positive' : 'negative');
            const sign = val > 0 ? '+' : (val < 0 ? '-' : '');
            return '<span class="diff-badge ' + cls + '">' + sign + fmt(Math.abs(val)) + '</span>';
        }
        
        container.innerHTML = '<div style="background: #F8FAFC; border: 1.5px solid var(--border); border-radius: 12px; padding: 14px;">' +
            '<div class="diff-display-row"><span class="label">فرق النقدية</span><span class="value">' + diffBadge(cashDiff) + '</span></div>' +
            '<div class="diff-display-row"><span class="label">فرق المحافظ</span><span class="value">' + diffBadge(walletsDiff) + '</span></div>' +
            '<div class="diff-display-row" style="border-top: 2px solid var(--border); padding-top: 12px; margin-top: 6px;"><span class="label" style="font-weight: 900; color: var(--dark); font-size: 14px;">الفرق الإجمالي</span><span class="value">' + diffBadge(totalDiff) + '</span></div>' +
        '</div>';
        
        if (totalDiff !== 0) {
            noteInput.required = true;
            noteInput.style.borderColor = 'var(--danger)';
            const noteLabel = noteInput.parentElement.querySelector('label');
            noteLabel.innerHTML = '📝 ملاحظة <span class="req">*</span> (إجبارية — يوجد فرق)';
            const reason = totalDiff > 0 ? 'زيادة' : 'عجز';
            const color = totalDiff > 0 ? 'info' : 'danger';
            warningContainer.innerHTML = '<div class="shift-warning ' + color + '" style="margin-top: 15px;"><i class="fa-solid fa-triangle-exclamation"></i><div><strong>تنبيه:</strong> يوجد ' + reason + ' بقيمة <strong>' + fmt(Math.abs(totalDiff)) + '</strong>. يرجى كتابة السبب في الملاحظة قبل التقفيل.</div></div>';
        } else {
            noteInput.required = false;
            noteInput.style.borderColor = 'var(--border)';
            const noteLabel = noteInput.parentElement.querySelector('label');
            noteLabel.innerHTML = '📝 ملاحظة (اختياري)';
            warningContainer.innerHTML = '<div class="shift-warning info" style="margin-top: 15px;"><i class="fa-solid fa-circle-check"></i><div>الأرقام مطابقة تماماً ✨ يمكنك المتابعة بأمان.</div></div>';
        }
    };
    
    window.closeCloseShiftModal = function() {
        document.getElementById('closeShiftModal').classList.remove('show');
    };
    
    window.confirmCloseShift = function() {
        if (!currentShift) return;
        const actualCash = parseFloat(document.getElementById('closeActualCash').value) || 0;
        const actualWallets = parseFloat(document.getElementById('closeActualWallets').value) || 0;
        const note = document.getElementById('closeShiftNote').value.trim();
        const stats = computeShiftStats(currentShift.id);
        const openingFloat = currentShift.openingFloat || 0;
        const expectedCash = openingFloat + stats.cash;
        const expectedWallets = stats.wallets;
        const cashDiff = actualCash - expectedCash;
        const walletsDiff = actualWallets - expectedWallets;
        const totalDiff = cashDiff + walletsDiff;
        
        if (totalDiff !== 0 && !note) { showToast('يجب كتابة سبب الفرق قبل التقفيل', 'error'); document.getElementById('closeShiftNote').focus(); return; }
        if (stats.invoices === 0 && !confirm('لم تُسجَّل أي فواتير. هل تريد التقفيل؟')) return;
        
        const shiftRecord = {
            ...currentShift,
            closedAt: new Date().toISOString(),
            status: 'closed',
            expected: { cash: expectedCash, wallets: expectedWallets, openingFloat: openingFloat, returns: stats.returns, invoices: stats.invoices, items: stats.items },
            actual: { cash: actualCash, wallets: actualWallets },
            difference: { cash: cashDiff, wallets: walletsDiff, total: totalDiff },
            breakdown: stats.breakdown,
            note: note,
            closedBy: currentUser.name
        };
        
        let shifts = getShiftsRegistry();
        const idx = shifts.findIndex(s => s.id === currentShift.id);
        if (idx > -1) shifts[idx] = shiftRecord; else shifts.push(shiftRecord);
        saveShiftsRegistry(shifts);
        clearOpenShiftId(currentUser.id);
        lastClosedShift = shiftRecord;
        document.getElementById('closeShiftModal').classList.remove('show');
        if (shiftTimerInterval) { clearInterval(shiftTimerInterval); shiftTimerInterval = null; }
        currentShift = null;
        showShiftClosedSuccess(shiftRecord);
    };
    
    function showShiftClosedSuccess(shift) {
        const diffTotal = shift.difference.total;
        let diffText = '', diffColor = 'var(--success)', diffIcon = 'fa-circle-check';
        if (diffTotal === 0) { diffText = 'مطابق تماماً'; }
        else if (diffTotal > 0) { diffText = 'زيادة ' + fmt(Math.abs(diffTotal)); diffColor = 'var(--blue)'; diffIcon = 'fa-arrow-up'; }
        else { diffText = 'عجز ' + fmt(Math.abs(diffTotal)); diffColor = 'var(--danger)'; diffIcon = 'fa-arrow-down'; }
        
        const duration = formatDuration(new Date(shift.closedAt).getTime() - new Date(shift.openedAt).getTime());
        document.getElementById('shiftClosedSubtitle').textContent = 'الوردية #' + shift.id.split('-').pop() + ' — ' + shift.cashierName;
        document.getElementById('shiftClosedDetails').innerHTML = 
            '<div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed var(--border);"><span style="font-size: 12px; color: var(--muted); font-weight: 700;">⏱ المدة</span><span style="font-size: 13px; font-weight: 800;">' + duration + '</span></div>' +
            '<div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed var(--border);"><span style="font-size: 12px; color: var(--muted); font-weight: 700;">🧾 الفواتير</span><span style="font-size: 13px; font-weight: 800;">' + shift.expected.invoices + '</span></div>' +
            '<div style="display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed var(--border);"><span style="font-size: 12px; color: var(--muted); font-weight: 700;">💰 إجمالي المبيعات</span><span style="font-size: 13px; font-weight: 800;">' + fmt(shift.breakdown ? Object.values(shift.breakdown).reduce((s, b) => s + b.net, 0) : 0) + '</span></div>' +
            '<div style="display: flex; justify-content: space-between; padding: 10px 0 0;"><span style="font-size: 13px; font-weight: 800; color: ' + diffColor + ';"><i class="fa-solid ' + diffIcon + '"></i> الفرق</span><span style="font-size: 14px; font-weight: 900; color: ' + diffColor + ';">' + diffText + '</span></div>';
        
        document.getElementById('shiftClosedModal').classList.add('show');
    }
    
    window.logoutAfterClose = function() {
        document.getElementById('shiftClosedModal').classList.remove('show');
        window.logout(true);
    };
    
    window.printShiftReceipt = function() {
        if (!lastClosedShift) return;
        const shift = lastClosedShift;
        const duration = formatDuration(new Date(shift.closedAt).getTime() - new Date(shift.openedAt).getTime());
        const openedAtStr = new Date(shift.openedAt).toLocaleString('ar-EG');
        const closedAtStr = new Date(shift.closedAt).toLocaleString('ar-EG');
        const netTotal = shift.breakdown ? Object.values(shift.breakdown).reduce((s, b) => s + b.net, 0) : 0;
        const diffTotal = shift.difference.total;
        const diffClass = diffTotal === 0 ? '' : (diffTotal > 0 ? 'positive' : 'negative');
        
        const breakdownRows = Object.entries(shift.breakdown || {}).map(([method, data]) => 
            '<div class="shift-receipt-row"><span>' + method + ' (' + (data.count || 0) + ')</span><span>' + fmt(data.net) + '</span></div>'
        ).join('');
        
        document.getElementById('shift-receipt-area').innerHTML = 
            '<div class="shift-receipt-header"><h2>بوتيك مقليس</h2><div class="meta">صنعاء - شارع حدة | 777 000 000</div><div class="meta" style="margin-top: 8px; font-weight: 900; font-size: 13px;">إيصال تقفيل وردية</div></div>' +
            '<div class="shift-receipt-info">' +
                '<div class="row"><span>رقم الوردية:</span><strong>#' + shift.id.split('-').pop() + '</strong></div>' +
                '<div class="row"><span>الكاشير:</span><strong>' + shift.cashierName + '</strong></div>' +
                '<div class="row"><span>وقت الفتح:</span><span>' + openedAtStr + '</span></div>' +
                '<div class="row"><span>وقت الإغلاق:</span><span>' + closedAtStr + '</span></div>' +
                '<div class="row"><span>المدة:</span><strong>' + duration + '</strong></div>' +
            '</div>' +
            '<div class="shift-receipt-section"><h4>📊 تفصيل المبيعات</h4>' +
                '<div class="shift-receipt-row"><span>عدد الفواتير</span><strong>' + shift.expected.invoices + '</strong></div>' +
                '<div class="shift-receipt-row"><span>عدد القطع</span><strong>' + shift.expected.items + '</strong></div>' +
                '<div class="shift-receipt-row"><span>المرتجعات</span><strong>' + fmt(shift.expected.returns) + '</strong></div>' +
                breakdownRows +
                '<div class="shift-receipt-row total"><span>الصافي</span><span>' + fmt(netTotal) + '</span></div>' +
            '</div>' +
            '<div class="shift-receipt-section"><h4>💰 النقدية</h4>' +
                '<div class="shift-receipt-row"><span>العهدة الابتدائية</span><span>' + fmt(shift.expected.openingFloat) + '</span></div>' +
                '<div class="shift-receipt-row"><span>المتوقع في الدرج</span><span>' + fmt(shift.expected.cash) + '</span></div>' +
                '<div class="shift-receipt-row"><span>الفعلي في الدرج</span><span>' + fmt(shift.actual.cash) + '</span></div>' +
                '<div class="shift-receipt-row diff-row ' + diffClass + '"><span>الفرق</span><span>' + (diffTotal >= 0 ? '+' : '-') + fmt(Math.abs(diffTotal)) + '</span></div>' +
            '</div>' +
            (shift.note ? '<div class="shift-receipt-info" style="background: #FEF3C7; border: 1px solid #FDE68A;"><div class="row"><span style="color: #92400E; font-weight: 900;">📝 ملاحظة:</span></div><div style="font-size: 11px; color: #78350F; margin-top: 4px;">' + shift.note + '</div></div>' : '') +
            '<div class="shift-receipt-signature"><div>توقيع الكاشير</div><div>توقيع المدير</div></div>' +
            '<div class="shift-receipt-footer"><p>بوتيك مقليس - نظام الكاشير</p><p style="font-size: 10px; margin-top: 3px;">' + closedAtStr + '</p></div>';
        
        setTimeout(() => window.print(), 200);
    };
    
    /* ============================================================
       LOGIN / LOGOUT
       ============================================================ */
    window.login = function() {
        const user = document.getElementById('loginUser').value.trim();
        const pass = document.getElementById('loginPass').value.trim();
        const users = JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS)) || [];
        const found = users.find(u => u.username === user && u.password === pass);
        if (!found) { document.getElementById('loginError').style.display = 'block'; return; }
        if (found.role !== 'cashier' && found.role !== 'admin') { alert('هذا الحساب ليس حساب كاشير'); return; }
        currentUser = found;
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(found));
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('app-container').style.display = 'flex';
        const existingShift = getCurrentShiftFromStorage();
        if (existingShift) { currentShift = existingShift; initApp(); showToast('🔄 تم استئناف ورديتك المفتوحة'); }
        else { initApp(); window.openOpenShiftModal(); }
    };
    
    window.logout = function(force) {
        if (currentShift && !force) {
            const confirmLogout = confirm('⚠️ لديك وردية مفتوحة!\n\nيجب تقفيل الوردية قبل الخروج لضمان محاسبة دقيقة.\n\nهل تريد تقفيل الوردية الآن؟');
            if (confirmLogout) { window.openCloseShiftModal(); return; }
            if (!confirm('تحذير: الخروج بدون تقفيل الوردية سيبقيها مفتوحة.\n\nهل أنت متأكد؟')) return;
        }
        if (cart.length > 0 && !force && !confirm('لديك منتجات في السلة. هل تريد الخروج؟')) return;
        if (currentUser) {
            localStorage.removeItem(STORAGE_KEYS.CART_PREFIX + currentUser.id);
            localStorage.removeItem(STORAGE_KEYS.BASKETS_PREFIX + currentUser.id);
        }
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
        document.getElementById('app-container').style.display = 'none';
        document.getElementById('login-screen').style.display = 'flex';
        document.getElementById('loginPass').value = '';
        document.getElementById('loginError').style.display = 'none';
        if (readyOrdersInterval) { clearInterval(readyOrdersInterval); readyOrdersInterval = null; }
        if (clockInterval) { clearInterval(clockInterval); clockInterval = null; }
        if (shiftTimerInterval) { clearInterval(shiftTimerInterval); shiftTimerInterval = null; }
        window.stopScanner();
        cart = []; customerBaskets = []; activeBasketId = null; currentShift = null;
        updateCartUI();
        pendingReadyOrder = null; currentUser = null;
    };
    
    window.onload = function() {
        const saved = JSON.parse(localStorage.getItem(STORAGE_KEYS.CURRENT_USER));
        if (saved) {
            currentUser = saved;
            document.getElementById('login-screen').style.display = 'none';
            document.getElementById('app-container').style.display = 'flex';
            const existingShift = getCurrentShiftFromStorage();
            if (existingShift) { currentShift = existingShift; initApp(); }
            else { initApp(); window.openOpenShiftModal(); }
        }
    };
    
    /* ============================================================
       APPLY ROLE
       ============================================================ */
    function applyRole() {
        const isMain = !currentUser.permissions || currentUser.permissions.canReceivePayment !== false;
        window.CAN_RECEIVE_PAYMENT = isMain;
        const payBtn = document.getElementById('payBtn');
        const sendBtn = document.getElementById('sendToMainBtn');
        const readyBtn = document.getElementById('readyOrdersBtn');
        const returnsBtn = document.getElementById('returnsNavBtn');
        const userBadge = document.getElementById('userBadge');
        const warehouseBtn = document.getElementById('warehouseBtn');
        const manualTabBtn = document.getElementById('tab-manual-btn');
        const subBasketsUI = document.getElementById('subCashierBasketsUI');
        
        if (isMain) {
            payBtn.style.display = 'flex';
            sendBtn.style.display = 'none';
            returnsBtn.style.display = 'flex';
            if (warehouseBtn) warehouseBtn.style.display = 'flex';
            subBasketsUI.style.display = 'none';
            userBadge.innerHTML = '<i class="fa-solid fa-cash-register" style="color:var(--gold);"></i> <span style="color:var(--gold);">صندوق رئيسي — ' + currentUser.name + '</span>';
        } else {
            payBtn.style.display = 'none';
            sendBtn.style.display = 'flex';
            returnsBtn.style.display = 'none';
            readyBtn.style.display = 'none';
            if (warehouseBtn) warehouseBtn.style.display = 'none';
            subBasketsUI.style.display = 'block';
            userBadge.innerHTML = '<i class="fa-solid fa-user-tag" style="color:var(--blue);"></i> <span style="color:var(--blue);">كاشير فرعي — ' + currentUser.name + '</span>';
            const savedBaskets = localStorage.getItem(STORAGE_KEYS.BASKETS_PREFIX + currentUser.id);
            if (savedBaskets) {
                customerBaskets = JSON.parse(savedBaskets);
                if (customerBaskets.length > 0) { activeBasketId = customerBaskets[0].id; cart = customerBaskets[0].items; }
            }
            renderSubCashierBaskets();
        }
        const perms = currentUser.permissions || {};
        if (perms.useBarcode === false) { document.getElementById('scanBtn').style.display = 'none'; document.getElementById('barcodeInput').placeholder = 'ابحث بالاسم فقط...'; }
        if (perms.allowReturn === false) { returnsBtn.style.display = 'none'; }
        if (perms.allowManualReturn === false && manualTabBtn) { manualTabBtn.style.display = 'none'; }
    }
    
    function saveSubBaskets() {
        if (currentUser && currentUser.permissions?.canReceivePayment === false) {
            localStorage.setItem(STORAGE_KEYS.BASKETS_PREFIX + currentUser.id, JSON.stringify(customerBaskets));
        }
    }
    
    window.createNewBasket = function() {
        if (activeBasketId) { const oldBasket = customerBaskets.find(b => b.id === activeBasketId); if (oldBasket) oldBasket.items = [...cart]; }
        const newId = Math.floor(Math.random() * 900) + 100;
        customerBaskets.push({ id: newId, items: [] });
        activeBasketId = newId;
        cart = customerBaskets.find(b => b.id === newId).items;
        saveSubBaskets(); renderSubCashierBaskets(); updateCartUI();
        playBeep('success'); showToast('تم إنشاء سلة للزبونة #' + newId);
    };
    
    window.switchBasket = function(id) {
        if (activeBasketId) { const oldBasket = customerBaskets.find(b => b.id === activeBasketId); if (oldBasket) oldBasket.items = [...cart]; }
        activeBasketId = id;
        cart = customerBaskets.find(b => b.id === id).items;
        saveSubBaskets(); renderSubCashierBaskets(); updateCartUI();
    };
    
    function renderSubCashierBaskets() {
        if (!currentUser || currentUser.permissions?.canReceivePayment !== false) return;
        const container = document.getElementById('subBasketsList');
        if (!container) return;
        if (customerBaskets.length === 0) { container.innerHTML = '<div style="text-align:center; width:100%; color:var(--muted); font-size:12px; padding:10px;">لا توجد سلال. اضغط "زبونة جديدة" للبدء.</div>'; return; }
        container.innerHTML = customerBaskets.map(b => {
            const qty = b.id === activeBasketId ? cart.reduce((s,i)=>s+i.qty,0) : b.items.reduce((s,i)=>s+i.qty,0);
            return '<div class="sub-basket-tab ' + (activeBasketId === b.id ? 'active' : '') + '" onclick="window.switchBasket(' + b.id + ')"><i class="fa-solid fa-user"></i> زبونة #' + b.id + ' <span class="badge">' + qty + '</span></div>';
        }).join('');
    }
    
    function renderCategoryBar() {
        const bar = document.getElementById('categoryBar');
        if (!bar) return;
        const cats = [{ key: 'all', label: '📦 الكل' }, ...Object.keys(CATEGORIES_MAP).map(k => ({ key: CATEGORIES_MAP[k].key, label: CATEGORIES_MAP[k].icon + ' ' + k }))];
        bar.innerHTML = cats.map(c => '<button class="cat-btn ' + (currentFilters.cat === c.key ? 'active' : '') + '" onclick="window.setCatFilter(\'' + c.key + '\')">' + c.label + '</button>').join('');
    }
    
    function renderSubcategoryBar() {
        const row = document.getElementById('subcategoryRow');
        const bar = document.getElementById('subcategoryBar');
        if (!row || !bar) return;
        if (currentFilters.cat === 'all') { row.style.display = 'none'; return; }
        const catArabic = Object.keys(CATEGORIES_MAP).find(k => CATEGORIES_MAP[k].key === currentFilters.cat);
        if (!catArabic) { row.style.display = 'none'; return; }
        const subs = CATEGORIES_MAP[catArabic].sub;
        row.style.display = 'flex';
        bar.innerHTML = '<button class="subcat-btn ' + (currentFilters.subcat === 'all' ? 'active' : '') + '" onclick="window.setSubcatFilter(\'all\')">الكل</button>' + subs.map(s => '<button class="subcat-btn ' + (currentFilters.subcat === s ? 'active' : '') + '" onclick="window.setSubcatFilter(\'' + s + '\')">' + s + '</button>').join('');
    }
    
    window.setCatFilter = function(key) { currentFilters.cat = key; currentFilters.subcat = 'all'; renderCategoryBar(); renderSubcategoryBar(); filterAndRender(); };
    window.setSubcatFilter = function(sub) { currentFilters.subcat = sub; renderSubcategoryBar(); filterAndRender(); };
    window.setDateFilter = function(date, btn) {
        currentFilters.date = date;
        document.querySelectorAll('.date-btn').forEach(b => b.classList.remove('active'));
        if (btn) btn.classList.add('active');
        filterAndRender();
    };
    window.handleSearch = function(val) { currentFilters.search = val.trim(); filterAndRender(); };
    
    function loadProducts() {
        rawProducts = JSON.parse(localStorage.getItem(STORAGE_KEYS.INVENTORY)) || [];
        let updated = false;
        rawProducts.forEach(p => { if (p.reserved === undefined) { p.reserved = 0; updated = true; } if (p.qty === undefined) { p.qty = 0; updated = true; } });
        if (updated) localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(rawProducts));
        const grouped = {};
        rawProducts.forEach(p => { if (!grouped[p.name]) grouped[p.name] = { name: p.name, image: p.image, price: p.price, mainCategory: p.mainCategory, subCategory: p.subCategory, variants: [] }; grouped[p.name].variants.push(p); });
        products = Object.values(grouped);
        filterAndRender();
    }
    
    function filterAndRender() {
        let filtered = products.filter(p => {
            if (currentFilters.cat !== 'all') { const catArabic = Object.keys(CATEGORIES_MAP).find(k => CATEGORIES_MAP[k].key === currentFilters.cat); if (p.mainCategory !== catArabic) return false; }
            if (currentFilters.subcat !== 'all') { if (p.subCategory !== currentFilters.subcat) return false; }
            if (currentFilters.date !== 'all') {
                const added = p.variants[0].dateAdded ? new Date(p.variants[0].dateAdded) : new Date(0);
                const now = new Date();
                if (currentFilters.date === 'today') { if (added < new Date(now.getFullYear(), now.getMonth(), now.getDate())) return false; }
                else if (currentFilters.date === 'week') { const start = new Date(now); start.setDate(start.getDate() - 7); if (added < start) return false; }
                else if (currentFilters.date === 'month') { if (added < new Date(now.getFullYear(), now.getMonth(), 1)) return false; }
            }
            if (currentFilters.search) { const q = currentFilters.search.toLowerCase(); if (!p.name.toLowerCase().includes(q)) return false; }
            return true;
        });
        filtered.sort((a, b) => {
            const da = a.variants[0].dateAdded ? new Date(a.variants[0].dateAdded).getTime() : 0;
            const db = b.variants[0].dateAdded ? new Date(b.variants[0].dateAdded).getTime() : 0;
            return db - da;
        });
        renderProducts(filtered);
    }
    
    function renderProducts(list) {
        const grid = document.getElementById('productsGrid');
        grid.innerHTML = '';
        if (list.length === 0) { grid.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:50px; color:var(--muted);"><i class="fa-solid fa-box-open" style="font-size:40px; margin-bottom:10px; opacity:0.3;"></i><br>لا توجد منتجات مطابقة</div>'; return; }
        list.forEach(g => {
            const totalQty = g.variants.reduce((sum, v) => sum + (v.qty || 0), 0);
            const totalReserved = g.variants.reduce((sum, v) => sum + (v.reserved || 0), 0);
            const totalAvailable = Math.max(0, totalQty - totalReserved);
            const isOutOfStock = totalQty === 0;
            const isFullyReserved = totalAvailable === 0 && totalQty > 0;
            const card = document.createElement('div');
            card.className = 'product-card';
            if (isOutOfStock) { card.style.opacity = '0.5'; card.style.cursor = 'not-allowed'; card.onclick = () => { playBeep('error'); showToast('هذا المنتج نفد', 'error'); }; }
            else if (isFullyReserved) { card.style.opacity = '0.85'; card.style.borderColor = 'var(--warning)'; card.onclick = () => { playBeep('error'); showToast('محجوز بالكامل', 'error'); }; }
            else { card.onclick = () => openVariantModal(g.name); }
            card.innerHTML = '<img src="' + (g.image || 'https://via.placeholder.com/150') + '" alt="' + g.name + '" onerror="this.src=\'https://via.placeholder.com/150\'"><h4>' + g.name + '</h4><div style="font-size:11px; color:var(--muted); margin-bottom:4px;"><i class="fa-solid fa-palette"></i> ' + g.variants.length + ' خيارات</div><div class="price">' + g.price.toLocaleString() + ' ر.ي</div><div class="stock-info" style="display:flex; flex-direction:column; gap:4px; margin-top:8px;"><div class="stock-row available"><span>المتاح:</span><strong>' + totalAvailable + '</strong></div>' + (totalReserved > 0 ? '<div class="stock-row reserved"><span>محجوز:</span><strong>' + totalReserved + '</strong></div>' : '') + '</div>';
            grid.appendChild(card);
        });
    }
    
    let selectedVariantGroup = null, selectedColor = null, selectedSize = null;
    function openVariantModal(groupName) {
        const group = products.find(p => p.name === groupName);
        if (!group) return;
        selectedVariantGroup = group; selectedColor = null; selectedSize = null;
        document.getElementById('vTitle').textContent = group.name;
        document.getElementById('vImage').src = group.image || 'https://via.placeholder.com/150';
        document.getElementById('vPrice').textContent = group.price.toLocaleString() + ' ر.ي';
        const availableVariants = group.variants.filter(v => Math.max(0, v.qty - (v.reserved || 0)) > 0);
        const totalAvail = availableVariants.reduce((sum, v) => sum + Math.max(0, v.qty - (v.reserved || 0)), 0);
        document.getElementById('vAvailable').textContent = 'المتاح للبيع: ' + totalAvail + ' قطعة';
        const colors = [...new Set(availableVariants.map(v => v.color))];
        document.getElementById('vColors').innerHTML = colors.map(c => '<button class="cat-btn" onclick="window.selectVariantColor(\'' + c + '\', this)" style="padding:6px 12px;">' + c + '</button>').join('');
        document.getElementById('vSizes').innerHTML = '<div style="color:var(--muted); font-size:12px;">الرجاء اختيار اللون أولاً</div>';
        document.getElementById('variantModal').classList.add('show');
    }
    
    window.selectVariantColor = function(color, btn) {
        selectedColor = color; selectedSize = null;
        document.querySelectorAll('#vColors .cat-btn').forEach(b => b.classList.remove('active')); btn.classList.add('active');
        const variantsForColor = selectedVariantGroup.variants.filter(v => v.color === color);
        document.getElementById('vSizes').innerHTML = variantsForColor.map(v => {
            const vQty = v.qty || 0; const vRes = v.reserved || 0; const vAvailable = Math.max(0, vQty - vRes);
            let label = v.size;
            if (vAvailable <= 0 && vQty > 0) label += ' (محجوز)';
            else if (vAvailable <= 0 && vQty === 0) label += ' (نفد)';
            const disabled = vAvailable <= 0 ? 'disabled' : '';
            const style = vAvailable <= 0 ? 'opacity:0.4; cursor:not-allowed; background:#eee;' : 'padding:6px 12px;';
            const onclick = vAvailable > 0 ? 'onclick="window.selectVariantSize(\'' + v.size + '\', this)"' : '';
            return '<button class="cat-btn" ' + onclick + ' ' + disabled + ' style="' + style + '">' + label + '</button>';
        }).join('');
    };
    
    window.selectVariantSize = function(size, btn) { selectedSize = size; document.querySelectorAll('#vSizes .cat-btn').forEach(b => b.classList.remove('active')); btn.classList.add('active'); };
    window.addVariantToCart = function() {
        if (!selectedColor) { showToast('اختر اللون', 'error'); return; }
        if (!selectedSize) { showToast('اختر المقاس', 'error'); return; }
        const variant = selectedVariantGroup.variants.find(v => v.color === selectedColor && v.size === selectedSize);
        if (variant) { addToCart(variant.sku); window.closeVariantModal(); }
    };
    window.closeVariantModal = function() { document.getElementById('variantModal').classList.remove('show'); };
    
    document.getElementById('barcodeInput').addEventListener('keypress', function(e) {
        if (e.key !== 'Enter') return;
        const val = this.value.trim();
        if (!val) return;
        const product = rawProducts.find(p => p.sku === val);
        if (product) { addToCart(product.sku); this.value = ''; }
        else { playBeep('error'); showToast('الباركود غير موجود', 'error'); }
    });
    
    function addToCart(sku) {
        const product = rawProducts.find(p => p.sku === sku);
        if (!product) return;
        if (currentUser.permissions?.canReceivePayment === false && !activeBasketId) { window.createNewBasket(); }
        const existingItem = cart.find(item => item.sku === sku);
        const currentQtyInCart = existingItem ? existingItem.qty : 0;
        const available = Math.max(0, product.qty - (product.reserved || 0));
        if (currentQtyInCart + 1 > available) { playBeep('error'); showToast('الكمية المتاحة فقط ' + available + ' قطعة', 'error'); return; }
        if (existingItem) existingItem.qty++;
        else cart.push({ ...product, qty: 1, discount: 0 });
        playBeep('success'); showToast('تم إضافة ' + product.name); updateCartUI();
        document.getElementById('cartSection').classList.add('flash');
        setTimeout(() => document.getElementById('cartSection').classList.remove('flash'), 300);
    }
    
    window.updateQty = function(sku, change) {
        const item = cart.find(i => i.sku === sku);
        if (!item) return;
        if (change > 0) { const product = rawProducts.find(p => p.sku === sku); const available = Math.max(0, product.qty - (product.reserved || 0)); if (item.qty + 1 > available) { playBeep('error'); showToast('الحد الأقصى: ' + available, 'error'); return; } }
        item.qty += change;
        if (item.qty <= 0) cart = cart.filter(i => i.sku !== sku);
        updateCartUI();
    };
    
    window.applyDiscount = function(sku) {
        if (currentUser.permissions && currentUser.permissions.applyDiscount === false) { showToast('ليس لديك صلاحية', 'error'); return; }
        const item = cart.find(i => i.sku === sku);
        if (!item || !item.maxDiscount) { showToast('هذا المنتج لا يقبل الخصم', 'error'); return; }
        const input = prompt('أدخل نسبة الخصم (الحد الأقصى ' + item.maxDiscount + '%):', item.discount || 0);
        if (input === null) return;
        const discount = parseFloat(input);
        if (isNaN(discount) || discount < 0 || discount > item.maxDiscount) { showToast('الحد الأقصى: ' + item.maxDiscount + '%', 'error'); return; }
        item.discount = discount; updateCartUI(); showToast('تم تطبيق الخصم');
    };
    
    window.clearCart = function() {
        if (currentUser.permissions?.canReceivePayment === false) {
            if (!activeBasketId) return;
            if (!confirm('مسح منتجات هذه الزبونة؟')) return;
            cart = [];
            const basket = customerBaskets.find(b => b.id === activeBasketId);
            if (basket) basket.items = [];
            saveSubBaskets(); updateCartUI(); showToast('تم مسح السلة');
        } else {
            if (cart.length > 0 && !confirm('مسح السلة؟')) return;
            cart = []; updateCartUI(); showToast('تم مسح السلة');
        }
    };
    
    function updateCartUI() {
        const container = document.getElementById('cartItemsContainer');
        container.innerHTML = '';
        if (currentUser && currentUser.permissions?.canReceivePayment === false) { renderSubCashierBaskets(); saveSubBaskets(); }
        if (currentUser && currentUser.permissions?.canReceivePayment === false && !activeBasketId) {
            container.innerHTML = '<div class="empty-cart"><i class="fa-solid fa-users"></i><p>لم يتم اختيار زبونة</p><p style="font-size:12px; margin-top:10px;">اضغط "زبونة جديدة"</p></div>';
            ['cartCountBadge','mobileCartBadge'].forEach(id => document.getElementById(id).textContent = '0');
            ['subtotalDisplay','taxDisplay','totalDisplay'].forEach(id => document.getElementById(id).textContent = '0 ر.ي');
            return;
        }
        if (cart.length === 0) {
            container.innerHTML = '<div class="empty-cart"><i class="fa-solid fa-cart-shopping"></i><p>السلة فارغة</p></div>';
            ['cartCountBadge','mobileCartBadge'].forEach(id => document.getElementById(id).textContent = '0');
            ['subtotalDisplay','taxDisplay','totalDisplay'].forEach(id => document.getElementById(id).textContent = '0 ر.ي');
            return;
        }
        let totalQty = 0, subtotal = 0;
        cart.forEach(item => {
            totalQty += item.qty;
            const discountAmt = item.price * ((item.discount || 0) / 100);
            const finalPrice = item.price - discountAmt;
            subtotal += finalPrice * item.qty;
            const el = document.createElement('div');
            el.className = 'cart-item';
            el.innerHTML = '<img src="' + (item.image || 'https://via.placeholder.com/60') + '" onerror="this.src=\'https://via.placeholder.com/60\'"><div class="cart-item-info"><h4>' + item.name + '</h4><div style="font-size:11px; color:var(--muted); margin-bottom:2px;">' + (item.color || '') + ' | ' + (item.size || '') + '</div><div class="item-price">' + (item.discount > 0 ? '<del>' + item.price.toLocaleString() + '</del>' : '') + ' ' + finalPrice.toLocaleString() + ' ر.ي</div>' + (item.maxDiscount > 0 ? '<button class="discount-btn" onclick="window.applyDiscount(\'' + item.sku + '\')"><i class="fa-solid fa-tag"></i> خصم (' + (item.discount || 0) + '%)</button>' : '') + '</div><div class="qty-controls"><button class="qty-btn" onclick="window.updateQty(\'' + item.sku + '\', 1)"><i class="fa-solid fa-plus"></i></button><span class="qty-num">' + item.qty + '</span><button class="qty-btn" onclick="window.updateQty(\'' + item.sku + '\', -1)"><i class="fa-solid fa-minus"></i></button></div>';
            container.appendChild(el);
        });
        const tax = subtotal * TAX_RATE, total = subtotal + tax;
        document.getElementById('cartCountBadge').textContent = totalQty;
        document.getElementById('mobileCartBadge').textContent = totalQty;
        document.getElementById('subtotalDisplay').textContent = fmt(subtotal);
        document.getElementById('taxDisplay').textContent = fmt(tax);
        document.getElementById('totalDisplay').textContent = fmt(total);
        if (currentUser && currentUser.permissions?.canReceivePayment !== false) {
            localStorage.setItem(STORAGE_KEYS.CART_PREFIX + currentUser.id, JSON.stringify(cart));
        }
    }
    
    window.toggleMobileCart = function() { if (window.innerWidth <= 900) document.getElementById('cartSection').classList.toggle('open'); };
    
    window.startScanner = function() {
        if (currentUser.permissions && currentUser.permissions.useBarcode === false) { showToast('ليس لديك صلاحية', 'error'); return; }
        document.getElementById('scanner-modal').classList.add('show');
        if (typeof Html5Qrcode === 'undefined') { showToast('الماسح غير متاح', 'error'); document.getElementById('scanner-modal').classList.remove('show'); return; }
        if (!html5QrcodeScanner) html5QrcodeScanner = new Html5Qrcode('reader');
        html5QrcodeScanner.start({ facingMode: 'environment' }, { fps: 10, qrbox: { width: 280, height: 150 } },
            (decodedText) => { window.stopScanner(); const product = rawProducts.find(p => p.sku === decodedText); if (product) addToCart(product.sku); else { playBeep('error'); showToast('المنتج "' + decodedText + '" غير موجود', 'error'); } }, () => {}
        ).catch((err) => { console.error(err); showToast('فشل تشغيل الكاميرا', 'error'); window.stopScanner(); });
    };
    
    window.stopScanner = function() {
        if (html5QrcodeScanner && html5QrcodeScanner.isScanning) html5QrcodeScanner.stop().then(() => document.getElementById('scanner-modal').classList.remove('show')).catch(() => document.getElementById('scanner-modal').classList.remove('show'));
        else document.getElementById('scanner-modal').classList.remove('show');
    };
    
    window.openPaymentModal = function() {
        if (cart.length === 0) { playBeep('error'); showToast('السلة فارغة', 'error'); return; }
        if (!currentShift) { showToast('يجب فتح وردية أولاً', 'error'); return; }
        let subtotal = 0; cart.forEach(item => subtotal += (item.price - (item.price * ((item.discount || 0) / 100))) * item.qty);
        document.getElementById('paymentAmountDisplay').textContent = fmt(subtotal + subtotal * TAX_RATE);
        document.getElementById('paymentModal').classList.add('show');
    };
    
    window.closePaymentModal = function() {
        document.getElementById('paymentModal').classList.remove('show');
        if (pendingReadyOrder) { pendingReadyOrder = null; document.getElementById('warehouseBtn').style.display = 'flex'; }
    };
    
    /* ⭐ confirmPayment — مع تسجيل حركة البيع + تسجيل الحجز */
    window.confirmPayment = function(method) {
        if (pendingReadyOrder) { finalizeReadyOrder(method); return; }
        if (cart.length === 0) return;
        if (!currentShift) { showToast('يجب فتح وردية أولاً', 'error'); return; }
        window.closePaymentModal();
        
        let subtotal = 0; cart.forEach(item => subtotal += (item.price - (item.price * ((item.discount || 0) / 100))) * item.qty);
        const tax = subtotal * TAX_RATE, total = subtotal + tax;
        let inventory = JSON.parse(localStorage.getItem(STORAGE_KEYS.INVENTORY)) || [];
        let canProceed = true, missingItem = '';
        
        cart.forEach(ci => {
            const inv = inventory.find(i => i.sku === ci.sku);
            if ((inv ? Math.max(0, inv.qty - (inv.reserved || 0)) : 0) < ci.qty) { canProceed = false; missingItem = ci.name; }
        });
        if (!canProceed) { playBeep('error'); showToast('الكمية المتاحة للمنتج "' + missingItem + '" لم تعد تكفي', 'error'); cart = []; updateCartUI(); loadProducts(); return; }
        
        // ⭐⭐⭐ "طلب من المخزن" — حجز + تسجيل حركة reserve
        if (method === 'طلب من المخزن') {
            const reqId = 'REQ-' + Date.now();
            cart.forEach(ci => { 
                const inv = inventory.find(i => i.sku === ci.sku); 
                if (inv) {
                    logStockMovement(ci.sku, 'reserve', ci.qty, inv.qty, inv.qty, reqId, 'حجز لطلب مخزن');
                    inv.reserved = (inv.reserved || 0) + ci.qty;
                }
            });
            localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
            let orders = JSON.parse(localStorage.getItem(STORAGE_KEYS.PICKUP)) || [];
            orders.push({ id: reqId, date: new Date().toISOString(), cashier: currentUser.name, subCashier: null, mainCashier: currentUser.name, items: [...cart], status: 'pending', source: 'pos', paymentMethod: null, shiftId: currentShift.id });
            localStorage.setItem(STORAGE_KEYS.PICKUP, JSON.stringify(orders));
            playBeep('success'); showToast('📤 تم إرسال الطلب للمخزن'); 
            cart = []; updateCartUI(); loadProducts(); updateShiftBar();
            return;
        }
        
        // ⭐⭐⭐ البيع العادي — تسجيل حركة sale
        const saleId = 'INV-' + Date.now();
        cart.forEach(ci => { 
            const inv = inventory.find(i => i.sku === ci.sku); 
            if (inv) {
                const before = inv.qty;
                const after = Math.max(0, before - ci.qty);
                logStockMovement(ci.sku, 'sale', -ci.qty, before, after, saleId, method);
                inv.qty = after;
            }
        });
        localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
        
        let sales = JSON.parse(localStorage.getItem(STORAGE_KEYS.SALES)) || [];
        sales.push({ id: saleId, date: new Date().toISOString(), cashier: currentUser.name, subCashier: null, mainCashier: currentUser.name, items: [...cart], subtotal, tax, total, paymentMethod: method, source: 'pos', shiftId: currentShift.id });
        localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
        
        prepareReceipt({ items: cart, total: total, method: method, id: saleId, isPreview: false });
        document.getElementById('successMessage').textContent = 'تم خصم الكميات من المخزون';
        document.getElementById('successModal').classList.add('show');
        if (window.innerWidth <= 900) document.getElementById('cartSection').classList.remove('open');
        cart = []; updateCartUI(); loadProducts(); playBeep('success');
        updateShiftBar();
    };
    
    /* ⭐ sendToMainCashier — مع تسجيل حركة reserve */
    window.sendToMainCashier = function() {
        if (!activeBasketId) { playBeep('error'); showToast('الرجاء اختيار سلة أولاً', 'error'); return; }
        if (cart.length === 0) { playBeep('error'); showToast('السلة فارغة', 'error'); return; }
        if (!currentShift) { showToast('يجب فتح وردية أولاً', 'error'); return; }
        
        let inventory = JSON.parse(localStorage.getItem(STORAGE_KEYS.INVENTORY)) || [];
        let canProceed = true, missingItem = '';
        cart.forEach(ci => { const inv = inventory.find(i => i.sku === ci.sku); if ((inv ? Math.max(0, inv.qty - (inv.reserved || 0)) : 0) < ci.qty) { canProceed = false; missingItem = ci.name; } });
        if (!canProceed) { playBeep('error'); showToast('الكمية المتاحة للمنتج "' + missingItem + '" لم تعد تكفي', 'error'); return; }
        
        const orderId = 'REQ-' + Date.now();
        cart.forEach(ci => { 
            const inv = inventory.find(i => i.sku === ci.sku); 
            if (inv) {
                logStockMovement(ci.sku, 'reserve', ci.qty, inv.qty, inv.qty, orderId, 'حجز من كاشير فرعي #' + activeBasketId);
                inv.reserved = (inv.reserved || 0) + ci.qty;
            }
        });
        localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
        
        let orders = JSON.parse(localStorage.getItem(STORAGE_KEYS.PICKUP)) || [];
        orders.push({ id: orderId, date: new Date().toISOString(), cashier: currentUser.name, subCashier: currentUser.name, customerNo: activeBasketId, mainCashier: null, items: [...cart], status: 'pending', source: 'pos', paymentMethod: null, shiftId: currentShift.id });
        localStorage.setItem(STORAGE_KEYS.PICKUP, JSON.stringify(orders));
        
        let subtotal = 0; cart.forEach(item => subtotal += (item.price - (item.price * ((item.discount || 0) / 100))) * item.qty);
        const total = subtotal + subtotal * TAX_RATE;
        window.__previewReceiptData = { items: [...cart], total: total, orderId: orderId, customerNo: activeBasketId };
        
        document.getElementById('previewOrderId').textContent = orderId + ' (زبونة #' + activeBasketId + ')';
        document.getElementById('previewTotalAmount').textContent = fmt(total);
        document.getElementById('previewReceiptModal').classList.add('show');
        playBeep('success');
        
        customerBaskets = customerBaskets.filter(b => b.id !== activeBasketId);
        if (customerBaskets.length > 0) { activeBasketId = customerBaskets[0].id; cart = customerBaskets[0].items; }
        else { activeBasketId = null; cart = []; }
        saveSubBaskets(); renderSubCashierBaskets(); updateCartUI(); loadProducts(); updateShiftBar();
    };
    
    window.closePreviewReceipt = function() { document.getElementById('previewReceiptModal').classList.remove('show'); };
    window.printPreviewReceipt = function() {
        if (currentUser.permissions && currentUser.permissions.printReceipt === false) { showToast('ليس لديك صلاحية', 'error'); return; }
        const data = window.__previewReceiptData; if (!data) return;
        prepareReceipt({ items: data.items, total: data.total, method: 'غير مدفوع (طلب مبدئي)', id: data.orderId, customerNo: data.customerNo, isPreview: true });
        setTimeout(() => window.print(), 200);
    };
    
    function checkReadyOrders() {
        if (!window.CAN_RECEIVE_PAYMENT) return;
        const orders = JSON.parse(localStorage.getItem(STORAGE_KEYS.PICKUP)) || [];
        const activeOrders = orders.filter(o => o.status === 'pending' || o.status === 'ready');
        const newOrders = activeOrders.filter(o => !knownReadyOrders.includes(o.id));
        if (newOrders.length > 0) {
            playBeep('success'); setTimeout(() => playBeep('success'), 350);
            showToast('🔔 ' + newOrders.length + ' طلب جديد', 'success');
            newOrders.forEach(o => { if (!knownReadyOrders.includes(o.id)) knownReadyOrders.push(o.id); });
            localStorage.setItem(STORAGE_KEYS.KNOWN_READY, JSON.stringify(knownReadyOrders));
        }
        const btn = document.getElementById('readyOrdersBtn'), count = document.getElementById('readyOrdersCount');
        if (btn && count) { if (activeOrders.length > 0) { btn.style.display = 'flex'; count.textContent = activeOrders.length; } else { btn.style.display = 'none'; } }
    }
    
    window.openReadyOrdersModal = function() {
        const orders = JSON.parse(localStorage.getItem(STORAGE_KEYS.PICKUP)) || [];
        const activeOrders = orders.filter(o => o.status === 'pending' || o.status === 'ready');
        renderReadyOrdersList(activeOrders);
        document.getElementById('readyOrdersModal').classList.add('show');
    };
    window.closeReadyOrdersModal = function() { document.getElementById('readyOrdersModal').classList.remove('show'); };
    
    function renderReadyOrdersList(orders) {
        const list = document.getElementById('readyOrdersList');
        if (orders.length === 0) { list.innerHTML = '<div style="text-align:center; padding:40px 20px; color:var(--muted);"><i class="fa-solid fa-bell-slash" style="font-size:50px; color:#E2E8F0; margin-bottom:15px; display:block;"></i><p>لا توجد طلبات حالياً</p></div>'; return; }
        list.innerHTML = [...orders].sort((a, b) => new Date(b.date) - new Date(a.date)).map(o => {
            const isOnline = o.source === 'online';
            const isReady = o.status === 'ready';
            const customerNoStr = o.customerNo ? '<span style="background:#F59E0B; color:white; padding:2px 8px; border-radius:6px; font-size:11px; font-weight:bold; margin-right:5px;"><i class="fa-solid fa-user"></i> #' + o.customerNo + '</span>' : '';
            const statusBadge = isReady ? '<span style="background:#DEF7EC; color:#059669; padding:2px 8px; border-radius:6px; font-size:11px; font-weight:bold;">✅ جاهز</span>' : '<span style="background:#FEF3C7; color:#D97706; padding:2px 8px; border-radius:6px; font-size:11px; font-weight:bold;">⏳ قيد التجهيز</span>';
            let itemsHtml = '', subtotal = 0;
            o.items.forEach(item => { subtotal += (item.price - (item.price * ((item.discount || 0) / 100))) * item.qty; itemsHtml += '<p>• ' + item.name + ' <span style="color:var(--muted);">(' + (item.color || '') + ' - ' + (item.size || '') + ')</span> × ' + item.qty + '</p>'; });
            const total = subtotal + subtotal * TAX_RATE;
            return '<div class="ready-order-card ' + (isOnline ? 'online-order' : 'pos-order') + '">' +
                '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;"><div><span class="ready-order-source-badge ' + (isOnline ? 'online' : 'pos') + '">' + (isOnline ? '🌐 أونلاين' : '💳 كاشير') + '</span><strong style="font-size:14px;">طلب #' + o.id.split('-').pop() + '</strong>' + customerNoStr + '</div><div>' + statusBadge + '</div></div>' +
                '<div style="background:#DBEAFE; padding:6px 10px; border-radius:6px; font-size:12px; font-weight:700; color:#1E40AF; margin-bottom:8px;"><i class="fa-solid fa-user-tag"></i> من: ' + (o.subCashier || o.cashier) + '</div>' +
                '<div class="ready-order-items">' + itemsHtml + '</div>' +
                '<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; padding: 8px 10px; background: white; border-radius: 8px;"><span style="font-size:13px; font-weight:700;">الإجمالي:</span><span style="font-size:16px; font-weight:900; color:var(--gold);">' + total.toLocaleString() + ' ر.ي</span></div>' +
                '<div class="ready-order-actions">' +
                    (isOnline ? '<button class="btn-deliver-order" onclick="window.deliverOnlineOrder(\'' + o.id + '\')">✅ تسليم</button>' : (isReady ? '<button class="btn-complete-sale" onclick="window.completePosOrder(\'' + o.id + '\')">💵 إتمام البيع</button>' : '<button class="btn-complete-sale" style="background:#ccc; color:#666; cursor:not-allowed;" disabled>بانتظار المخزن...</button>')) +
                    '<button class="btn-cancel-order" onclick="window.cancelReadyOrder(\'' + o.id + '\')">✕ إلغاء</button>' +
                '</div></div>';
        }).join('');
    }
    
    window.completePosOrder = function(orderId) {
        const orders = JSON.parse(localStorage.getItem(STORAGE_KEYS.PICKUP)) || [];
        pendingReadyOrder = orders.find(o => o.id === orderId);
        if (!pendingReadyOrder) return;
        if (!currentShift) { showToast('يجب فتح وردية أولاً', 'error'); return; }
        let subtotal = 0; pendingReadyOrder.items.forEach(item => subtotal += (item.price - (item.price * ((item.discount || 0) / 100))) * item.qty);
        document.getElementById('paymentAmountDisplay').textContent = fmt(subtotal + subtotal * TAX_RATE);
        document.getElementById('warehouseBtn').style.display = 'none';
        window.closeReadyOrdersModal(); 
        document.getElementById('paymentModal').classList.add('show');
    };
    
    /* ⭐ finalizeReadyOrder — مع تسجيل حركة sale */
    function finalizeReadyOrder(method) {
        const order = pendingReadyOrder; 
        window.closePaymentModal(); 
        if (!order) return;
        if (!currentShift) { showToast('يجب فتح وردية أولاً', 'error'); return; }
        
        let subtotal = 0; order.items.forEach(item => subtotal += (item.price - (item.price * ((item.discount || 0) / 100))) * item.qty);
        const tax = subtotal * TAX_RATE, total = subtotal + tax;
        const saleId = 'INV-' + Date.now();
        
        let inventory = JSON.parse(localStorage.getItem(STORAGE_KEYS.INVENTORY)) || [];
        if (order.source !== 'online') {
            order.items.forEach(ci => { 
                const inv = inventory.find(i => i.sku === ci.sku); 
                if (inv) { 
                    const before = inv.qty;
                    const after = Math.max(0, before - ci.qty);
                    logStockMovement(ci.sku, 'sale', -ci.qty, before, after, saleId, 'إتمام طلب مخزن: ' + order.id);
                    inv.qty = after; 
                    inv.reserved = Math.max(0, (inv.reserved || 0) - ci.qty); 
                } 
            });
        }
        localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
        
        let sales = JSON.parse(localStorage.getItem(STORAGE_KEYS.SALES)) || [];
        sales.push({ id: saleId, date: new Date().toISOString(), cashier: currentUser.name, subCashier: order.subCashier || null, mainCashier: currentUser.name, customerNo: order.customerNo || null, items: order.items, subtotal, tax, total, paymentMethod: method, source: 'pos', originalPickupOrder: order.id, shiftId: currentShift.id });
        localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
        
        const orders = JSON.parse(localStorage.getItem(STORAGE_KEYS.PICKUP)) || [];
        const idx = orders.findIndex(o => o.id === order.id);
        if (idx > -1) { orders[idx].status = 'completed'; orders[idx].completedAt = new Date().toISOString(); orders[idx].paymentMethod = method; orders[idx].mainCashier = currentUser.name; localStorage.setItem(STORAGE_KEYS.PICKUP, JSON.stringify(orders)); }
        
        prepareReceipt({ items: order.items, total: total, method: method, id: saleId, customerNo: order.customerNo, isPreview: false });
        document.getElementById('successMessage').textContent = 'تم إتمام البيع (' + method + ')';
        document.getElementById('successModal').classList.add('show');
        pendingReadyOrder = null; 
        checkReadyOrders(); 
        loadProducts(); 
        playBeep('success');
        updateShiftBar();
    }
    
    window.deliverOnlineOrder = function(orderId) {
        const orders = JSON.parse(localStorage.getItem(STORAGE_KEYS.PICKUP)) || [];
        const order = orders.find(o => o.id === orderId); if (!order) return;
        order.status = 'completed'; order.deliveredAt = new Date().toISOString();
        localStorage.setItem(STORAGE_KEYS.PICKUP, JSON.stringify(orders));
        showToast('✅ تم تسليم طلب الأونلاين'); 
        window.closeReadyOrdersModal(); 
        checkReadyOrders();
    };
    
    /* ⭐ cancelReadyOrder — مع تسجيل حركة cancel */
    window.cancelReadyOrder = function(orderId) {
        if (!confirm('إلغاء الطلب وإرجاع الكميات؟')) return;
        const orders = JSON.parse(localStorage.getItem(STORAGE_KEYS.PICKUP)) || [];
        const order = orders.find(o => o.id === orderId); if (!order) return;
        
        let inventory = JSON.parse(localStorage.getItem(STORAGE_KEYS.INVENTORY)) || [];
        order.items.forEach(ci => { 
            const inv = inventory.find(i => i.sku === ci.sku); 
            if (inv) { 
                if (order.source === 'online') {
                    const before = inv.qty;
                    logStockMovement(ci.sku, 'cancel', ci.qty, before, before + ci.qty, order.id, 'إلغاء طلب أونلاين');
                    inv.qty = before + ci.qty;
                } else {
                    logStockMovement(ci.sku, 'cancel', ci.qty, inv.qty, inv.qty, order.id, 'تحرير حجز - إلغاء طلب مخزن');
                    inv.reserved = Math.max(0, (inv.reserved || 0) - ci.qty);
                }
            } 
        });
        localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
        
        order.status = 'cancelled'; order.cancelledAt = new Date().toISOString();
        localStorage.setItem(STORAGE_KEYS.PICKUP, JSON.stringify(orders));
        showToast('تم إلغاء الطلب', 'error'); 
        checkReadyOrders(); 
        loadProducts();
    };
    
    window.openReturnsModal = function() {
        if (currentUser.permissions && currentUser.permissions.allowReturn === false) { showToast('ليس لديك صلاحية', 'error'); return; }
        document.getElementById('returnInvoiceSearch').value = ''; 
        window.filterInvoices(); 
        document.getElementById('returnsModal').classList.add('show');
    };
    window.closeReturnsModal = function() { document.getElementById('returnsModal').classList.remove('show'); };
    
    window.switchReturnTab = function(tab) {
        const isInvoice = tab === 'invoice';
        document.getElementById('tab-invoice-btn').classList.toggle('active', isInvoice);
        document.getElementById('tab-manual-btn').classList.toggle('active', !isInvoice);
        document.getElementById('returnTabInvoice').style.display = isInvoice ? 'block' : 'none';
        document.getElementById('returnTabManual').style.display = !isInvoice ? 'block' : 'none';
        if (!isInvoice) window.renderManualReturnGrid('');
    };
    
    window.filterInvoices = function() {
        const query = (document.getElementById('returnInvoiceSearch').value || '').trim().toLowerCase();
        const sales = JSON.parse(localStorage.getItem(STORAGE_KEYS.SALES)) || [];
        const list = document.getElementById('invoiceList');
        const filtered = sales.filter(s => s.source !== 'return' && s.id.toLowerCase().includes(query));
        if (filtered.length === 0) { list.innerHTML = '<div style="text-align:center; padding:20px; color:#888;">لا توجد فواتير مطابقة</div>'; return; }
        list.innerHTML = [...filtered].reverse().slice(0, 50).map(sale => 
            '<div class="invoice-item" onclick="window.selectInvoiceForReturn(\'' + sale.id + '\')"><div style="display:flex; justify-content:space-between; font-weight:bold; margin-bottom:5px;"><span>' + sale.id + '</span><span style="color:var(--gold);">' + sale.total.toLocaleString() + ' ر.ي</span></div><div style="font-size:12px; color:var(--muted);">' + new Date(sale.date).toLocaleDateString('ar-EG') + ' | ' + sale.cashier + '</div></div>'
        ).join('');
    };
    
    window.selectInvoiceForReturn = function(saleId) {
        const sales = JSON.parse(localStorage.getItem(STORAGE_KEYS.SALES)) || [];
        currentReturnInvoice = sales.find(s => s.id === saleId); 
        if (!currentReturnInvoice) return;
        window.closeReturnsModal();
        document.getElementById('returnInvIdDisplay').textContent = currentReturnInvoice.id;
        document.getElementById('returnItemsContainer').innerHTML = currentReturnInvoice.items.map((item, idx) => {
            const available = item.qty - (item.returnedQty || 0);
            return '<div class="return-item-row"><div><div style="font-weight:bold; font-size:14px;">' + item.name + '</div><div style="font-size:12px; color:var(--muted);">' + (item.color || '') + ' - ' + (item.size || '') + ' | سعر: ' + item.price.toLocaleString() + '</div>' + (item.returnedQty > 0 ? '<div style="font-size:11px; color:var(--danger); margin-top:3px;">أُرجع سابقاً: ' + item.returnedQty + '</div>' : '') + '</div><div style="display:flex; align-items:center; gap:8px;"><span style="font-size:12px;">متاح: <strong>' + available + '</strong></span><input type="number" class="return-qty-input" id="retQty_' + idx + '" min="0" max="' + available + '" value="' + (available > 0 ? 1 : 0) + '" ' + (available === 0 ? 'disabled style="background:#FED7D7"' : '') + '></div></div>';
        }).join('');
        document.getElementById('returnConfirmModal').classList.add('show');
    };
    
    window.closeReturnConfirmModal = function() { document.getElementById('returnConfirmModal').classList.remove('show'); currentReturnInvoice = null; };
    
    /* ⭐ processReturn — مع تسجيل حركة return */
    window.processReturn = function() {
        if (!currentReturnInvoice) return;
        if (!currentShift) { showToast('يجب فتح وردية أولاً', 'error'); return; }
        let inventory = JSON.parse(localStorage.getItem(STORAGE_KEYS.INVENTORY)) || [];
        let returnItems = [], returnSubtotal = 0, hasError = false;
        
        currentReturnInvoice.items.forEach((item, idx) => {
            const input = document.getElementById('retQty_' + idx); 
            if (!input || input.disabled) return;
            const qty = parseInt(input.value) || 0, available = item.qty - (item.returnedQty || 0);
            if (qty > available) { showToast('الكمية المتاحة ' + available, 'error'); hasError = true; return; }
            if (qty > 0) {
                const inv = inventory.find(i => i.sku === item.sku); 
                if (inv) {
                    const before = inv.qty;
                    const after = before + qty;
                    logStockMovement(item.sku, 'return', qty, before, after, 'RET-' + Date.now(), 'مرتجع من الفاتورة: ' + currentReturnInvoice.id);
                    inv.qty = after;
                }
                returnSubtotal += (item.price - (item.price * ((item.discount || 0) / 100))) * qty;
                returnItems.push({ ...item, qty: qty, _idx: idx });
            }
        });
        
        if (hasError) return;
        if (returnItems.length === 0) { showToast('لم يتم تحديد كمية', 'error'); return; }
        
        let sales = JSON.parse(localStorage.getItem(STORAGE_KEYS.SALES)) || [];
        const origSale = sales.find(s => s.id === currentReturnInvoice.id);
        if (origSale) returnItems.forEach(ri => { const origItem = origSale.items.find(i => i.sku === ri.sku); if (origItem) origItem.returnedQty = (origItem.returnedQty || 0) + ri.qty; });
        
        const returnTax = returnSubtotal * TAX_RATE, returnTotal = returnSubtotal + returnTax;
        sales.push({ id: 'RET-' + Date.now(), date: new Date().toISOString(), cashier: currentUser.name, items: returnItems.map(({ _idx, ...rest }) => rest), subtotal: -returnSubtotal, tax: -returnTax, total: -returnTotal, paymentMethod: 'مرتجع', source: 'return', originalInvoiceId: currentReturnInvoice.id, shiftId: currentShift.id });
        localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales)); 
        localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
        
        window.closeReturnConfirmModal(); 
        showToast('✅ تم الإرجاع. المبلغ: ' + returnTotal.toLocaleString() + ' ر.ي'); 
        loadProducts(); updateShiftBar();
    };
    
    window.renderManualReturnGrid = function(search) {
        const q = (search || '').toLowerCase().trim();
        const grid = document.getElementById('manualReturnGrid');
        const grouped = {};
        rawProducts.forEach(p => { if (!grouped[p.name]) grouped[p.name] = { name: p.name, image: p.image, variants: [] }; grouped[p.name].variants.push(p); });
        const filtered = Object.values(grouped).filter(p => p.name.toLowerCase().includes(q));
        if (filtered.length === 0) { grid.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:30px; color:var(--muted);">لا توجد منتجات مطابقة</div>'; return; }
        grid.innerHTML = filtered.map(p => '<div class="manual-return-card" onclick="window.openManualReturnVariants(\'' + p.name + '\')"><img src="' + (p.image || 'https://via.placeholder.com/100') + '" onerror="this.src=\'https://via.placeholder.com/100\'"><h4>' + p.name + '</h4><div class="price-tag">' + p.variants[0].price.toLocaleString() + ' ر.ي</div></div>').join('');
    };
    
    window.openManualReturnVariants = function(name) {
        const variants = rawProducts.filter(p => p.name === name);
        const options = variants.map((v, i) => (i+1) + '. ' + v.color + ' - ' + v.size + ' (SKU: ' + v.sku + ')').join('\n');
        const choice = prompt('اختر رقم الصنف المطلوب إرجاعه:\n' + options);
        if (!choice) return;
        const idx = parseInt(choice) - 1;
        if (isNaN(idx) || idx < 0 || idx >= variants.length) { alert('اختيار غير صالح'); return; }
        window.openManualReturn(variants[idx].sku);
    };
    
    window.openManualReturn = function(sku) {
        const product = rawProducts.find(p => p.sku === sku); 
        if (!product) return;
        currentManualReturnItem = product;
        document.getElementById('manualReturnPreview').innerHTML = '<div style="background:#F8FAFC; padding:12px; border-radius:10px; margin-bottom:12px;"><h4 style="font-size:14px; font-weight:800;">' + product.name + '</h4><div style="font-size:12px; color:var(--muted);">' + (product.color || '') + ' - ' + (product.size || '') + '</div><div style="font-size:11px; color:var(--gold); font-family:monospace;">' + product.sku + '</div></div><div style="margin-bottom:12px;"><label style="display:block; font-weight:700; margin-bottom:6px; font-size:13px;">الكمية:</label><input type="number" id="manualRetQty" min="1" value="1" oninput="window.updateManualRetTotal()" style="width:100%; padding:10px; border:1.5px solid var(--border); border-radius:8px; font-family:\'Cairo\'; font-size:16px; text-align:center; font-weight:bold;"></div><div style="background:white; border:1.5px solid var(--border); border-radius:10px; padding:12px;"><div style="display:flex; justify-content:space-between; margin-bottom:6px; font-size:13px;"><span>السعر:</span><strong id="manualRetPrice">' + product.price.toLocaleString() + ' ر.ي</strong></div><div style="display:flex; justify-content:space-between; margin-bottom:6px; font-size:13px;"><span>الضريبة:</span><strong id="manualRetTax">' + (product.price * TAX_RATE).toLocaleString() + ' ر.ي</strong></div><div style="display:flex; justify-content:space-between; padding-top:8px; border-top:1px dashed var(--border); font-size:15px; font-weight:900;"><span>الإجمالي:</span><span id="manualRetTotal" style="color:var(--gold);">' + (product.price + product.price * TAX_RATE).toLocaleString() + ' ر.ي</span></div></div>';
        document.getElementById('manualReturnConfirmModal').classList.add('show');
    };
    
    window.updateManualRetTotal = function() {
        if (!currentManualReturnItem) return;
        const qty = parseInt(document.getElementById('manualRetQty').value) || 0;
        const price = currentManualReturnItem.price;
        document.getElementById('manualRetPrice').textContent = (price * qty).toLocaleString() + ' ر.ي';
        document.getElementById('manualRetTax').textContent = ((price * TAX_RATE) * qty).toLocaleString() + ' ر.ي';
        document.getElementById('manualRetTotal').textContent = ((price + price * TAX_RATE) * qty).toLocaleString() + ' ر.ي';
    };
    
    window.closeManualReturnModal = function() { document.getElementById('manualReturnConfirmModal').classList.remove('show'); currentManualReturnItem = null; };
    
    /* ⭐ processManualReturn — مع تسجيل حركة return */
    window.processManualReturn = function() {
        if (!currentManualReturnItem) return;
        if (!currentShift) { showToast('يجب فتح وردية أولاً', 'error'); return; }
        const qty = parseInt(document.getElementById('manualRetQty').value) || 0;
        if (qty <= 0) { showToast('كمية غير صالحة', 'error'); return; }
        const product = currentManualReturnItem, price = product.price, subtotal = price * qty, taxAmt = (price * TAX_RATE) * qty, total = subtotal + taxAmt;
        
        let inventory = JSON.parse(localStorage.getItem(STORAGE_KEYS.INVENTORY)) || [];
        const inv = inventory.find(i => i.sku === product.sku); 
        if (inv) {
            const before = inv.qty;
            const after = before + qty;
            logStockMovement(product.sku, 'return', qty, before, after, 'RET-MAN-' + Date.now(), 'مرتجع يدوي');
            inv.qty = after;
        }
        localStorage.setItem(STORAGE_KEYS.INVENTORY, JSON.stringify(inventory));
        
        let sales = JSON.parse(localStorage.getItem(STORAGE_KEYS.SALES)) || [];
        sales.push({ id: 'RET-MAN-' + Date.now(), date: new Date().toISOString(), cashier: currentUser.name, items: [{ name: product.name, sku: product.sku, color: product.color || '', size: product.size || '', price: price, qty: qty, discount: 0 }], subtotal: -subtotal, tax: -taxAmt, total: -total, paymentMethod: 'مرتجع يدوي', source: 'return', manualReturn: true, shiftId: currentShift.id });
        localStorage.setItem(STORAGE_KEYS.SALES, JSON.stringify(sales));
        
        window.closeManualReturnModal(); 
        window.closeReturnsModal(); 
        showToast('✅ تم إرجاع ' + qty + ' قطعة. المبلغ: ' + total.toLocaleString() + ' ر.ي'); 
        loadProducts(); updateShiftBar();
    };
    
    function prepareReceipt(data) {
        document.getElementById('receipt-cashier-name').textContent = 'الكاشير: ' + (currentUser ? currentUser.name : '');
        let custNoStr = '';
        if (data.customerNo) custNoStr = ' - زبونة #' + data.customerNo;
        document.getElementById('receipt-items').innerHTML = data.items.map(item => {
            const finalPrice = item.price - (item.price * ((item.discount || 0) / 100));
            return '<div class="receipt-item"><span>' + item.name + ' (' + (item.size || '') + ') × ' + item.qty + '</span><span>' + (finalPrice * item.qty).toLocaleString() + '</span></div>';
        }).join('');
        document.getElementById('receipt-total-val').textContent = data.total.toLocaleString() + ' ر.ي';
        document.getElementById('receipt-payment-method').textContent = 'طريقة الدفع: ' + data.method;
        const orderNumEl = document.getElementById('receipt-order-number');
        if (data.isPreview) { orderNumEl.textContent = 'رقم الطلب: ' + data.id + custNoStr + ' (طلب مبدئي - غير مدفوع)'; document.getElementById('receipt-watermark').style.display = 'block'; }
        else { orderNumEl.textContent = 'رقم الفاتورة: ' + data.id + custNoStr; document.getElementById('receipt-watermark').style.display = 'none'; }
    }
    
    window.printReceipt = function() {
        if (currentUser.permissions && currentUser.permissions.printReceipt === false) { showToast('ليس لديك صلاحية', 'error'); return; }
        window.print();
    };
    
    window.closeSuccess = function() {
        document.getElementById('successModal').classList.remove('show');
        document.getElementById('barcodeInput').value = ''; 
        document.getElementById('barcodeInput').focus();
    };
    
    function initApp() {
        if (!currentUser) return;
        applyRole();
        if (currentUser.permissions?.canReceivePayment !== false) {
            const savedCart = localStorage.getItem(STORAGE_KEYS.CART_PREFIX + currentUser.id);
            if (savedCart) { try { cart = JSON.parse(savedCart); } catch (e) { cart = []; } }
        }
        loadProducts();
        renderCategoryBar();
        if (clockInterval) clearInterval(clockInterval);
        clockInterval = setInterval(() => { const el = document.getElementById('currentTime'); if (el) el.textContent = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }); }, 1000);
        const timeEl = document.getElementById('currentTime');
        if (timeEl) timeEl.textContent = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
        updateCartUI();
        if (currentShift) { startShiftTimer(); updateShiftBar(); }
        if (window.CAN_RECEIVE_PAYMENT) { checkReadyOrders(); if (readyOrdersInterval) clearInterval(readyOrdersInterval); readyOrdersInterval = setInterval(checkReadyOrders, 2000); }
        window.removeEventListener('storage', handleStorageChange);
        window.addEventListener('storage', handleStorageChange);
        if(window.innerWidth <= 900) { const closeBtn = document.querySelector('.mobile-close-btn'); if (closeBtn) closeBtn.style.display = 'block'; }
    }
    
    function handleStorageChange(e) {
        if (e.key === STORAGE_KEYS.INVENTORY) loadProducts();
        if (e.key === STORAGE_KEYS.PICKUP && window.CAN_RECEIVE_PAYMENT) checkReadyOrders();
        if (e.key === STORAGE_KEYS.SALES && currentShift) updateShiftBar();
    }

})();
