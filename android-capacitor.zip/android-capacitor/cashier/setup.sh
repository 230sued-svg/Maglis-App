#!/usr/bin/env bash
# يشغَّل مرة واحدة من داخل هذا المجلد
set -e
npm install
npx cap add android

MANIFEST="android/app/src/main/AndroidManifest.xml"
python3 - "$MANIFEST" <<'PY'
import sys, re
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
add = """    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n"""
for line in add.splitlines():
    key = re.search(r'android:name="([^"]+)"', line).group(1)
    if key not in s:
        s = s.replace("<application", line.strip() + "\n    <application", 1)
open(p, "w", encoding="utf-8").write(s)
PY

npx cap sync android
echo "تم. افتح المشروع في Android Studio بالأمر: npx cap open android"
