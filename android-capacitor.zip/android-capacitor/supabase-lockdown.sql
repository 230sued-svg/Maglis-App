-- نفّذ هذا الملف في Supabase (SQL Editor) بعد تثبيت النسخة الجديدة على كل الأجهزة
-- ويُقفل الجدول بحيث لا يصل إليه إلا حساب الموظفين المسجَّل دخوله

drop policy if exists "anon all" on kv_store;
revoke all on public.kv_store from anon;

grant usage on schema public to authenticated;
grant select, insert, update, delete on public.kv_store to authenticated;

drop policy if exists "staff all" on kv_store;
create policy "staff all" on kv_store
  for all to authenticated using (true) with check (true);
